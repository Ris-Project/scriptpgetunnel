#!/bin/bash
# ============================================================
#  PASANG SCRIPT BACKEND RENEW YANG SUDAH DIPERBAIKI
#  (bot-renew-vme / vle / tro / ss -> exit 0 saat sukses)
#  Pakai:  bash pasang-backend-renew.sh
# ============================================================

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
ok()   { echo -e "${GREEN}[OK]${NC} $1"; }
err()  { echo -e "${RED}[GAGAL]${NC} $1"; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FILES="bot-renew-vme bot-renew-vle bot-renew-tro bot-renew-ss"

# cari folder tempat script lama terpasang (mis. /usr/bin atau /usr/local/sbin)
TARGET=""
for cand in /usr/bin /usr/local/sbin /usr/local/bin /usr/sbin; do
    [ -f "$cand/bot-renew-vme" ] && TARGET="$cand" && break
done
if [ -z "$TARGET" ]; then
    # minta lokasi dari user
    WHERE=$(command -v bot-renew-vme 2>/dev/null)
    [ -n "$WHERE" ] && TARGET=$(dirname "$WHERE")
fi
if [ -z "$TARGET" ]; then
    TARGET="/usr/bin"
    echo -e "${YELLOW}[!]${NC} Script bot-renew lama tidak ketemu, pakai default: $TARGET"
else
    ok "Script lama ditemukan di: $TARGET"
fi

# backup
BACKUP="/root/renew-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP"
for f in $FILES; do
    [ -f "$TARGET/$f" ] && cp -a "$TARGET/$f" "$BACKUP/" && ok "backup $f"
done

for f in $FILES; do
    cp -f "$SCRIPT_DIR/$f" "$TARGET/$f" && chmod +x "$TARGET/$f" \
        && ok "pasang $TARGET/$f" || err "pasang $f"
done

echo ""
ok "SELESAI. Exit code script renew sekarang benar: 0 saat sukses."
ok "Bot sudah diperbaiki juga di sisi Python (cek kondisi sistem), jadi fix ini double-lapis."
