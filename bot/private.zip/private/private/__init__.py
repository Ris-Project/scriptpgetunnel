#!/usr/bin/env python3
import os
import asyncio
import time
import sqlite3
import math
import logging
import re
import subprocess
import requests
import datetime as DT
from telethon import TelegramClient, Button

# ============================================================
# KOMPATIBILITAS TOMBOL BERWARNA (style success / danger)
# Tombol berwarna butuh Telethon >= 1.45 (MTProto layer 222+).
# Kalau di VPS masih ada Telethon lama, argumen style otomatis
# dibuang supaya bot TETAP JALAN (tombol tampil polos, bukan crash).
# ============================================================
import inspect as _insp

def _patch_button_inline_compat():
    try:
        _fn = Button.inline
        if "style" in _insp.signature(_fn).parameters:
            return  # Telethon baru -> style didukung, tidak perlu patch
        _orig = getattr(_fn, "__func__", _fn)

        def _inline_compat(text, data=None, style=None, icon=None):
            return _orig(text, data)

        Button.inline = staticmethod(_inline_compat)
    except Exception:
        pass

_patch_button_inline_compat()

logging.basicConfig(level=logging.INFO)

# === Konstanta path
# Bisa dioverride lewat env var (berguna untuk testing), default tetap sama:
VAR_FILE = os.environ.get("PRIVATE_VAR_FILE", "/usr/bin/private/var.txt")
DB_FILE = os.environ.get("PRIVATE_DB_FILE", "/usr/bin/private/database.db")
SESSION_NAME = "private"  # nama file session Telethon
API_ID = 6                # ganti jika kamu pakai API ID sendiri
API_HASH = "eb06d4abfb49dc3eeb1aeb98ae0f581e"  # ganti jika pakai milikmu

uptime = DT.datetime.now()

# === Pastikan var.txt ada
os.makedirs(os.path.dirname(VAR_FILE), exist_ok=True)
if not os.path.exists(VAR_FILE):
    with open(VAR_FILE, "w") as f:
        f.write("# BOT_TOKEN=123456:ABC-xxx\n# ADMIN=11111111\n# DOMAIN=example.com\n"
                "# NICK=sg1  (opsional: nama panggilan bot, default = menu)\n")

# === Fungsi util: baca var.txt (dipakai modul lain juga)
def load_env_vars(path: str = VAR_FILE):
    result = {"BOT_TOKEN": None, "ADMINS": [], "DOMAIN": None, "BANNER": None, "NICK": None}
    if os.path.exists(path):
        with open(path, "r") as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, val = line.split("=", 1)
                key = key.strip()
                val = val.strip().strip('"').strip("'")
                if key == "BOT_TOKEN":
                    result["BOT_TOKEN"] = val
                elif key == "ADMIN":
                    result["ADMINS"].append(val)
                elif key == "DOMAIN":
                    result["DOMAIN"] = val
                elif key == "BANNER":
                    result["BANNER"] = val
                elif key == "NICK":
                    result["NICK"] = val
    return result

# === Pakai load_env_vars untuk inisialisasi global
env = load_env_vars()
BOT_TOKEN = env["BOT_TOKEN"]
ADMINS = env["ADMINS"]
DOMAIN = env["DOMAIN"]

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN belum diset di {}".format(VAR_FILE))

# ============================================================
# === NAMA PANGGILAN BOT (NICK) — konfigurasi di var.txt ===
# ============================================================
# Cara pakai: tambahkan satu baris di var.txt, contoh:  NICK=sg1
#   - Bot menu      : dipanggil dengan  .sg1  atau  /sg1
#   - Bot start     : dipanggil dengan  .startsg1  atau  /startsg1
#   - Semua tombol otomatis ikut ter-suffix, jadi 1 bot token (BOT_TOKEN)
#     bisa dipakai mengelola banyak server tanpa bentrok.
# Kalau NICK tidak ada / kosong / "menu", bot pakai panggilan default
#   .menu, /menu, .start, /start (perilaku lama).
# TIDAK PERLU LAGI edit kode modul satu per satu.
_raw_nick = str(env.get("NICK") or "").strip()
NICK = re.sub(r"[^a-zA-Z0-9_]", "", _raw_nick) or "menu"
SUFFIX = "" if NICK == "menu" else NICK

# (?:@\w+)? -> memungkinkan /perintah@NamaBot (Telegram kadang menambahkan
# @username saat command dipilih dari autocomplete, terutama di grup)
PATTERN_MENU = r"(?:\.{}|/{})(?:@\w+)?$".format(NICK, NICK)
PATTERN_START = r"(?:\.start{}|/start{})(?:@\w+)?$".format(SUFFIX, SUFFIX)
CB_MENU = NICK
CB_START = "start" + SUFFIX

def cbx(name):
    """Callback data dengan suffix NICK (bytes).
    Semua handler & tombol wajib pakai ini agar konsisten."""
    name = str(name)
    if name == "menu":
        return CB_MENU.encode()
    if name == "start":
        return CB_START.encode()
    return (name + SUFFIX).encode()

# === Inisialisasi DB + tabel
os.makedirs(os.path.dirname(DB_FILE), exist_ok=True)
conn = sqlite3.connect(DB_FILE)
c = conn.cursor()
c.execute("CREATE TABLE IF NOT EXISTS admin (user_id TEXT UNIQUE)")
conn.commit()

# === Sinkron admin dari var.txt ke DB
for admin_id in ADMINS:
    c.execute("INSERT OR IGNORE INTO admin (user_id) VALUES (?)", (str(admin_id),))
conn.commit()
conn.close()

# === Client Telethon
bot = TelegramClient(SESSION_NAME, API_ID, API_HASH).start(bot_token=BOT_TOKEN)

# === Helper DB
def get_db():
    x = sqlite3.connect(DB_FILE)
    x.row_factory = sqlite3.Row
    return x

def valid(id_):
    db = get_db()
    rows = db.execute("SELECT user_id FROM admin").fetchall()
    admin_list = [r[0] for r in rows]
    return "true" if str(id_) in admin_list else "false"

def convert_size(size_bytes):
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return f"{s} {size_name[i]}"

# ============================================================
# === Banner Info (mengikuti script pgetunnel) ===
# ============================================================
AUTH_URL = "https://raw.githubusercontent.com/Ris-Project/scriptpgetunnel/main/ip"
DAYS_ID = ("Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu")
MONTHS_ID = ("Januari", "Februari", "Maret", "April", "Mei", "Juni",
             "Juli", "Agustus", "September", "Oktober", "November", "Desember")

def _get_vps_ip():
    """Ambil IP publik VPS (sama seperti script: curl icanhazip.com)."""
    for url in ("https://api.ipify.org", "http://icanhazip.com"):
        try:
            ip = requests.get(url, timeout=5).text.strip()
            if ip:
                return ip
        except Exception:
            pass
    return ""

def get_expire_info(exp):
    """Format Exp Date spt script: 11-11-2026 9 Days Active / Lifetime / Unknown."""
    if exp == "lifetime":
        return "Lifetime"
    if not exp:
        return "Unknown"
    try:
        expd = DT.datetime.strptime(exp, "%Y-%m-%d").date()
    except Exception:
        return "Unknown"
    days = (expd - DT.date.today()).days
    status = "Expired" if days < 0 else ("Today Expire" if days == 0 else "Active")
    return "{} {} Days {}".format(expd.strftime("%d-%m-%Y"), days, status)

def get_banner_info():
    """Banner info akun: Username, Exp Date, Date, Time, Version (WIB).
    Urutan & spasi tunggal mengikuti contoh agar rapih di caption foto."""
    ip = _get_vps_ip()
    username, exp = "Unknown", ""
    try:
        raw = requests.get(AUTH_URL, timeout=5).text
        for line in raw.splitlines():
            cols = line.split()
            if ip and ip in cols:
                username = cols[1] if len(cols) > 1 else "Unknown"
                exp = cols[2] if len(cols) > 2 else ""
                break
    except Exception:
        pass

    # Versi mengikuti script pgetunnel (/etc/pgetunnel/.version)
    ver = "1.0"
    try:
        with open("/etc/pgetunnel/.version") as f:
            parts = f.read().split()
            if len(parts) >= 2:
                ver = parts[1]
    except Exception:
        pass

    # Hari, tanggal, jam (otomatis - Indonesia, sama seperti script)
    now = DT.datetime.now()
    day = DAYS_ID[(now.weekday() + 1) % 7]
    date_id = "{}, {} {} {}".format(day, now.strftime("%d"), MONTHS_ID[now.month - 1], now.strftime("%Y"))
    time_id = "{} {}".format(now.strftime("%H:%M:%S"), now.strftime("%Z") or "WIB")

    return (
        "┏━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "┃   👤 Username : {}\n"
        "┃   ⏰ Exp Date : {}\n"
        "┃   📆 Date : {}\n"
        "┃   🕒 Time : {}\n"
        "┃   🚀 Version : {} (Auto)\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━━━┛"
    ).format(username, get_expire_info(exp), date_id, time_id, ver)

# Alias agar pemanggilan banner_info() (mis. di modules/start.py, modules/menu.py
# dan modul dist) tetap berfungsi
banner_info = get_banner_info

# ============================================================
# === Banner Menu (gambar) ===
# ============================================================
BANNER_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "banner.jpg")

def get_banner_file():
    """Gambar banner menu: utamakan file banner.jpg di folder bot,
    kalau tidak ada pakai URL dari BANNER= di var.txt, kalau keduanya
    tidak ada kembalikan None (menu terkirim sebagai teks biasa)."""
    try:
        if os.path.exists(BANNER_FILE):
            return BANNER_FILE
    except Exception:
        pass
    return load_env_vars().get("BANNER") or None

# ============================================================
# === INFO MEMBER & KUOTA (SSH, VMESS, VLESS, TROJAN, SHADOWSOCKS) ===
# ============================================================
# Sumber data di server (mengikuti script pgetunnel):
#   SSH         : user = /etc/passwd (UID >= 1000),
#                 expired = "chage -l <user>",
#                 limit kuota = /etc/ssh/<user>            (byte),
#                 terpakai    = /etc/limit/ssh/<user>      (byte)
#   vmess/vless : user + expired = penanda di /etc/xray/config.json
#   /trojan/ss    ("### user tgl" / "#& user tgl" / "#! user tgl"
#                 / "#@& user tgl"),
#                 limit kuota = /etc/<layanan>/<user>       (byte),
#                 terpakai    = /etc/limit/<layanan>/<user> (byte)
#
# Dipakai untuk:
#   1. Pesan sukses RENEW  -> diperpanjang X hari, masa aktif
#      sekarang Y hari, tanggal expired baru (lihat modul ssh.py,
#      vmess.py, vless.py, trojan.py, shadowsocks.py).
#   2. Tombol LIST MEMBER  -> tiap member tampil rapih: username,
#      expired, sisa hari, limit kuota, terpakai, sisa kuota,
#      lengkap dengan tombol Next/Back per halaman.
# ============================================================

MEMBER_PER_PAGE = 4   # jumlah akun per halaman list member

PASSWD_FILE = "/etc/passwd"
XRAY_CONFIG_FILE = "/etc/xray/config.json"

_QUOTA_DIRS = {
    "ssh": "/etc/ssh",
    "vmess": "/etc/vmess",
    "vless": "/etc/vless",
    "trojan": "/etc/trojan",
    "shadowsocks": "/etc/shadowsocks",
}
_LIMIT_DIRS = {
    "ssh": "/etc/limit/ssh",
    "vmess": "/etc/limit/vmess",
    "vless": "/etc/limit/vless",
    "trojan": "/etc/limit/trojan",
    "shadowsocks": "/etc/limit/shadowsocks",
}
_XRAY_MARKERS = {
    "vmess": "###",
    "vless": "#&",
    "trojan": "#!",
    "shadowsocks": "#@&",
}
_MEMBER_TITLES = {
    "ssh": "LIST MEMBER SSH",
    "vmess": "LIST MEMBER VMESS",
    "vless": "LIST MEMBER VLESS",
    "trojan": "LIST MEMBER TROJAN",
    "shadowsocks": "LIST MEMBER SHADOWSOCKS",
}
_MEMBER_PAGE_CB = {
    "ssh": "listssh",
    "vmess": "listvm",
    "vless": "listvl",
    "trojan": "listtr",
    "shadowsocks": "listss",
}

def fmt_quota(num_bytes, zero="Unlimited"):
    """Format byte jadi '300 GB' / '500 MB'. 0/negatif -> zero
    (default 'Unlimited', untuk terpakai pakai zero='0 B')."""
    try:
        b = int(num_bytes)
    except (TypeError, ValueError):
        return zero
    if b <= 0:
        return zero
    if b >= 1024 ** 3:
        v = b / 1024 ** 3
        return "{} GB".format(int(v) if v == int(v) else round(v, 2))
    if b >= 1024 ** 2:
        v = b / 1024 ** 2
        return "{} MB".format(int(v) if v == int(v) else round(v, 2))
    if b >= 1024:
        return "{} KB".format(int(round(b / 1024.0)))
    return "{} B".format(b)

def _parse_exp_date(text):
    """Parse tanggal expired -> datetime.date / 'lifetime' / None.
    Format yang didukung: 2026-11-11 (config.json & db xray),
    'Nov 11, 2026' (chage), '11 Nov, 2026' (/etc/ssh/.ssh.db)."""
    if text is None:
        return None
    raw = " ".join(str(text).strip().split())
    if not raw:
        return None
    if raw.lower() in ("never", "lifetime", "unlimited"):
        return "lifetime"
    for fmt in ("%Y-%m-%d", "%b %d, %Y", "%d %b, %Y", "%Y/%m/%d", "%d-%m-%Y"):
        try:
            return DT.datetime.strptime(raw, fmt).date()
        except ValueError:
            continue
    return None

def _read_bytes_file(path):
    """Baca file berisi jumlah byte -> int / None kalau tidak ada
    isinya. Toleran berbagai format penulisan kuota script server:
      '12345678'  '12345.67'  '1,234,567'
      '500 MB'    '1.5 GB'    '1024 KB'    '2 TB'
    (fix V7: dulu format seperti '500 MB' / '1,234' gagal dibaca
    -> Terpakai selalu tampil 0 B walau user sedang online)."""
    try:
        with open(path, "r") as f:
            raw = f.read().strip()
    except Exception:
        return None
    if not raw:
        return None
    t = raw.replace(",", "")
    m = re.match(r"^\s*([0-9]*\.?[0-9]+)\s*([KkMmGgTt])[Bb]?\s*$", t)
    if m:
        try:
            mult = {"k": 1024, "m": 1024 ** 2, "g": 1024 ** 3,
                    "t": 1024 ** 4}[m.group(2).lower()]
            return int(float(m.group(1)) * mult)
        except Exception:
            return None
    try:
        return int(float(t.split()[0]))
    except (ValueError, IndexError):
        return None

def _read_int_file(path):
    """Baca file berisi satu angka (byte kuota dll) -> int (0 kalau gagal)."""
    v = _read_bytes_file(path)
    return v if v is not None else 0

def _used_bytes(limit_dir, user):
    """Data TERPAKAI (byte) user: cek beberapa lokasi umum file
    counter di folder limit. Return None kalau tidak ada data
    (V7.2: list member lalu menampilkan '0 B', bukan lagi '-')."""
    if not limit_dir:
        return None
    u = str(user)
    for rel in (u, u + ".txt", "quota/" + u, "usage/" + u):
        v = _read_bytes_file(os.path.join(limit_dir, rel))
        if v is not None:
            return v
    return None

def _read_ip_limit(path):
    """Baca limit IP dari file (ambil angka pertama, default 1)."""
    try:
        with open(path, "r") as f:
            for tok in f.read().split():
                if tok.isdigit():
                    return tok
    except Exception:
        pass
    return "1"

def _passwd_users():
    """Daftar user SSH (UID >= 1000, tanpa nobody) dari /etc/passwd."""
    users = []
    try:
        with open(PASSWD_FILE, "r") as f:
            for line in f:
                cols = line.split(":")
                if len(cols) < 3:
                    continue
                name = cols[0].strip()
                if not name or name == "nobody":
                    continue
                try:
                    if int(cols[2]) >= 1000:
                        users.append(name)
                except ValueError:
                    continue
    except Exception:
        pass
    return users

def _ssh_expired(user):
    """(tanggal_expired, sisa_hari) akun SSH via chage -l.
    Contoh hasil: ('11-11-2026', '9 Hari') / ('Lifetime', 'Lifetime')."""
    try:
        out = subprocess.check_output(
            ["chage", "-l", str(user)],
            stderr=subprocess.DEVNULL, timeout=10).decode("utf-8", "ignore")
    except Exception:
        return "Unknown", "-"
    for line in out.splitlines():
        if "Account expires" in line and ":" in line:
            raw = line.split(":", 1)[1].strip()
            d = _parse_exp_date(raw)
            if d == "lifetime":
                return "Lifetime", "Lifetime"
            if d is None:
                return (raw or "Unknown"), "-"
            days = (d - DT.date.today()).days
            return d.strftime("%d-%m-%Y"), ("{} Hari".format(days) if days >= 0 else "Expired")
    return "Unknown", "-"

def _xray_expiry_map(service):
    """Peta {username: tanggal_expired} dari penanda di config.json."""
    result = {}
    marker = _XRAY_MARKERS.get(service, "")
    if not marker:
        return result
    try:
        with open(XRAY_CONFIG_FILE, "r", errors="ignore") as f:
            for line in f:
                parts = line.strip().split()
                if parts and parts[0] == marker and len(parts) >= 2:
                    result[parts[1]] = parts[2] if len(parts) > 2 else ""
    except Exception:
        pass
    return result

def get_members(service):
    """Semua member satu layanan + expired, sisa hari, kuota, dan
    durasi aktif ('Sedang Aktif' / 'Terakhir Aktif').
    Dipakai tombol List Member di tiap modul service."""
    service = str(service).lower()
    today = DT.date.today()
    now_ts = time.time()
    if service == "ssh":
        exp_map = None                       # SSH: expired via chage per user
        users = sorted(_passwd_users())      # urut abjad biar rapih konsisten
    else:
        exp_map = _xray_expiry_map(service)
        users = sorted(exp_map)
    quota_dir = _QUOTA_DIRS.get(service)
    limit_dir = _LIMIT_DIRS.get(service)
    # Status online + Total Login + IP Aktif + data durasi aktif
    seen = {}      # xray: {user: {'last': epoch, 'start': epoch}}
    sess = {}      # ssh  : {user: {'count', 'since', 'ips'}}
    if service == "ssh":
        sess = _ssh_sessions()             # sekali panggil utk semua data
        online_set = set(sess)             # punya >= 1 sesi aktif = online
        # Total Login (kali) = setiap BUKA KONEKSI / login ke server,
        # dari riwayat wtmp (`last`) - termasuk sesi lama yang sudah
        # selesai. Fallback sesi aktif bila `last` kosong supaya
        # user yang sedang online tetap >= 1.
        hist = _ssh_login_history()
        login_map = dict(hist)
        for u, v in sess.items():
            login_map[u] = max(login_map.get(u, 0), v.get("count", 0))
        # IP Aktif = IP sumber BERBEDA dari sesi yang SEDANG jalan
        # (beda IP ~ beda HP) - akun offline = 0
        ipaktif_map = {u: len(v.get("ips") or ()) for u, v in sess.items()}
    else:
        online_set, ip_map, seen, xstat = _xray_activity()
        ipson = xstat.get("ips_online", {})
        # Total Login (kali) = setiap BUKA KONEKSI (login) user:
        # 1 rantai aktivitas beruntun di access.log = 1 login;
        # jeda > ONLINE_WINDOW_SEC = koneksi lama ditutup ->
        # connect lagi dihitung login baru. BUKAN jumlah koneksi
        # TCP (1 HP bisa buka banyak koneksi tanpa login ulang).
        login_map = {}
        for u in set(seen) | set(ipson):
            c = (seen.get(u) or {}).get("count") or 0
            login_map[u] = c if c > 0 else 1
        # IP Aktif = jumlah IP client BERBEDA yang SEDANG aktif
        # (beda IP ~ beda HP/lokasi) - akun offline = 0
        ipaktif_map = {u: len(s) for u, s in ipson.items()}
    # Trafik TERPAKAI asli per user dari xray stats API (best effort,
    # kosong kalau server tidak mengaktifkan stats)
    stats_map = {} if service == "ssh" else _xray_stats_traffic()
    members = []
    for user in users:
        if service == "ssh":
            exp_str, days_str = _ssh_expired(user)
        else:
            d = _parse_exp_date(exp_map.get(user, ""))
            if d == "lifetime":
                exp_str, days_str = "Lifetime", "Lifetime"
            elif d is None:
                exp_str, days_str = "Unknown", "-"
            else:
                days = (d - today).days
                exp_str = d.strftime("%d-%m-%Y")
                days_str = "{} Hari".format(days) if days >= 0 else "Expired"
        limit_b = _read_int_file(os.path.join(quota_dir, user)) if quota_dir else 0
        used_raw = _used_bytes(limit_dir, user)
        if (used_raw is None or used_raw == 0) and stats_map.get(user):
            # counter file kosong / 0, tapi xray stats tahu trafik aslinya
            used_raw = stats_map[user]
        used_b = used_raw if used_raw is not None else 0
        if limit_b > 0:
            left_s = fmt_quota(max(limit_b - used_b, 0), zero="0 B")
            limit_s = fmt_quota(limit_b)
        else:
            left_s = "Unlimited"
            limit_s = "Unlimited"
        # V7.2: tidak ada data sama sekali -> tampil '0 B'
        # (tidak ada lagi 'Terpakai : -' yang bikin bingung)
        used_s = fmt_quota(used_b, zero="0 B")
        # Durasi aktif (V6):
        #   online  -> 'Sedang Aktif' sejak awal masa aktif berjalan
        #   offline -> 'Terakhir Aktif' sejak aktivitas terakhir
        if user in online_set:
            start = (sess.get(user) or {}).get("since") if service == "ssh" \
                else (seen.get(user) or {}).get("start")
            aktif = fmt_durasi_aktif(now_ts - start) \
                if start is not None else "-"
        else:
            if service == "ssh":
                secs = _ssh_last_active(user)
            else:
                last = (seen.get(user) or {}).get("last")
                secs = max(now_ts - last, 0.0) if last is not None else None
            aktif = fmt_terakhir_aktif(secs) if secs is not None else "-"
        members.append({
            "user": user,
            "exp": exp_str,
            "days": days_str,
            "limit": limit_s,
            "used": used_s,
            "left": left_s,
            "online": user in online_set,
            "iplimit": _read_ip_limit(
                os.path.join(limit_dir, "ip", user)) if limit_dir else "1",
            "logins": login_map.get(user, 0),
            "ipaktif": ipaktif_map.get(user, 0),
            "aktif": aktif,
        })
    return members

def get_member_info(service, user):
    """Info SATU akun dari sistem (dipakai pesan sukses renew):
    tanggal expired baru + sisa hari setelah diperpanjang."""
    service = str(service).lower()
    info = {"exp": "Unknown", "days": "-", "quota": "Unlimited", "iplimit": "1"}
    if service == "ssh":
        info["exp"], info["days"] = _ssh_expired(user)
        info["quota"] = fmt_quota(_read_int_file(
            os.path.join(_QUOTA_DIRS["ssh"], user)))
        info["iplimit"] = _read_ip_limit(
            os.path.join(_LIMIT_DIRS["ssh"], "ip", user))
    else:
        d = _parse_exp_date(_xray_expiry_map(service).get(user, ""))
        if d == "lifetime":
            info["exp"], info["days"] = "Lifetime", "Lifetime"
        elif d is not None:
            days = (d - DT.date.today()).days
            info["exp"] = d.strftime("%d-%m-%Y")
            info["days"] = "{} Hari".format(days) if days >= 0 else "Expired"
        info["quota"] = fmt_quota(_read_int_file(
            os.path.join(_QUOTA_DIRS[service], user)))
        info["iplimit"] = _read_ip_limit(
            os.path.join(_LIMIT_DIRS[service], "ip", user))
    return info

# ============================================================
# === STATUS ONLINE / OFFLINE + DURASI AKTIF MEMBER ===
# ============================================================
# - SSH         : user terlihat di output `who` (OpenSSH & Dropbear)
#                 dan di judul proses sshd ("sshd: user@notty").
# - vmess/vless/trojan/shadowsocks : email user muncul di log
#   /var/log/xray/access.log dalam ONLINE_WINDOW_SEC detik
#   terakhir (logika yang sama dengan script cek-ws/cek-vless/
#   cek-tr/cek-ss).
#
# DURASI AKTIF (V6) - dipakai tombol LIST MEMBER di semua layanan:
#   🟢 Online  -> ⏱ Sedang Aktif : 5 Menit / 2 Jam 15 Menit /
#                 1 Hari 3 Jam
#       SSH  : sejak waktu login sesi yang terlihat di `who`.
#       Xray : sejak awal rantai aktivitas beruntun di access.log
#              (jeda antar aktivitas <= ONLINE_WINDOW_SEC dianggap
#              masih satu masa aktif).
#   ⚪ Offline -> ⏱ Terakhir Aktif : 30 Menit Lalu / 3 Hari Lalu
#       SSH  : dari waktu sesi terakhir berakhir (`last`).
#       Xray : dari aktivitas terakhir user di access.log.
# ============================================================

ONLINE_WINDOW_SEC = 300   # aktivitas dalam N detik terakhir = Online
XRAY_ACCESS_LOG = os.environ.get("PRIVATE_XRAY_LOG", "/var/log/xray/access.log")
# Ekor log yang dibaca untuk cek online + durasi aktif. Durasi butuh
# riwayat lebih panjang, jadi default naik ke 8 MB ( masih ringan ).
# Bisa diatur lewat env: PRIVATE_XRAY_TAIL_MB=8
try:
    _XRAY_TAIL_MB = float(os.environ.get("PRIVATE_XRAY_TAIL_MB", "8") or 8)
except ValueError:
    _XRAY_TAIL_MB = 8.0
_ONLINE_TAIL_BYTES = max(int(_XRAY_TAIL_MB * 1024 * 1024), 512 * 1024)
_EMAIL_RE = re.compile(r"email:\s*([^\s\[\]]+)")
# pola tanggal+jam di awal baris access.log: '2026/11/02 10:30:45 ...'
_XRAY_TS_RE = re.compile(
    r"^(\d{4})/(\d{1,2})/(\d{1,2})\s+(\d{1,2}):(\d{2})(?::(\d{2}))?")
_XRAY_ACT_CACHE = {"t": 0.0, "online": frozenset(), "ips": {}, "seen": {},
                   "stats": {}}

# pola alamat client di access.log: '1.2.3.4:5678' atau '[::1]:44858'
_ADDR_RE = re.compile(
    r"^(\d{1,3}\.){3}\d{1,3}(:\d+)?$|^\[[0-9A-Fa-f:.]+\](:\d+)?$")

def _client_addr(tok):
    """'1.2.3.4:5678' / '[::1]:44858' -> '1.2.3.4' / '::1'.
    Return None kalau token bukan alamat IP."""
    tok = str(tok).strip()
    if not _ADDR_RE.match(tok):
        return None
    if tok.startswith("["):
        end = tok.find("]")
        return tok[1:end] if end > 1 else None
    return tok.rsplit(":", 1)[0]

def _tim2sec(arg):
    """'HH:MM:SS' (boleh ada pecahan '.xxx') -> total detik."""
    total = 0
    for part in str(arg).split(".")[0].split(":"):
        part = part.strip()
        if not part.isdigit():
            return -1
        total = total * 60 + int(part)
    return total

def _xray_activity():
    """Aktivitas xray dari access.log (sama seperti script cek-ws).
    Return (online, ips, seen, stat):
      - online : set username yang punya aktivitas dalam
        ONLINE_WINDOW_SEC detik terakhir
      - ips    : {username: set(ip client)} semua IP yang terlihat
        di ekor log (lintas hari)
      - seen   : {username: {"last": epoch, "start": epoch,
                 "count": n}}
        last  = waktu aktivitas TERAKHIR user (untuk teks
        'Terakhir Aktif X Lalu' user offline),
        start = awal rantai aktivitas beruntun yang berujung di
        aktivitas terakhir; jeda antar aktivitas <= ONLINE_WINDOW_SEC
        dianggap masih satu masa aktif (untuk teks 'Sedang Aktif X'),
        count = jumlah rantai login dalam ekor log - setiap 'buka
        koneksi' (login) = +1; dipakai Total Login list member
        (V7.3, dibedakan dari IP Aktif).
      - stat  : data window online utk Total Login & IP Aktif:
          conns      = {user: set('ip:port')} koneksi aktif
          ips_online = {user: set(ip)} IP client aktif
    Hasil di-cache 10 detik supaya 5 layanan tidak membaca log
    berulang-ulang."""
    now = time.time()
    if now - _XRAY_ACT_CACHE["t"] < 10:
        st = _XRAY_ACT_CACHE["stats"]
        return (set(_XRAY_ACT_CACHE["online"]),
                {u: set(s) for u, s in _XRAY_ACT_CACHE["ips"].items()},
                {u: dict(v) for u, v in _XRAY_ACT_CACHE["seen"].items()},
                {"conns": {u: set(s) for u, s in st.get("conns", {}).items()},
                 "ips_online": {u: set(s) for u, s in
                                st.get("ips_online", {}).items()}})
    online = set()
    ips = {}
    seen = {}
    conns = {}      # {user: set('ip:port')} koneksi aktif (window online)
    ips_on = {}     # {user: set(ip)} IP client aktif (window online)
    partial = False
    try:
        with open(XRAY_ACCESS_LOG, "rb") as f:
            try:
                f.seek(-_ONLINE_TAIL_BYTES, os.SEEK_END)
                partial = True   # posisi awal bisa di tengah baris
            except OSError:
                f.seek(0)        # file kecil -> dibaca utuh dari awal
            blob = f.read().decode("utf-8", "ignore")
        lines = blob.split("\n")
        if partial and lines:
            lines = lines[1:]    # buang baris pertama (kemungkinan terpotong)
    except Exception:
        lines = []
    now_sec = _tim2sec(time.strftime("%H:%M:%S"))
    for line in lines:
        if "email" not in line:
            continue
        parts = line.strip().split()
        if len(parts) < 2:
            continue
        # Waktu baris log: utamakan tanggal lengkap '2026/11/02 10:30:45'
        # (butuh untuk durasi aktif). Kalau formatnya tidak dikenali,
        # fallback ke jam saja seperti perilaku lama (cukup utk cek online).
        ts = None
        m_ts = _XRAY_TS_RE.match(line.strip())
        if m_ts:
            try:
                ts = DT.datetime(
                    int(m_ts.group(1)), int(m_ts.group(2)), int(m_ts.group(3)),
                    int(m_ts.group(4)), int(m_ts.group(5)),
                    int(m_ts.group(6) or 0)).timestamp()
            except Exception:
                ts = None
        if ts is not None:
            # log bertanggal lengkap -> bisa lintas hari, tanpa trik tengah malam
            is_online = (now - ts) <= ONLINE_WINDOW_SEC
        else:
            # fallback jam-saja: '10:30:45 ...' (tanpa tanggal) -> parts[0],
            # atau format lama '2026/11/02 10:30:45 ...' -> parts[1]
            tsec = _tim2sec(parts[0])
            if tsec < 0:
                tsec = _tim2sec(parts[1])
            if tsec < 0:
                continue
            diff = now_sec - tsec
            if diff < 0 or diff > ONLINE_WINDOW_SEC:
                # diff < 0 -> log hari sebelumnya (lewat tengah malam)
                continue
            is_online = True
        m = _EMAIL_RE.search(line)
        if not m:
            continue
        user = m.group(1).split("@")[0]
        # Alamat client: token pertama yang berbentuk IP:port.
        # Token setelah label 'remote:' / 'local:' adalah alamat
        # tujuan server, jadi dilewati.
        addr = None
        addr_raw = None
        prev = ""
        for tok in parts[2:]:
            if prev.lower() in ("remote:", "local:"):
                prev = tok
                continue
            a = _client_addr(tok)
            if a:
                addr = a
                addr_raw = tok
                break
            prev = tok
        if addr:
            ips.setdefault(user, set()).add(addr)
        if is_online:
            online.add(user)
            if addr:
                # koneksi aktif (IP:port) disimpan sebagai data
                # pendukung; Total Login sendiri kini dihitung per
                # 'buka koneksi' (rantai aktivitas) - lihat bawah
                conns.setdefault(user, set()).add(addr_raw)
                # IP aktif = IP saja (tanpa port)
                ips_on.setdefault(user, set()).add(addr)
        # Riwayat waktu 'Sedang Aktif' / 'Terakhir Aktif' + hitungan
        # Total Login: satu rantai aktivitas beruntun = satu buka
        # koneksi (login). Jeda > ONLINE_WINDOW_SEC dianggap koneksi
        # sebelumnya sudah putus -> login berikutnya +1.
        if ts is not None:
            st = seen.get(user)
            if st is None:
                seen[user] = {"last": ts, "start": ts, "count": 1}
            else:
                if ts >= st["last"] and ts - st["last"] > ONLINE_WINDOW_SEC:
                    st["start"] = ts
                    st["count"] = st.get("count", 1) + 1
                st["last"] = max(st["last"], ts)
    _XRAY_ACT_CACHE["t"] = now
    _XRAY_ACT_CACHE["online"] = frozenset(online)
    _XRAY_ACT_CACHE["ips"] = ips
    _XRAY_ACT_CACHE["seen"] = seen
    _XRAY_ACT_CACHE["stats"] = {"conns": conns, "ips_online": ips_on}
    return online, {u: set(s) for u, s in ips.items()}, \
        {u: dict(v) for u, v in seen.items()}, \
        {"conns": {u: set(s) for u, s in conns.items()},
         "ips_online": {u: set(s) for u, s in ips_on.items()}}

def _xray_online_users():
    """Set username xray yang punya aktivitas terakhir di access.log
    dalam ONLINE_WINDOW_SEC detik (sama seperti script cek-ws)."""
    return set(_xray_activity()[0])

def _xray_login_ips():
    """{username: set(ip client)} xray di ekor access.log (lintas
    hari). Catatan V7.3: Total Login list member dihitung per buka
    koneksi (rantai aktivitas, seen[u]['count']) - BUKAN dari IP
    ini; IP Aktif memakai ips_online (window)."""
    return _xray_activity()[1]

def _xray_seen():
    """{username: {'last': epoch, 'start': epoch}} xray dari access.log
    (dipakai durasi 'Sedang Aktif' & 'Terakhir Aktif' list member)."""
    return _xray_activity()[2]

_XRAY_STATS_CACHE = {"t": 0.0, "data": {}}

def _enclosing_object(text, pos):
    """Ambil teks SATU objek { ... } yang mengapit posisi `pos`
    (brace matching sederhana). Dipakai karena config.json script
    server berisi baris penanda '###' sehingga tidak bisa dibaca
    dengan json.load."""
    start = text.rfind("{", 0, pos)
    if start < 0:
        return None
    depth = 0
    for i in range(start, min(len(text), start + 8192)):
        ch = text[i]
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text[start:i + 1]
    return None

def _xray_api_ports(text):
    """Daftar kandidat port API stats xray dari isi config.json,
    urut prioritas. Semua tata letak inbound API yang umum didukung:
      1. 'listen': '127.0.0.1:10085'           (host:port gabung)
      2. 'listen': '127.0.0.1'  +  'port': 10085   (field terpisah;
         inilah tata letak standar yang dulu TIDAK dikenali ->
         bot gagal ambil data stats -> Terpakai tampil '-')
      3. inbound 'protocol': 'dokodemo-door'   (API xray di script
         server umumnya berupa dokodemo-door lokal)
    Port fallback 10085/10086 ditambahkan oleh pemanggil."""
    ports = []

    def add(p):
        if p and p not in ports:
            ports.append(p)

    # 1) listen gabungan host:port
    for m in re.finditer(r'"listen"\s*:\s*"127\.0\.0\.1:(\d+)"', text):
        add(m.group(1))
    # 2) listen lokal dengan port di field terpisah (objek yang sama)
    for m in re.finditer(r'"listen"\s*:\s*"127\.0\.0\.1"', text):
        seg = _enclosing_object(text, m.start())
        if seg:
            pm = re.search(r'"port"\s*:\s*(\d+)', seg)
            if pm:
                add(pm.group(1))
    # 3) inbound dokodemo-door (API)
    for m in re.finditer(r'"protocol"\s*:\s*"dokodemo-door"', text):
        seg = _enclosing_object(text, m.start())
        if seg:
            pm = re.search(r'"port"\s*:\s*(\d+)', seg)
            if pm:
                add(pm.group(1))
    return ports

def _xray_stats_traffic():
    """{username: total byte (uplink+downlink)} dari xray stats API
    (best effort). Ini sumber data TERPAKAI yang sesungguhnya kalau
    server mengaktifkan stats. Port API sekarang dicari menyeluruh
    (_xray_api_ports) + port umum script server 10085/10086 —
    dulu hanya satu pola 'listen': '127.0.0.1:port' yang dikenali
    sehingga port sering tidak ketemu, stats tak pernah terbaca,
    dan Terpakai tampil '-' walau user sedang online.
    Cache 30 detik supaya list member tidak meng-query berulang."""
    now = time.time()
    if now - _XRAY_STATS_CACHE["t"] < 30:
        return dict(_XRAY_STATS_CACHE["data"])
    data = {}

    def _query(port):
        out = subprocess.run(
            ["xray", "api", "stats",
             "--server=127.0.0.1:{}".format(port)],
            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            timeout=5).stdout.decode("utf-8", "ignore")
        got = {}
        names = re.findall(r'name:\s*"([^"]+)"', out)
        values = re.findall(r'value:\s*(\d+)', out)
        for name, val in zip(names, values):
            if "traffic" not in name:
                continue
            parts = name.split(">>>")
            if len(parts) < 2 or parts[0] != "user":
                continue
            try:
                val = int(val)
            except ValueError:
                continue
            u = parts[1].split("@")[0]
            got[u] = got.get(u, 0) + val
        return got

    try:
        ports = []
        try:
            with open(XRAY_CONFIG_FILE, "r", errors="ignore") as f:
                ports = _xray_api_ports(f.read())
        except Exception:
            ports = []
        # fallback port API yang paling umum dipakai script server
        for p in ("10085", "10086"):
            if p not in ports:
                ports.append(p)
        for port in ports:
            try:
                got = _query(port)
            except Exception:
                continue
            if got:
                data = got
                break
    except Exception:
        data = {}
    _XRAY_STATS_CACHE["t"] = now
    _XRAY_STATS_CACHE["data"] = data
    return dict(data)

def _who_login_epoch(toks):
    """Epoch waktu login dari token-token satu baris `who`.
    Didukung: '2026-11-02 10:30', '2026-11-02 10:30:45' (format
    coreutils/BusyBox modern) dan 'Nov 2 10:30' (format lama, tahun
    berjalan). Return None kalau tidak berhasil diparse."""
    if len(toks) < 4:
        return None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
        try:
            return DT.datetime.strptime(
                "{} {}".format(toks[2], toks[3]), fmt).timestamp()
        except ValueError:
            pass
    if len(toks) >= 5 and toks[2].isalpha():
        try:
            cand = DT.datetime.strptime(
                "{} {} {}".format(toks[2], toks[3], toks[4]), "%b %d %H:%M")
            return cand.replace(year=DT.date.today().year).timestamp()
        except ValueError:
            pass
    return None

def _ssh_sessions():
    """{user: {'count': jumlah sesi aktif, 'since': epoch login paling
    awal}} untuk SSH.
    Sesi dihitung dari `who` (OpenSSH & Dropbear) ditambah proses
    sshd untuk sesi tanpa PTY (sshd: user@notty yang tidak masuk
    `who`). Nilai tiap user diambil MAKSIMAL dari kedua sumber agar
    sesi yang sama tidak dihitung dua kali (sesi @pts muncul di
    `who` DAN di `ps aux`). 'since' dipakai durasi 'Sedang Aktif'
    (sejak sesi paling awal user yang masih aktif)."""
    who = {}
    try:
        out = subprocess.run(
            ["who"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            timeout=5).stdout.decode("utf-8", "ignore")
        for line in out.splitlines():
            tok = line.split()
            if not tok:
                continue
            ent = who.setdefault(
                tok[0], {"count": 0, "since": None, "ips": set()})
            ent["count"] += 1
            # IP sumber sesi: token dalam kurung di akhir baris,
            # contoh: 'budi pts/0 2026-11-02 10:30 (1.2.3.4)'.
            # '(:0)' / '(:1)' = display lokal, diabaikan.
            m_ip = re.search(r"\(([^)]+)\)\s*$", line.rstrip())
            if m_ip:
                ip = m_ip.group(1).strip()
                if ip and not ip.startswith(":"):
                    ent["ips"].add(ip)
            ts = _who_login_epoch(tok)
            if ts is not None and (ent["since"] is None or ts < ent["since"]):
                ent["since"] = ts
    except Exception:
        pass
    ps = {}
    try:
        out = subprocess.run(
            ["ps", "aux"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            timeout=5).stdout.decode("utf-8", "ignore")
        for m in re.finditer(r"sshd:\s+([A-Za-z0-9._-]+)@", out):
            ps[m.group(1)] = ps.get(m.group(1), 0) + 1
    except Exception:
        pass
    result = {}
    for u in (set(who) | set(ps)):
        result[u] = {
            "count": max(who.get(u, {}).get("count", 0), ps.get(u, 0)),
            "since": who.get(u, {}).get("since"),
            "ips": who.get(u, {}).get("ips") or set(),
        }
    return result

_SSH_LAST_CACHE = {"t": 0.0, "data": {}}

def _ssh_login_history():
    """{user: jumlah TOTAL login (buka koneksi)} dari riwayat wtmp
    (`last`). Setiap baris sesi = satu login, TERMASUK sesi lama
    yang sudah selesai dan yang masih berjalan (still logged in).
    Inilah sumber Total Login list member SSH (V7.3) - beda dari
    _ssh_sessions() yang hanya sesi AKTIF sekarang, dan beda dari
    IP Aktif yang menghitung IP berbeda. Cache 10 detik supaya
    render list member tidak menjalankan `last` berulang-ulang."""
    now = time.time()
    if now - _SSH_LAST_CACHE["t"] < 10:
        return dict(_SSH_LAST_CACHE["data"])
    counts = {}
    for args in (["last", "-w"], ["last"]):
        try:
            out = subprocess.run(
                args, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                timeout=10).stdout.decode("utf-8", "ignore")
        except Exception:
            continue
        if not out.strip() and args[-1] == "-w":
            continue          # varian -w mungkin tak didukung -> coba polos
        for line in out.splitlines():
            tok = line.split()
            if not tok or tok[0] in ("wtmp", "btmp"):
                continue      # lewati baris 'wtmp begins ...'
            counts[tok[0]] = counts.get(tok[0], 0) + 1
        break
    _SSH_LAST_CACHE["t"] = now
    _SSH_LAST_CACHE["data"] = counts
    return dict(counts)

def _ssh_login_counts():
    """{user: jumlah sesi login AKTIF sekarang} untuk SSH (dipakai
    status online). Total Login list member memakai
    _ssh_login_history() (setiap buka koneksi dari wtmp)."""
    return {u: v["count"] for u, v in _ssh_sessions().items()}

def _iso_ts_to_epoch(tok):
    """Token waktu '2026-11-02T10:30:45+07:00' / '2026-11-02 10:30' /
    '2026-11-02 10:30:45 +0700' -> epoch. Return None kalau gagal."""
    s = str(tok).strip().replace("T", " ")
    tz = None
    m = re.search(r"\s?([+-])(\d{2}):?(\d{2})$", s)
    if m:
        s = re.sub(r"\s?[+-]\d{2}:?\d{2}$", "", s).strip()
        off = int(m.group(2)) * 3600 + int(m.group(3)) * 60
        if m.group(1) == "-":
            off = -off
        tz = DT.timezone(DT.timedelta(seconds=off))
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M"):
        try:
            d = DT.datetime.strptime(s, fmt)
            return d.replace(tzinfo=tz).timestamp()
        except ValueError:
            continue
    return None

_ISO_TS_RE = re.compile(
    r"\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(?::\d{2})?(?:\s?[+-]\d{2}:?\d{2})?")

def _ssh_last_active(user):
    """Detik sejak sesi SSH TERAKHIR user selesai (dipakai teks
    'Terakhir Aktif X Lalu' untuk user SSH yang offline).
    Sumber: `last` (wtmp, OpenSSH & Dropbear). Return None kalau
    tidak ketahu (wtmp kosong / perintah last tidak tersedia)."""
    for args in (["last", "-n", "1", "-w", "--time-format", "iso", user],
                 ["last", "-n", "1", user]):
        try:
            out = subprocess.run(
                args, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                timeout=5).stdout.decode("utf-8", "ignore")
        except Exception:
            continue
        found = False
        for line in out.splitlines():
            tok = line.split()
            if not tok or tok[0] != user:
                continue   # lewati baris 'wtmp begins' dll
            found = True
            tss = [t for t in _ISO_TS_RE.findall(line)]
            eps = [e for e in map(_iso_ts_to_epoch, tss) if e is not None]
            if not eps:
                break
            if "still logged in" in line:
                end = eps[0]          # sesi masih jalan -> pakai login
            elif len(eps) >= 2:
                end = eps[1]          # timestamp ke-2 = waktu logout
            else:
                end = eps[0]          # 'gone - no logout' -> pakai login
            return max(time.time() - end, 0.0)
        if found:
            break   # sudah ketemu baris sesinya, tidak perlu varian kedua
    return None

# ============================================================
# === FORMAT DURASI AKTIF (Menit / Jam / Hari) ===
# ============================================================

def fmt_durasi_aktif(sec):
    """Detik -> teks durasi Indonesia: '5 Menit', '2 Jam 15 Menit',
    '1 Hari 3 Jam', '3 Hari'. Kurang dari 1 menit ->
    'Kurang dari 1 Menit'. Gagal parse -> '-'."""
    try:
        s = int(sec)
    except (TypeError, ValueError):
        return "-"
    if s < 0:
        s = 0
    if s < 60:
        return "Kurang dari 1 Menit"
    total_min = s // 60
    hari, rest = divmod(total_min, 1440)
    jam, menit = divmod(rest, 60)
    if hari:
        out = "{} Hari".format(hari)
        if jam:
            out += " {} Jam".format(jam)
        return out
    if jam:
        out = "{} Jam".format(jam)
        if menit:
            out += " {} Menit".format(menit)
        return out
    return "{} Menit".format(menit)

def fmt_terakhir_aktif(sec):
    """Detik sejak aktivitas terakhir -> 'Baru Saja' / '5 Menit Lalu' /
    '2 Jam 15 Menit Lalu' / '3 Hari Lalu'. Gagal parse -> '-'."""
    try:
        s = int(sec)
    except (TypeError, ValueError):
        return "-"
    if s < 0:
        s = 0
    if s < 60:
        return "Baru Saja"
    return "{} Lalu".format(fmt_durasi_aktif(s))

def _ssh_online_users():
    """Set user SSH yang sedang login (punya >= 1 sesi aktif)."""
    return set(_ssh_login_counts())

def _online_users(service):
    """Set username yang sedang dipakai (online) untuk satu layanan."""
    service = str(service).lower()
    if service == "ssh":
        return _ssh_online_users()
    return _xray_online_users()

def run_renew(cmd, timeout=180):
    """Jalankan perintah renew backend TANPA bergantung pada exit code.

    Script bot-renew-vme / bot-renew-vle / bot-renew-tro / bot-renew-ss
    selalu exit 1 walau berhasil (fungsi Sc_Credit diakhiri 'exit 1'),
    sehingga subprocess.check_output SELALU dianggap gagal dan bot
    menampilkan 'Gagal Renew' padahal akun sudah diperpanjang.
    Keberhasilan renew diverifikasi terpisah lewat get_member_info()
    (kondisi sistem), bukan dari exit code script."""
    try:
        p = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT, timeout=timeout)
        out = p.stdout.decode("utf-8", "ignore") if p.stdout else ""
    except Exception:
        out = ""
    return out

def render_member_page(service, page=1):
    """Render SATU halaman List Member -> (teks, tombol).
    Tiap member tampil rapih dalam box: Username, Status Online/Offline,
    Durasi Aktif (⏱ Sedang Aktif / Terakhir Aktif), Expired, Sisa Hari,
    Limit Kuota, Terpakai, Sisa Kuota.
    Tombol Next/Back untuk berpindah halaman."""
    service = str(service).lower()
    members = get_members(service)
    total = len(members)
    pages = (total + MEMBER_PER_PAGE - 1) // MEMBER_PER_PAGE if total else 1
    try:
        page = max(1, min(int(page), pages))
    except (TypeError, ValueError):
        page = 1
    title = _MEMBER_TITLES.get(service, "LIST MEMBER")
    n_online = sum(1 for m in members if m.get("online"))
    n_offline = total - n_online
    lines = [
        "**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**",
        "**┃   ⟨{}⟩**".format(title),
        "**┃   » Total : {} Akun**".format(total),
        "**┃   » Online : {} Akun**".format(n_online),
        "**┃   » Offline : {} Akun**".format(n_offline),
    ]
    if pages > 1:
        lines.append("**┃   » Halaman : {}/{}**".format(page, pages))
    lines.append("**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**")
    if total == 0:
        lines.append("**┃   Belum ada member**")
        lines.append("**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**")
        return "\n".join(lines) + "\n**» 🤖@zenviora_id**", [
            [Button.inline("‹ Main Menu ›", cbx("menu"), style="primary")]]
    chunk = members[(page - 1) * MEMBER_PER_PAGE: page * MEMBER_PER_PAGE]
    for m in chunk:
        if m.get("online"):
            status = "🟢 Online (Sedang Dipakai)"
            # durasi sedang aktif: 5 Menit / 2 Jam 15 Menit / 1 Hari 3 Jam
            aktif_line = "**┃   ⏱ Sedang Aktif :** `{}`".format(
                m.get("aktif") or "-")
        else:
            status = "⚪ Offline (Tidak Dipakai)"
            # kapan terakhir dipakai: 30 Menit Lalu / 3 Hari Lalu
            aktif_line = "**┃   ⏱ Terakhir Aktif :** `{}`".format(
                m.get("aktif") or "-")
        lines += [
            "**┃   👤 Username :** `{}`".format(m["user"]),
            "**┃   🔗 Limit IP :** `{} orang`".format(m.get("iplimit", "1")),
            "**┃   📲 Total Login :** `{} kali`".format(m.get("logins", 0)),
            "**┃   🌐 IP Aktif :** `{} IP`".format(m.get("ipaktif", 0)),
            "**┃   📶 Status :** {}".format(status),
            aktif_line,
            "**┃   📅 Expired :** `{}`".format(m["exp"]),
            "**┃   ⏳ Sisa Hari :** `{}`".format(m["days"]),
            "**┃   📦 Limit Kuota :** `{}`".format(m["limit"]),
            "**┃   📊 Terpakai :** `{}`".format(m["used"]),
            "**┃   ✅ Sisa Kuota :** `{}`".format(m["left"]),
            "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**",
        ]
    lines[-1] = "**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**"
    msg = "\n".join(lines) + "\n**» 🤖@zenviora_id**"
    # tombol navigasi halaman (Next / Back)
    cbp = _MEMBER_PAGE_CB[service]
    nav = []
    if page > 1:
        nav.append(Button.inline("‹ Back", cbx("{}-{}".format(cbp, page - 1)), style="primary"))
    if page < pages:
        nav.append(Button.inline("Next ›", cbx("{}-{}".format(cbp, page + 1)), style="primary"))
    buttons = []
    if nav:
        buttons.append(nav)
    buttons.append([Button.inline("‹ Main Menu ›", cbx("menu"), style="primary")])
    return msg, buttons

def get_global_stats(ssh=0, vmess=0, vless=0, trojan=0, shadowsocks=0):
    """Statistik global SEMUA layanan -> (total, online, offline).

    - total   : dijumlahkan dari counter yang sudah tampil di
      menu/start (SSH + Vmess + Vless + Trojan + Shadowsocks)
      supaya angkanya konsisten dengan tampilan.
    - online  : dihitung dari kondisi sistem (user SSH terlihat di
      `who`/proses sshd, user xray aktif di access.log dalam
      ONLINE_WINDOW_SEC detik terakhir).
    - offline : total - online.

    Dipakai menu utama & tampilan start:
      🌐 Global Total Akun / 🟢 Online / ⚪ Offline
    """
    try:
        total = (int(ssh or 0) + int(vmess or 0) + int(vless or 0)
                 + int(trojan or 0) + int(shadowsocks or 0))
    except (TypeError, ValueError):
        total = 0
    online = 0
    try:
        online += sum(1 for u in _passwd_users()
                      if u in _ssh_online_users())
        xray_on = _xray_online_users()
        for svc in ("vmess", "vless", "trojan", "shadowsocks"):
            online += sum(1 for u in _xray_expiry_map(svc)
                          if u in xray_on)
    except Exception:
        pass
    if online > total:
        total = online   # jaga konsistensi: Total >= Online
    return total, online, total - online

# ============================================================
# === SEMUA TAMPILAN PAKAI GAMBAR (KECUALI LOADING) ===
# ============================================================
# Patch dipasang SEKALI di sini. Method respond / reply / edit milik
# event Telethon diubah sehingga:
#
#   1. SEMUA tampilan (menu service, info akun, hasil trial, cek
#      login, pesan sukses, dll) otomatis dikirim sebagai FOTO
#      banner.jpg + caption -> tidak perlu mengubah script modul
#      satu per satu (start.py, ssh.py, vmess.py, dst tetap utuh).
#
#   2. Pesan LOADING ("Loading......", "Please Wait...",
#      "Wait.. Setting up an Account", dll) SELALU dikirim sebagai
#      TEKS BIASA TANPA GAMBAR. Kalau tombol ditekan pada pesan
#      bergambar, pesan loading dikirim sebagai pesan teks baru
#      sehingga gambarnya tidak ikut tampil.
#
#   3. Prompt input ("Username:", "Password:", ...) ikut dianggap
#      teks biasa supaya chat tidak penuh gambar banner saat input
#      data. Ubah BANNER_ON_PROMPTS = True kalau prompt juga mau
#      bergambar.
#
#   4. Pesan yang lebih panjang dari 1024 karakter (batas caption
#      foto Telegram) otomatis DIPECAH: bagian awal jadi caption foto
#      banner, sisanya dikirim sebagai pesan teks lanjutan. Pesan
#      edit yang terlalu panjang tetap diedit sebagai teks biasa.
#
# Kalau banner.jpg / BANNER= tidak ada, semua kembali ke perilaku
# lama (teks biasa) - tidak ada yang rusak.
# ============================================================

from telethon import events as _tg_events
from telethon.tl.custom.message import Message as _tg_message

BANNER_ON_PROMPTS = False   # True -> prompt "Username:" dll ikut pakai gambar
BANNER_MAX_CAPTION = 1024   # batas karakter caption foto Telegram

_LOADING_KEYWORDS = ("loading", "please wait", "memuat", "wait..",
                     "setting up", "tunggu")
# Pesan hasil PEMBUATAN AKUN & TRIAL dikirim sebagai TEKS BIASA
# (tanpa gambar) sesuai permintaan: judulnya selalu berakhiran
# "ACCOUNT⟩" (mis. "⟨VMESS ACCOUNT⟩") atau mengandung "TRIAL".
_NO_BANNER_KEYWORDS = ("account⟩", "trial")
_MD_STRIP_RE = re.compile(r"\*+|_+|`+")
_SEP_RE = re.compile(r"[━]{3,}|[─]{3,}")

def _banner_visible_len(text):
    """Perkiraan panjang teks setelah penanda markdown dihapus."""
    return len(_MD_STRIP_RE.sub("", text))

def _banner_wants_photo(text):
    """True kalau pesan ini bukan loading / bukan prompt input /
    bukan hasil pembuatan akun & trial.
    (Pesan yang terlalu panjang untuk caption foto ditangani
    _banner_split_text: dipecah jadi foto + lanjutan teks.)"""
    if not isinstance(text, str) or not text.strip():
        return False
    plain = _MD_STRIP_RE.sub("", text).strip().lower()
    # 0) hasil pembuatan akun & trial -> TANPA gambar (teks biasa)
    for kw in _NO_BANNER_KEYWORDS:
        if kw in plain:
            return False
    # 1) pesan loading -> tanpa gambar
    for kw in _LOADING_KEYWORDS:
        if kw in plain:
            return False
    # 2) prompt input pendek ("Username:", "Password :", ...) -> tanpa gambar
    if not BANNER_ON_PROMPTS and len(plain) <= 48 and plain.endswith(":"):
        return False
    return True

def _banner_split_text(text, limit=BANNER_MAX_CAPTION):
    """Pecah pesan yang lebih panjang dari batas caption foto.
    Pemotongan dilakukan di garis pemisah (━/─) dan hanya di luar
    blok kode ``` supaya format kedua bagian tetap rapi.
    Return (bagian_caption, bagian_lanjutan) atau None kalau tak perlu."""
    if _banner_visible_len(text) <= limit:
        return None
    lines = text.split("\n")
    acc = 0
    in_code = False
    last_sep = None   # potongan terakhir di garis pemisah
    last_any = None   # potongan terakhir di baris mana pun (seimbang)
    for i, line in enumerate(lines):
        if line.count("```") % 2 == 1:
            in_code = not in_code
        vl = len(_MD_STRIP_RE.sub("", line))
        if acc + vl > limit - 8:
            break
        acc += vl + 1
        if in_code:
            continue
        if _SEP_RE.search(line):
            last_sep = i + 1
        last_any = i + 1
    cut = last_sep or last_any
    if not cut or cut >= len(lines):
        return None
    part1 = "\n".join(lines[:cut]).rstrip()
    part2 = "\n".join(lines[cut:]).strip()
    if not part1 or not part2:
        return None
    return part1, part2

def _banner_media():
    """Ambil banner.jpg / URL BANNER (None kalau tidak ada)."""
    try:
        return get_banner_file()
    except Exception:
        return None

# ============================================================
# === AUTO DELETE PESAN "Loading......" ===
# ============================================================
# Semua pesan loading ("Loading......", "Please Wait...", dll)
# dilacak dan OTOMATIS DIHAPUS:
#   1. begitu pesan hasil (menu / sukses / gagal / prompt input)
#      dikirim di chat yang sama, dan
#   2. sebagai cadangan, setelah LOADING_TTL_SEC detik
#      (kalau operasinya menggantung / chat ditinggal).
# ============================================================

LOADING_TTL_SEC = 90
_LOADING_TRACK = {}   # {chat_id: set(message_id)}

def _is_loading_text(text):
    """True kalau teks ini adalah pesan loading."""
    if not isinstance(text, str) or not text.strip():
        return False
    plain = _MD_STRIP_RE.sub("", text).strip().lower()
    for kw in _LOADING_KEYWORDS:
        if kw in plain:
            return True
    return False

def _is_prompt_text(text):
    """True kalau teks ini prompt input pendek ("Username :", dll)."""
    if not isinstance(text, str) or not text.strip():
        return False
    plain = _MD_STRIP_RE.sub("", text).strip().lower()
    return len(plain) <= 48 and plain.endswith(":")

def _track_loading(msg):
    """Catat pesan loading yang baru terkirim + jadwalkan auto delete."""
    try:
        chat_id = msg.chat_id
        if chat_id is None or msg.id is None:
            return
        _LOADING_TRACK.setdefault(chat_id, set()).add(msg.id)
    except Exception:
        return

    async def _ttl_delete():
        # cadangan: hapus pesan loading yang tidak pernah diganti hasil
        try:
            await asyncio.sleep(LOADING_TTL_SEC)
            ids = _LOADING_TRACK.get(chat_id)
            if ids and msg.id in ids:
                ids.discard(msg.id)
                if not ids:
                    _LOADING_TRACK.pop(chat_id, None)
                await bot.delete_messages(chat_id, [msg.id])
        except Exception:
            pass

    try:
        bot.loop.create_task(_ttl_delete())
    except Exception:
        pass

async def _flush_loading(self):
    """Hapus semua pesan loading yang tercatat di chat ini (best effort).
    Dipanggil sebelum mengirim pesan hasil (bukan loading/prompt)."""
    try:
        chat_id = self.chat_id
    except Exception:
        chat_id = None
    if chat_id is None:
        return
    ids = _LOADING_TRACK.pop(chat_id, None)
    if not ids:
        return
    try:
        await self._client.delete_messages(chat_id, list(ids))
    except Exception:
        pass

def _banner_free_kwargs(kwargs):
    """True kalau pemanggil tidak sedang mengirim file/caption sendiri."""
    return "file" not in kwargs and "caption" not in kwargs

# ---- simpan method asli milik Telethon ----
_orig_cbq_respond = _tg_events.CallbackQuery.Event.respond
_orig_cbq_reply   = _tg_events.CallbackQuery.Event.reply
_orig_cbq_edit    = _tg_events.CallbackQuery.Event.edit
_orig_msg_respond = _tg_message.respond
_orig_msg_reply   = _tg_message.reply

# ---- patch respond/reply milik event tombol (CallbackQuery) ----
async def _cbq_respond_banner(self, *args, **kwargs):
    text = args[0] if args and isinstance(args[0], str) else None
    if text is not None and _banner_free_kwargs(kwargs):
        # pesan loading -> kirim sbg teks + lacak utk auto delete
        if _is_loading_text(text):
            result = await _orig_cbq_respond(self, text, *args[1:], **kwargs)
            _track_loading(result)
            return result
        # pesan hasil/final -> hapus sisa pesan loading sebelumnya
        if not _is_prompt_text(text):
            await _flush_loading(self)
        if _banner_wants_photo(text):
            media = _banner_media()
            if media:
                self._client.loop.create_task(self.answer())
                chat = await self.get_input_chat()
                try:
                    split = _banner_split_text(text)
                    if split:
                        # pesan panjang: caption foto = bagian awal,
                        # sisanya dikirim sebagai teks lanjutan
                        part1, part2 = split
                        kw1 = dict(kwargs)
                        kw1.pop("buttons", None)
                        await self._client.send_file(
                            chat, media, caption=part1, **kw1)
                        return await self._client.send_message(
                            chat, part2, **kwargs)
                    return await self._client.send_file(
                        chat, media, caption=text, **kwargs)
                except Exception:
                    return await self._client.send_message(
                        chat, text, *args[1:], **kwargs)
    return await _orig_cbq_respond(self, *args, **kwargs)

async def _cbq_reply_banner(self, *args, **kwargs):
    text = args[0] if args and isinstance(args[0], str) else None
    if text is not None and _banner_free_kwargs(kwargs):
        if _is_loading_text(text):
            result = await _orig_cbq_reply(self, text, *args[1:], **kwargs)
            _track_loading(result)
            return result
        if not _is_prompt_text(text):
            await _flush_loading(self)
        if _banner_wants_photo(text):
            media = _banner_media()
            if media:
                self._client.loop.create_task(self.answer())
                kwargs.setdefault("reply_to", self.query.msg_id)
                chat = await self.get_input_chat()
                try:
                    split = _banner_split_text(text)
                    if split:
                        part1, part2 = split
                        kw1 = dict(kwargs)
                        kw1.pop("buttons", None)
                        await self._client.send_file(
                            chat, media, caption=part1, **kw1)
                        return await self._client.send_message(
                            chat, part2, **kwargs)
                    return await self._client.send_file(
                        chat, media, caption=text, **kwargs)
                except Exception:
                    return await self._client.send_message(
                        chat, text, *args[1:], **kwargs)
    return await _orig_cbq_reply(self, *args, **kwargs)

# ---- patch respond/reply milik pesan teks (NewMessage) ----
async def _msg_respond_banner(self, *args, **kwargs):
    text = args[0] if args and isinstance(args[0], str) else None
    if text is not None and self._client and _banner_free_kwargs(kwargs):
        if _is_loading_text(text):
            result = await _orig_msg_respond(self, text, *args[1:], **kwargs)
            _track_loading(result)
            return result
        if not _is_prompt_text(text):
            await _flush_loading(self)
        if _banner_wants_photo(text):
            media = _banner_media()
            if media:
                chat = await self.get_input_chat()
                try:
                    split = _banner_split_text(text)
                    if split:
                        part1, part2 = split
                        kw1 = dict(kwargs)
                        kw1.pop("buttons", None)
                        await self._client.send_file(
                            chat, media, caption=part1, **kw1)
                        return await self._client.send_message(
                            chat, part2, **kwargs)
                    return await self._client.send_file(
                        chat, media, caption=text, **kwargs)
                except Exception:
                    pass
    return await _orig_msg_respond(self, *args, **kwargs)

async def _msg_reply_banner(self, *args, **kwargs):
    text = args[0] if args and isinstance(args[0], str) else None
    if text is not None and self._client and _banner_free_kwargs(kwargs):
        if _is_loading_text(text):
            result = await _orig_msg_reply(self, text, *args[1:], **kwargs)
            _track_loading(result)
            return result
        if not _is_prompt_text(text):
            await _flush_loading(self)
        if _banner_wants_photo(text):
            media = _banner_media()
            if media:
                kwargs.setdefault("reply_to", self.id)
                chat = await self.get_input_chat()
                try:
                    split = _banner_split_text(text)
                    if split:
                        part1, part2 = split
                        kw1 = dict(kwargs)
                        kw1.pop("buttons", None)
                        await self._client.send_file(
                            chat, media, caption=part1, **kw1)
                        return await self._client.send_message(
                            chat, part2, **kwargs)
                    return await self._client.send_file(
                        chat, media, caption=text, **kwargs)
                except Exception:
                    pass
    return await _orig_msg_reply(self, *args, **kwargs)

# ---- patch edit milik event tombol (CallbackQuery) ----
async def _cbq_edit_banner(self, *args, **kwargs):
    # pemanggil mengatur sendiri gambarnya (start.py / menu.py) -> asli
    if "file" in kwargs or "caption" in kwargs:
        # menu/start bergambar = pesan final -> hapus sisa loading
        await _flush_loading(self)
        return await _orig_cbq_edit(self, *args, **kwargs)

    text = args[0] if args and isinstance(args[0], str) else None
    if text is None:
        return await _orig_cbq_edit(self, *args, **kwargs)

    # === LOADING: teks saja, TANPA gambar + lacak utk auto delete ===
    # Jangan pakai event.edit() di sini: kalau pesan yang diedit sedang
    # bergambar, caption "Loading......" akan tampil BERSAMA gambar.
    # Kirim sebagai pesan teks baru; pesan ini nanti DIHAPUS OTOMATIS
    # begitu pesan hasil terkirim (atau setelah LOADING_TTL_SEC detik).
    if _is_loading_text(text):
        result = await _orig_cbq_respond(self, text, *args[1:], **kwargs)
        _track_loading(result)
        return result

    # === pesan hasil/final -> hapus sisa pesan loading sebelumnya ===
    if not _is_prompt_text(text):
        await _flush_loading(self)

    # === PROMPT / hasil create-trial: teks saja, TANPA gambar ===
    if not _banner_wants_photo(text):
        return await _orig_cbq_respond(self, text, *args[1:], **kwargs)

    media = _banner_media()
    if not media:
        # tidak ada banner -> perilaku lama (edit teks biasa)
        return await _orig_cbq_edit(self, *args, **kwargs)

    # cek pesan yang sedang diedit: sudah bergambar atau belum?
    orig = None
    try:
        orig = await self.get_message()
    except Exception:
        orig = None
    orig_photo = orig is not None and orig.photo

    # === pesan terlalu panjang untuk caption foto (mis. hasil cek login) ===
    # caption foto maksimal 1024 karakter -> kirim sebagai pesan teks biasa
    if _banner_split_text(text) is not None:
        if orig_photo:
            self._client.loop.create_task(self.answer())
            try:
                await self._client.delete_messages(
                    await self.get_input_chat(), [self.query.msg_id])
            except Exception:
                pass
            chat = await self.get_input_chat()
            try:
                return await self._client.send_message(
                    chat, text, *args[1:], **kwargs)
            except Exception:
                pass
        return await _orig_cbq_edit(self, *args, **kwargs)

    if orig_photo:
        # sudah berupa foto -> edit caption saja, banner tetap tampil
        return await _orig_cbq_edit(self, *args, **kwargs)

    # pesan lama bukan foto -> hapus lalu kirim ulang dengan banner
    self._client.loop.create_task(self.answer())
    try:
        await self._client.delete_messages(
            await self.get_input_chat(), [self.query.msg_id])
    except Exception:
        pass
    chat = await self.get_input_chat()
    try:
        return await self._client.send_file(
            chat, media, caption=text, **kwargs)
    except Exception:
        return await self._client.send_message(
            chat, text, *args[1:], **kwargs)

# ---- pasang patch (berlaku untuk semua modul, tanpa mengubah script) ----
_tg_events.CallbackQuery.Event.respond = _cbq_respond_banner
_tg_events.CallbackQuery.Event.reply   = _cbq_reply_banner
_tg_events.CallbackQuery.Event.edit    = _cbq_edit_banner
_tg_message.respond = _msg_respond_banner
_tg_message.reply   = _msg_reply_banner