#!/usr/bin/env python3
import os
import sqlite3
import math
import logging
import re
import requests
import datetime as DT
from telethon import TelegramClient

logging.basicConfig(level=logging.INFO)

# === Konstanta path
# Bisa dioverride lewat env var (berguna untuk testing), default tetap sama:
VAR_FILE = os.environ.get("PRIVATE_VAR_FILE", "/usr/bin/private/var.txt")
DB_FILE = os.environ.get("PRIVATE_DB_FILE", "/usr/bin/private/database.db")
SESSION_NAME = "private"  # nama file session Telethon
API_ID = 6                # ganti jika kamu pakai API ID sendiri
API_HASH = "eb06d4abfb49dc3eeb1aeb98ae0f581e"  # ganti jika pakai milikmu

uptime = DT.datetime.now()

# === Pastikan var.txt ada
os.makedirs(os.path.dirname(VAR_FILE), exist_ok=True)
if not os.path.exists(VAR_FILE):
    with open(VAR_FILE, "w") as f:
        f.write("# BOT_TOKEN=123456:ABC-xxx\n# ADMIN=11111111\n# DOMAIN=example.com\n"
                "# NICK=sg1  (opsional: nama panggilan bot, default = menu)\n")

# === Fungsi util: baca var.txt (dipakai modul lain juga)
def load_env_vars(path: str = VAR_FILE):
    result = {"BOT_TOKEN": None, "ADMINS": [], "DOMAIN": None, "BANNER": None, "NICK": None}
    if os.path.exists(path):
        with open(path, "r") as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, val = line.split("=", 1)
                key = key.strip()
                val = val.strip().strip('"').strip("'")
                if key == "BOT_TOKEN":
                    result["BOT_TOKEN"] = val
                elif key == "ADMIN":
                    result["ADMINS"].append(val)
                elif key == "DOMAIN":
                    result["DOMAIN"] = val
                elif key == "BANNER":
                    result["BANNER"] = val
                elif key == "NICK":
                    result["NICK"] = val
    return result

# === Pakai load_env_vars untuk inisialisasi global
env = load_env_vars()
BOT_TOKEN = env["BOT_TOKEN"]
ADMINS = env["ADMINS"]
DOMAIN = env["DOMAIN"]

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN belum diset di {}".format(VAR_FILE))

# ============================================================
# === NAMA PANGGILAN BOT (NICK) — konfigurasi di var.txt ===
# ============================================================
# Cara pakai: tambahkan satu baris di var.txt, contoh:  NICK=sg1
#   - Bot menu      : dipanggil dengan  .sg1  atau  /sg1
#   - Bot start     : dipanggil dengan  .startsg1  atau  /startsg1
#   - Semua tombol otomatis ikut ter-suffix, jadi 1 bot token (BOT_TOKEN)
#     bisa dipakai mengelola banyak server tanpa bentrok.
# Kalau NICK tidak ada / kosong / "menu", bot pakai panggilan default
#   .menu, /menu, .start, /start (perilaku lama).
# TIDAK PERLU LAGI edit kode modul satu per satu.
_raw_nick = str(env.get("NICK") or "").strip()
NICK = re.sub(r"[^a-zA-Z0-9_]", "", _raw_nick) or "menu"
SUFFIX = "" if NICK == "menu" else NICK

# (?:@\w+)? -> memungkinkan /perintah@NamaBot (Telegram kadang menambahkan
# @username saat command dipilih dari autocomplete, terutama di grup)
PATTERN_MENU = r"(?:\.{}|/{})(?:@\w+)?$".format(NICK, NICK)
PATTERN_START = r"(?:\.start{}|/start{})(?:@\w+)?$".format(SUFFIX, SUFFIX)
CB_MENU = NICK
CB_START = "start" + SUFFIX

def cbx(name):
    """Callback data dengan suffix NICK (bytes).
    Semua handler & tombol wajib pakai ini agar konsisten."""
    name = str(name)
    if name == "menu":
        return CB_MENU.encode()
    if name == "start":
        return CB_START.encode()
    return (name + SUFFIX).encode()

# === Inisialisasi DB + tabel
os.makedirs(os.path.dirname(DB_FILE), exist_ok=True)
conn = sqlite3.connect(DB_FILE)
c = conn.cursor()
c.execute("CREATE TABLE IF NOT EXISTS admin (user_id TEXT UNIQUE)")
conn.commit()

# === Sinkron admin dari var.txt ke DB
for admin_id in ADMINS:
    c.execute("INSERT OR IGNORE INTO admin (user_id) VALUES (?)", (str(admin_id),))
conn.commit()
conn.close()

# === Client Telethon
bot = TelegramClient(SESSION_NAME, API_ID, API_HASH).start(bot_token=BOT_TOKEN)

# === Helper DB
def get_db():
    x = sqlite3.connect(DB_FILE)
    x.row_factory = sqlite3.Row
    return x

def valid(id_):
    db = get_db()
    rows = db.execute("SELECT user_id FROM admin").fetchall()
    admin_list = [r[0] for r in rows]
    return "true" if str(id_) in admin_list else "false"

def convert_size(size_bytes):
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return f"{s} {size_name[i]}"

# ============================================================
# === Banner Info (mengikuti script pgetunnel) ===
# ============================================================
AUTH_URL = "https://raw.githubusercontent.com/Ris-Project/scriptpgetunnel/main/ip"
DAYS_ID = ("Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu")
MONTHS_ID = ("Januari", "Februari", "Maret", "April", "Mei", "Juni",
             "Juli", "Agustus", "September", "Oktober", "November", "Desember")

def _get_vps_ip():
    """Ambil IP publik VPS (sama seperti script: curl icanhazip.com)."""
    for url in ("https://api.ipify.org", "http://icanhazip.com"):
        try:
            ip = requests.get(url, timeout=5).text.strip()
            if ip:
                return ip
        except Exception:
            pass
    return ""

def get_expire_info(exp):
    """Format Exp Date spt script: 11-11-2026 9 Days Active / Lifetime / Unknown."""
    if exp == "lifetime":
        return "Lifetime"
    if not exp:
        return "Unknown"
    try:
        expd = DT.datetime.strptime(exp, "%Y-%m-%d").date()
    except Exception:
        return "Unknown"
    days = (expd - DT.date.today()).days
    status = "Expired" if days < 0 else ("Today Expire" if days == 0 else "Active")
    return "{} {} Days {}".format(expd.strftime("%d-%m-%Y"), days, status)

def get_banner_info():
    """Banner info akun script: Username, Exp Date, Version, Date, Time (WIB)."""
    ip = _get_vps_ip()
    username, exp = "Unknown", ""
    try:
        raw = requests.get(AUTH_URL, timeout=5).text
        for line in raw.splitlines():
            cols = line.split()
            if ip and ip in cols:
                username = cols[1] if len(cols) > 1 else "Unknown"
                exp = cols[2] if len(cols) > 2 else ""
                break
    except Exception:
        pass

    # Versi mengikuti script pgetunnel (/etc/pgetunnel/.version)
    ver = "1.0"
    try:
        with open("/etc/pgetunnel/.version") as f:
            parts = f.read().split()
            if len(parts) >= 2:
                ver = parts[1]
    except Exception:
        pass

    # Hari, tanggal, jam (otomatis - Indonesia, sama seperti script)
    now = DT.datetime.now()
    day = DAYS_ID[(now.weekday() + 1) % 7]
    date_id = "{}, {} {} {}".format(day, now.strftime("%d"), MONTHS_ID[now.month - 1], now.strftime("%Y"))
    time_id = "{} {}".format(now.strftime("%H:%M:%S"), now.strftime("%Z") or "WIB")

    return (
        "┏━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "┃   👤 Username : {}\n"
        "┃   ⏰ Exp Date : {}\n"
        "┃   🚀 Version  : {} (Auto)\n"
        "┃   📆 Date     : {}\n"
        "┃   🕒 Time     : {}\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━━━┛"
    ).format(username, get_expire_info(exp), ver, date_id, time_id)

# Alias agar pemanggilan banner_info() (mis. di modules/start.py, modules/menu.py
# dan modul dist) tetap berfungsi
banner_info = get_banner_info

# ============================================================
# === Banner Menu (gambar) ===
# ============================================================
BANNER_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "banner.jpg")

def get_banner_file():
    """Gambar banner menu: utamakan file banner.jpg di folder bot,
    kalau tidak ada pakai URL dari BANNER= di var.txt, kalau keduanya
    tidak ada kembalikan None (menu terkirim sebagai teks biasa)."""
    try:
        if os.path.exists(BANNER_FILE):
            return BANNER_FILE
    except Exception:
        pass
    return load_env_vars().get("BANNER") or None