#!/usr/bin/env python3
import os
import asyncio
import time
import sqlite3
import math
import logging
import re
import subprocess
import requests
import datetime as DT
from telethon import TelegramClient, Button

logging.basicConfig(level=logging.INFO)

# === Konstanta path
# Bisa dioverride lewat env var (berguna untuk testing), default tetap sama:
VAR_FILE = os.environ.get("PRIVATE_VAR_FILE", "/usr/bin/private/var.txt")
DB_FILE = os.environ.get("PRIVATE_DB_FILE", "/usr/bin/private/database.db")
SESSION_NAME = "private"  # nama file session Telethon
API_ID = 6                # ganti jika kamu pakai API ID sendiri
API_HASH = "eb06d4abfb49dc3eeb1aeb98ae0f581e"  # ganti jika pakai milikmu

uptime = DT.datetime.now()

# === Pastikan var.txt ada
os.makedirs(os.path.dirname(VAR_FILE), exist_ok=True)
if not os.path.exists(VAR_FILE):
    with open(VAR_FILE, "w") as f:
        f.write("# BOT_TOKEN=123456:ABC-xxx\n# ADMIN=11111111\n# DOMAIN=example.com\n"
                "# NICK=sg1  (opsional: nama panggilan bot, default = menu)\n")

# === Fungsi util: baca var.txt (dipakai modul lain juga)
def load_env_vars(path: str = VAR_FILE):
    result = {"BOT_TOKEN": None, "ADMINS": [], "DOMAIN": None, "BANNER": None, "NICK": None}
    if os.path.exists(path):
        with open(path, "r") as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, val = line.split("=", 1)
                key = key.strip()
                val = val.strip().strip('"').strip("'")
                if key == "BOT_TOKEN":
                    result["BOT_TOKEN"] = val
                elif key == "ADMIN":
                    result["ADMINS"].append(val)
                elif key == "DOMAIN":
                    result["DOMAIN"] = val
                elif key == "BANNER":
                    result["BANNER"] = val
                elif key == "NICK":
                    result["NICK"] = val
    return result

# === Pakai load_env_vars untuk inisialisasi global
env = load_env_vars()
BOT_TOKEN = env["BOT_TOKEN"]
ADMINS = env["ADMINS"]
DOMAIN = env["DOMAIN"]

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN belum diset di {}".format(VAR_FILE))

# ============================================================
# === NAMA PANGGILAN BOT (NICK) — konfigurasi di var.txt ===
# ============================================================
# Cara pakai: tambahkan satu baris di var.txt, contoh:  NICK=sg1
#   - Bot menu      : dipanggil dengan  .sg1  atau  /sg1
#   - Bot start     : dipanggil dengan  .startsg1  atau  /startsg1
#   - Semua tombol otomatis ikut ter-suffix, jadi 1 bot token (BOT_TOKEN)
#     bisa dipakai mengelola banyak server tanpa bentrok.
# Kalau NICK tidak ada / kosong / "menu", bot pakai panggilan default
#   .menu, /menu, .start, /start (perilaku lama).
# TIDAK PERLU LAGI edit kode modul satu per satu.
_raw_nick = str(env.get("NICK") or "").strip()
NICK = re.sub(r"[^a-zA-Z0-9_]", "", _raw_nick) or "menu"
SUFFIX = "" if NICK == "menu" else NICK

# (?:@\w+)? -> memungkinkan /perintah@NamaBot (Telegram kadang menambahkan
# @username saat command dipilih dari autocomplete, terutama di grup)
PATTERN_MENU = r"(?:\.{}|/{})(?:@\w+)?$".format(NICK, NICK)
PATTERN_START = r"(?:\.start{}|/start{})(?:@\w+)?$".format(SUFFIX, SUFFIX)
CB_MENU = NICK
CB_START = "start" + SUFFIX

def cbx(name):
    """Callback data dengan suffix NICK (bytes).
    Semua handler & tombol wajib pakai ini agar konsisten."""
    name = str(name)
    if name == "menu":
        return CB_MENU.encode()
    if name == "start":
        return CB_START.encode()
    return (name + SUFFIX).encode()

# === Inisialisasi DB + tabel
os.makedirs(os.path.dirname(DB_FILE), exist_ok=True)
conn = sqlite3.connect(DB_FILE)
c = conn.cursor()
c.execute("CREATE TABLE IF NOT EXISTS admin (user_id TEXT UNIQUE)")
conn.commit()

# === Sinkron admin dari var.txt ke DB
for admin_id in ADMINS:
    c.execute("INSERT OR IGNORE INTO admin (user_id) VALUES (?)", (str(admin_id),))
conn.commit()
conn.close()

# === Client Telethon
bot = TelegramClient(SESSION_NAME, API_ID, API_HASH).start(bot_token=BOT_TOKEN)

# === Helper DB
def get_db():
    x = sqlite3.connect(DB_FILE)
    x.row_factory = sqlite3.Row
    return x

def valid(id_):
    db = get_db()
    rows = db.execute("SELECT user_id FROM admin").fetchall()
    admin_list = [r[0] for r in rows]
    return "true" if str(id_) in admin_list else "false"

def convert_size(size_bytes):
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return f"{s} {size_name[i]}"

# ============================================================
# === Banner Info (mengikuti script pgetunnel) ===
# ============================================================
AUTH_URL = "https://raw.githubusercontent.com/Ris-Project/scriptpgetunnel/main/ip"
DAYS_ID = ("Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu")
MONTHS_ID = ("Januari", "Februari", "Maret", "April", "Mei", "Juni",
             "Juli", "Agustus", "September", "Oktober", "November", "Desember")

def _get_vps_ip():
    """Ambil IP publik VPS (sama seperti script: curl icanhazip.com)."""
    for url in ("https://api.ipify.org", "http://icanhazip.com"):
        try:
            ip = requests.get(url, timeout=5).text.strip()
            if ip:
                return ip
        except Exception:
            pass
    return ""

def get_expire_info(exp):
    """Format Exp Date spt script: 11-11-2026 9 Days Active / Lifetime / Unknown."""
    if exp == "lifetime":
        return "Lifetime"
    if not exp:
        return "Unknown"
    try:
        expd = DT.datetime.strptime(exp, "%Y-%m-%d").date()
    except Exception:
        return "Unknown"
    days = (expd - DT.date.today()).days
    status = "Expired" if days < 0 else ("Today Expire" if days == 0 else "Active")
    return "{} {} Days {}".format(expd.strftime("%d-%m-%Y"), days, status)

def get_banner_info():
    """Banner info akun: Username, Exp Date, Date, Time, Version (WIB).
    Urutan & spasi tunggal mengikuti contoh agar rapih di caption foto."""
    ip = _get_vps_ip()
    username, exp = "Unknown", ""
    try:
        raw = requests.get(AUTH_URL, timeout=5).text
        for line in raw.splitlines():
            cols = line.split()
            if ip and ip in cols:
                username = cols[1] if len(cols) > 1 else "Unknown"
                exp = cols[2] if len(cols) > 2 else ""
                break
    except Exception:
        pass

    # Versi mengikuti script pgetunnel (/etc/pgetunnel/.version)
    ver = "1.0"
    try:
        with open("/etc/pgetunnel/.version") as f:
            parts = f.read().split()
            if len(parts) >= 2:
                ver = parts[1]
    except Exception:
        pass

    # Hari, tanggal, jam (otomatis - Indonesia, sama seperti script)
    now = DT.datetime.now()
    day = DAYS_ID[(now.weekday() + 1) % 7]
    date_id = "{}, {} {} {}".format(day, now.strftime("%d"), MONTHS_ID[now.month - 1], now.strftime("%Y"))
    time_id = "{} {}".format(now.strftime("%H:%M:%S"), now.strftime("%Z") or "WIB")

    return (
        "┏━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "┃   👤 Username : {}\n"
        "┃   ⏰ Exp Date : {}\n"
        "┃   📆 Date : {}\n"
        "┃   🕒 Time : {}\n"
        "┃   🚀 Version : {} (Auto)\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━━━┛"
    ).format(username, get_expire_info(exp), date_id, time_id, ver)

# Alias agar pemanggilan banner_info() (mis. di modules/start.py, modules/menu.py
# dan modul dist) tetap berfungsi
banner_info = get_banner_info

# ============================================================
# === Banner Menu (gambar) ===
# ============================================================
BANNER_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "banner.jpg")

def get_banner_file():
    """Gambar banner menu: utamakan file banner.jpg di folder bot,
    kalau tidak ada pakai URL dari BANNER= di var.txt, kalau keduanya
    tidak ada kembalikan None (menu terkirim sebagai teks biasa)."""
    try:
        if os.path.exists(BANNER_FILE):
            return BANNER_FILE
    except Exception:
        pass
    return load_env_vars().get("BANNER") or None

# ============================================================
# === INFO MEMBER & KUOTA (SSH, VMESS, VLESS, TROJAN, SHADOWSOCKS) ===
# ============================================================
# Sumber data di server (mengikuti script pgetunnel):
#   SSH         : user = /etc/passwd (UID >= 1000),
#                 expired = "chage -l <user>",
#                 limit kuota = /etc/ssh/<user>            (byte),
#                 terpakai    = /etc/limit/ssh/<user>      (byte)
#   vmess/vless : user + expired = penanda di /etc/xray/config.json
#   /trojan/ss    ("### user tgl" / "#& user tgl" / "#! user tgl"
#                 / "#@& user tgl"),
#                 limit kuota = /etc/<layanan>/<user>       (byte),
#                 terpakai    = /etc/limit/<layanan>/<user> (byte)
#
# Dipakai untuk:
#   1. Pesan sukses RENEW  -> diperpanjang X hari, masa aktif
#      sekarang Y hari, tanggal expired baru (lihat modul ssh.py,
#      vmess.py, vless.py, trojan.py, shadowsocks.py).
#   2. Tombol LIST MEMBER  -> tiap member tampil rapih: username,
#      expired, sisa hari, limit kuota, terpakai, sisa kuota,
#      lengkap dengan tombol Next/Back per halaman.
# ============================================================

MEMBER_PER_PAGE = 4   # jumlah akun per halaman list member

PASSWD_FILE = "/etc/passwd"
XRAY_CONFIG_FILE = "/etc/xray/config.json"

_QUOTA_DIRS = {
    "ssh": "/etc/ssh",
    "vmess": "/etc/vmess",
    "vless": "/etc/vless",
    "trojan": "/etc/trojan",
    "shadowsocks": "/etc/shadowsocks",
}
_LIMIT_DIRS = {
    "ssh": "/etc/limit/ssh",
    "vmess": "/etc/limit/vmess",
    "vless": "/etc/limit/vless",
    "trojan": "/etc/limit/trojan",
    "shadowsocks": "/etc/limit/shadowsocks",
}
_XRAY_MARKERS = {
    "vmess": "###",
    "vless": "#&",
    "trojan": "#!",
    "shadowsocks": "#@&",
}
_MEMBER_TITLES = {
    "ssh": "LIST MEMBER SSH",
    "vmess": "LIST MEMBER VMESS",
    "vless": "LIST MEMBER VLESS",
    "trojan": "LIST MEMBER TROJAN",
    "shadowsocks": "LIST MEMBER SHADOWSOCKS",
}
_MEMBER_PAGE_CB = {
    "ssh": "listssh",
    "vmess": "listvm",
    "vless": "listvl",
    "trojan": "listtr",
    "shadowsocks": "listss",
}

def fmt_quota(num_bytes, zero="Unlimited"):
    """Format byte jadi '300 GB' / '500 MB'. 0/negatif -> zero
    (default 'Unlimited', untuk terpakai pakai zero='0 B')."""
    try:
        b = int(num_bytes)
    except (TypeError, ValueError):
        return zero
    if b <= 0:
        return zero
    if b >= 1024 ** 3:
        v = b / 1024 ** 3
        return "{} GB".format(int(v) if v == int(v) else round(v, 2))
    if b >= 1024 ** 2:
        v = b / 1024 ** 2
        return "{} MB".format(int(v) if v == int(v) else round(v, 2))
    if b >= 1024:
        return "{} KB".format(int(round(b / 1024.0)))
    return "{} B".format(b)

def _parse_exp_date(text):
    """Parse tanggal expired -> datetime.date / 'lifetime' / None.
    Format yang didukung: 2026-11-11 (config.json & db xray),
    'Nov 11, 2026' (chage), '11 Nov, 2026' (/etc/ssh/.ssh.db)."""
    if text is None:
        return None
    raw = " ".join(str(text).strip().split())
    if not raw:
        return None
    if raw.lower() in ("never", "lifetime", "unlimited"):
        return "lifetime"
    for fmt in ("%Y-%m-%d", "%b %d, %Y", "%d %b, %Y", "%Y/%m/%d", "%d-%m-%Y"):
        try:
            return DT.datetime.strptime(raw, fmt).date()
        except ValueError:
            continue
    return None

def _read_int_file(path):
    """Baca file berisi satu angka (byte kuota dll) -> int (0 kalau gagal)."""
    try:
        with open(path, "r") as f:
            tok = f.read().split()
            return int(tok[0]) if tok and tok[0].isdigit() else 0
    except Exception:
        return 0

def _read_ip_limit(path):
    """Baca limit IP dari file (ambil angka pertama, default 1)."""
    try:
        with open(path, "r") as f:
            for tok in f.read().split():
                if tok.isdigit():
                    return tok
    except Exception:
        pass
    return "1"

def _passwd_users():
    """Daftar user SSH (UID >= 1000, tanpa nobody) dari /etc/passwd."""
    users = []
    try:
        with open(PASSWD_FILE, "r") as f:
            for line in f:
                cols = line.split(":")
                if len(cols) < 3:
                    continue
                name = cols[0].strip()
                if not name or name == "nobody":
                    continue
                try:
                    if int(cols[2]) >= 1000:
                        users.append(name)
                except ValueError:
                    continue
    except Exception:
        pass
    return users

def _ssh_expired(user):
    """(tanggal_expired, sisa_hari) akun SSH via chage -l.
    Contoh hasil: ('11-11-2026', '9 Hari') / ('Lifetime', 'Lifetime')."""
    try:
        out = subprocess.check_output(
            ["chage", "-l", str(user)],
            stderr=subprocess.DEVNULL, timeout=10).decode("utf-8", "ignore")
    except Exception:
        return "Unknown", "-"
    for line in out.splitlines():
        if "Account expires" in line and ":" in line:
            raw = line.split(":", 1)[1].strip()
            d = _parse_exp_date(raw)
            if d == "lifetime":
                return "Lifetime", "Lifetime"
            if d is None:
                return (raw or "Unknown"), "-"
            days = (d - DT.date.today()).days
            return d.strftime("%d-%m-%Y"), ("{} Hari".format(days) if days >= 0 else "Expired")
    return "Unknown", "-"

def _xray_expiry_map(service):
    """Peta {username: tanggal_expired} dari penanda di config.json."""
    result = {}
    marker = _XRAY_MARKERS.get(service, "")
    if not marker:
        return result
    try:
        with open(XRAY_CONFIG_FILE, "r", errors="ignore") as f:
            for line in f:
                parts = line.strip().split()
                if parts and parts[0] == marker and len(parts) >= 2:
                    result[parts[1]] = parts[2] if len(parts) > 2 else ""
    except Exception:
        pass
    return result

def get_members(service):
    """Semua member satu layanan + expired, sisa hari, dan kuota.
    Dipakai tombol List Member di tiap modul service."""
    service = str(service).lower()
    today = DT.date.today()
    if service == "ssh":
        exp_map = None                       # SSH: expired via chage per user
        users = sorted(_passwd_users())      # urut abjad biar rapih konsisten
    else:
        exp_map = _xray_expiry_map(service)
        users = sorted(exp_map)
    quota_dir = _QUOTA_DIRS.get(service)
    limit_dir = _LIMIT_DIRS.get(service)
    online_set = _online_users(service)   # status sedang dipakai / tidak
    # Total Login: jumlah sesi/IP client yang sedang dipakai akun
    if service == "ssh":
        login_map = _ssh_login_counts()
    else:
        login_map = {u: len(s) for u, s in _xray_login_ips().items()}
    members = []
    for user in users:
        if service == "ssh":
            exp_str, days_str = _ssh_expired(user)
        else:
            d = _parse_exp_date(exp_map.get(user, ""))
            if d == "lifetime":
                exp_str, days_str = "Lifetime", "Lifetime"
            elif d is None:
                exp_str, days_str = "Unknown", "-"
            else:
                days = (d - today).days
                exp_str = d.strftime("%d-%m-%Y")
                days_str = "{} Hari".format(days) if days >= 0 else "Expired"
        limit_b = _read_int_file(os.path.join(quota_dir, user)) if quota_dir else 0
        used_b = _read_int_file(os.path.join(limit_dir, user)) if limit_dir else 0
        if limit_b > 0:
            left_s = fmt_quota(max(limit_b - used_b, 0), zero="0 B")
            limit_s = fmt_quota(limit_b)
        else:
            left_s = "Unlimited"
            limit_s = "Unlimited"
        members.append({
            "user": user,
            "exp": exp_str,
            "days": days_str,
            "limit": limit_s,
            "used": fmt_quota(used_b, zero="0 B"),
            "left": left_s,
            "online": user in online_set,
            "iplimit": _read_ip_limit(
                os.path.join(limit_dir, "ip", user)) if limit_dir else "1",
            "logins": login_map.get(user, 0),
        })
    return members

def get_member_info(service, user):
    """Info SATU akun dari sistem (dipakai pesan sukses renew):
    tanggal expired baru + sisa hari setelah diperpanjang."""
    service = str(service).lower()
    info = {"exp": "Unknown", "days": "-", "quota": "Unlimited", "iplimit": "1"}
    if service == "ssh":
        info["exp"], info["days"] = _ssh_expired(user)
        info["quota"] = fmt_quota(_read_int_file(
            os.path.join(_QUOTA_DIRS["ssh"], user)))
        info["iplimit"] = _read_ip_limit(
            os.path.join(_LIMIT_DIRS["ssh"], "ip", user))
    else:
        d = _parse_exp_date(_xray_expiry_map(service).get(user, ""))
        if d == "lifetime":
            info["exp"], info["days"] = "Lifetime", "Lifetime"
        elif d is not None:
            days = (d - DT.date.today()).days
            info["exp"] = d.strftime("%d-%m-%Y")
            info["days"] = "{} Hari".format(days) if days >= 0 else "Expired"
        info["quota"] = fmt_quota(_read_int_file(
            os.path.join(_QUOTA_DIRS[service], user)))
        info["iplimit"] = _read_ip_limit(
            os.path.join(_LIMIT_DIRS[service], "ip", user))
    return info

# ============================================================
# === STATUS ONLINE / OFFLINE MEMBER (Sedang Dipakai / Tidak) ===
# ============================================================
# - SSH         : user terlihat di output `who` (OpenSSH & Dropbear)
#                 dan di judul proses sshd ("sshd: user@notty").
# - vmess/vless/trojan/shadowsocks : email user muncul di log
#   /var/log/xray/access.log dalam ONLINE_WINDOW_SEC detik
#   terakhir (logika yang sama dengan script cek-ws/cek-vless/
#   cek-tr/cek-ss).
#
# Dipakai tombol LIST MEMBER di semua layanan:
#   🟢 Online  (Sedang Dipakai)
#   ⚪ Offline (Tidak Dipakai)
# ============================================================

ONLINE_WINDOW_SEC = 300   # aktivitas dalam N detik terakhir = Online
XRAY_ACCESS_LOG = os.environ.get("PRIVATE_XRAY_LOG", "/var/log/xray/access.log")
_ONLINE_TAIL_BYTES = 512 * 1024   # baca maksimal 512 KB terakhir dari log
_EMAIL_RE = re.compile(r"email:\s*([^\s\[\]]+)")
_XRAY_ACT_CACHE = {"t": 0.0, "online": frozenset(), "ips": {}}

# pola alamat client di access.log: '1.2.3.4:5678' atau '[::1]:44858'
_ADDR_RE = re.compile(
    r"^(\d{1,3}\.){3}\d{1,3}(:\d+)?$|^\[[0-9A-Fa-f:.]+\](:\d+)?$")

def _client_addr(tok):
    """'1.2.3.4:5678' / '[::1]:44858' -> '1.2.3.4' / '::1'.
    Return None kalau token bukan alamat IP."""
    tok = str(tok).strip()
    if not _ADDR_RE.match(tok):
        return None
    if tok.startswith("["):
        end = tok.find("]")
        return tok[1:end] if end > 1 else None
    return tok.rsplit(":", 1)[0]

def _tim2sec(arg):
    """'HH:MM:SS' (boleh ada pecahan '.xxx') -> total detik."""
    total = 0
    for part in str(arg).split(".")[0].split(":"):
        part = part.strip()
        if not part.isdigit():
            return -1
        total = total * 60 + int(part)
    return total

def _xray_activity():
    """Aktivitas xray dari access.log dalam ONLINE_WINDOW_SEC detik
    terakhir (sama seperti script cek-ws). Return (online, ips):
      - online : set username yang punya aktivitas terakhir
      - ips    : {username: set(ip client)} -> dipakai Total Login
        (jumlah IP client berbeda yang dipakai login akun itu).
    Hasil di-cache 10 detik supaya 5 layanan tidak membaca log
    berulang-ulang."""
    now = time.time()
    if now - _XRAY_ACT_CACHE["t"] < 10:
        return (set(_XRAY_ACT_CACHE["online"]),
                {u: set(s) for u, s in _XRAY_ACT_CACHE["ips"].items()})
    online = set()
    ips = {}
    partial = False
    try:
        with open(XRAY_ACCESS_LOG, "rb") as f:
            try:
                f.seek(-_ONLINE_TAIL_BYTES, os.SEEK_END)
                partial = True   # posisi awal bisa di tengah baris
            except OSError:
                f.seek(0)        # file kecil -> dibaca utuh dari awal
            blob = f.read().decode("utf-8", "ignore")
        lines = blob.split("\n")
        if partial and lines:
            lines = lines[1:]    # buang baris pertama (kemungkinan terpotong)
    except Exception:
        lines = []
    now_sec = _tim2sec(time.strftime("%H:%M:%S"))
    for line in lines:
        if "email" not in line:
            continue
        parts = line.strip().split()
        if len(parts) < 2:
            continue
        tsec = _tim2sec(parts[1])
        if tsec < 0:
            continue
        diff = now_sec - tsec
        if diff < 0 or diff > ONLINE_WINDOW_SEC:
            # diff < 0 -> log hari sebelumnya (lewat tengah malam)
            continue
        m = _EMAIL_RE.search(line)
        if not m:
            continue
        user = m.group(1).split("@")[0]
        online.add(user)
        # Alamat client: token pertama yang berbentuk IP:port.
        # Token setelah label 'remote:' / 'local:' adalah alamat
        # tujuan server, jadi dilewati.
        addr = None
        prev = ""
        for tok in parts[2:]:
            if prev.lower() in ("remote:", "local:"):
                prev = tok
                continue
            addr = _client_addr(tok)
            if addr:
                break
            prev = tok
        if addr:
            ips.setdefault(user, set()).add(addr)
    _XRAY_ACT_CACHE["t"] = now
    _XRAY_ACT_CACHE["online"] = frozenset(online)
    _XRAY_ACT_CACHE["ips"] = ips
    return online, {u: set(s) for u, s in ips.items()}

def _xray_online_users():
    """Set username xray yang punya aktivitas terakhir di access.log
    dalam ONLINE_WINDOW_SEC detik (sama seperti script cek-ws)."""
    return set(_xray_activity()[0])

def _xray_login_ips():
    """{username: set(ip client)} xray dalam window ONLINE detik
    terakhir. Jumlah IP = Total Login akun tsb."""
    return _xray_activity()[1]

def _ssh_login_counts():
    """{user: jumlah sesi login aktif} untuk SSH.
    Sesi dihitung dari `who` (OpenSSH & Dropbear) ditambah proses
    sshd untuk sesi tanpa PTY (sshd: user@notty yang tidak masuk
    `who`). Nilai tiap user diambil MAKSIMAL dari kedua sumber agar
    sesi yang sama tidak dihitung dua kali (sesi @pts muncul di
    `who` DAN di `ps aux`)."""
    who = {}
    try:
        out = subprocess.run(
            ["who"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            timeout=5).stdout.decode("utf-8", "ignore")
        for line in out.splitlines():
            tok = line.split()
            if tok:
                who[tok[0]] = who.get(tok[0], 0) + 1
    except Exception:
        pass
    ps = {}
    try:
        out = subprocess.run(
            ["ps", "aux"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            timeout=5).stdout.decode("utf-8", "ignore")
        for m in re.finditer(r"sshd:\s+([A-Za-z0-9._-]+)@", out):
            ps[m.group(1)] = ps.get(m.group(1), 0) + 1
    except Exception:
        pass
    return {u: max(who.get(u, 0), ps.get(u, 0)) for u in (set(who) | set(ps))}

def _ssh_online_users():
    """Set user SSH yang sedang login (punya >= 1 sesi aktif)."""
    return set(_ssh_login_counts())

def _online_users(service):
    """Set username yang sedang dipakai (online) untuk satu layanan."""
    service = str(service).lower()
    if service == "ssh":
        return _ssh_online_users()
    return _xray_online_users()

def run_renew(cmd, timeout=180):
    """Jalankan perintah renew backend TANPA bergantung pada exit code.

    Script bot-renew-vme / bot-renew-vle / bot-renew-tro / bot-renew-ss
    selalu exit 1 walau berhasil (fungsi Sc_Credit diakhiri 'exit 1'),
    sehingga subprocess.check_output SELALU dianggap gagal dan bot
    menampilkan 'Gagal Renew' padahal akun sudah diperpanjang.
    Keberhasilan renew diverifikasi terpisah lewat get_member_info()
    (kondisi sistem), bukan dari exit code script."""
    try:
        p = subprocess.run(cmd, shell=True, stdout=subprocess.PIPE,
                           stderr=subprocess.STDOUT, timeout=timeout)
        out = p.stdout.decode("utf-8", "ignore") if p.stdout else ""
    except Exception:
        out = ""
    return out

def render_member_page(service, page=1):
    """Render SATU halaman List Member -> (teks, tombol).
    Tiap member tampil rapih dalam box: Username, Status Online/Offline,
    Expired, Sisa Hari, Limit Kuota, Terpakai, Sisa Kuota.
    Tombol Next/Back untuk berpindah halaman."""
    service = str(service).lower()
    members = get_members(service)
    total = len(members)
    pages = (total + MEMBER_PER_PAGE - 1) // MEMBER_PER_PAGE if total else 1
    try:
        page = max(1, min(int(page), pages))
    except (TypeError, ValueError):
        page = 1
    title = _MEMBER_TITLES.get(service, "LIST MEMBER")
    n_online = sum(1 for m in members if m.get("online"))
    n_offline = total - n_online
    lines = [
        "**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**",
        "**┃   ⟨{}⟩**".format(title),
        "**┃   » Total : {} Akun**".format(total),
        "**┃   » Online : {} Akun**".format(n_online),
        "**┃   » Offline : {} Akun**".format(n_offline),
    ]
    if pages > 1:
        lines.append("**┃   » Halaman : {}/{}**".format(page, pages))
    lines.append("**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**")
    if total == 0:
        lines.append("**┃   Belum ada member**")
        lines.append("**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**")
        return "\n".join(lines) + "\n**» 🤖@zenviora_id**", [
            [Button.inline("‹ Main Menu ›", cbx("menu"))]]
    chunk = members[(page - 1) * MEMBER_PER_PAGE: page * MEMBER_PER_PAGE]
    for m in chunk:
        if m.get("online"):
            status = "🟢 Online (Sedang Dipakai)"
        else:
            status = "⚪ Offline (Tidak Dipakai)"
        lines += [
            "**┃   👤 Username :** `{}`".format(m["user"]),
            "**┃   🔗 Limit IP :** `{} orang`".format(m.get("iplimit", "1")),
            "**┃   📲 Total Login :** `{} orang`".format(m.get("logins", 0)),
            "**┃   📶 Status :** {}".format(status),
            "**┃   📅 Expired :** `{}`".format(m["exp"]),
            "**┃   ⏳ Sisa Hari :** `{}`".format(m["days"]),
            "**┃   📦 Limit Kuota :** `{}`".format(m["limit"]),
            "**┃   📊 Terpakai :** `{}`".format(m["used"]),
            "**┃   ✅ Sisa Kuota :** `{}`".format(m["left"]),
            "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**",
        ]
    lines[-1] = "**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**"
    msg = "\n".join(lines) + "\n**» 🤖@zenviora_id**"
    # tombol navigasi halaman (Next / Back)
    cbp = _MEMBER_PAGE_CB[service]
    nav = []
    if page > 1:
        nav.append(Button.inline("‹ Back", cbx("{}-{}".format(cbp, page - 1))))
    if page < pages:
        nav.append(Button.inline("Next ›", cbx("{}-{}".format(cbp, page + 1))))
    buttons = []
    if nav:
        buttons.append(nav)
    buttons.append([Button.inline("‹ Main Menu ›", cbx("menu"))])
    return msg, buttons

def get_global_stats(ssh=0, vmess=0, vless=0, trojan=0, shadowsocks=0):
    """Statistik global SEMUA layanan -> (total, online, offline).

    - total   : dijumlahkan dari counter yang sudah tampil di
      menu/start (SSH + Vmess + Vless + Trojan + Shadowsocks)
      supaya angkanya konsisten dengan tampilan.
    - online  : dihitung dari kondisi sistem (user SSH terlihat di
      `who`/proses sshd, user xray aktif di access.log dalam
      ONLINE_WINDOW_SEC detik terakhir).
    - offline : total - online.

    Dipakai menu utama & tampilan start:
      🌐 Global Total Akun / 🟢 Online / ⚪ Offline
    """
    try:
        total = (int(ssh or 0) + int(vmess or 0) + int(vless or 0)
                 + int(trojan or 0) + int(shadowsocks or 0))
    except (TypeError, ValueError):
        total = 0
    online = 0
    try:
        online += sum(1 for u in _passwd_users()
                      if u in _ssh_online_users())
        xray_on = _xray_online_users()
        for svc in ("vmess", "vless", "trojan", "shadowsocks"):
            online += sum(1 for u in _xray_expiry_map(svc)
                          if u in xray_on)
    except Exception:
        pass
    if online > total:
        total = online   # jaga konsistensi: Total >= Online
    return total, online, total - online

# ============================================================
# === SEMUA TAMPILAN PAKAI GAMBAR (KECUALI LOADING) ===
# ============================================================
# Patch dipasang SEKALI di sini. Method respond / reply / edit milik
# event Telethon diubah sehingga:
#
#   1. SEMUA tampilan (menu service, info akun, hasil trial, cek
#      login, pesan sukses, dll) otomatis dikirim sebagai FOTO
#      banner.jpg + caption -> tidak perlu mengubah script modul
#      satu per satu (start.py, ssh.py, vmess.py, dst tetap utuh).
#
#   2. Pesan LOADING ("Loading......", "Please Wait...",
#      "Wait.. Setting up an Account", dll) SELALU dikirim sebagai
#      TEKS BIASA TANPA GAMBAR. Kalau tombol ditekan pada pesan
#      bergambar, pesan loading dikirim sebagai pesan teks baru
#      sehingga gambarnya tidak ikut tampil.
#
#   3. Prompt input ("Username:", "Password:", ...) ikut dianggap
#      teks biasa supaya chat tidak penuh gambar banner saat input
#      data. Ubah BANNER_ON_PROMPTS = True kalau prompt juga mau
#      bergambar.
#
#   4. Pesan yang lebih panjang dari 1024 karakter (batas caption
#      foto Telegram) otomatis DIPECAH: bagian awal jadi caption foto
#      banner, sisanya dikirim sebagai pesan teks lanjutan. Pesan
#      edit yang terlalu panjang tetap diedit sebagai teks biasa.
#
# Kalau banner.jpg / BANNER= tidak ada, semua kembali ke perilaku
# lama (teks biasa) - tidak ada yang rusak.
# ============================================================

from telethon import events as _tg_events
from telethon.tl.custom.message import Message as _tg_message

BANNER_ON_PROMPTS = False   # True -> prompt "Username:" dll ikut pakai gambar
BANNER_MAX_CAPTION = 1024   # batas karakter caption foto Telegram

_LOADING_KEYWORDS = ("loading", "please wait", "memuat", "wait..",
                     "setting up", "tunggu")
# Pesan hasil PEMBUATAN AKUN & TRIAL dikirim sebagai TEKS BIASA
# (tanpa gambar) sesuai permintaan: judulnya selalu berakhiran
# "ACCOUNT⟩" (mis. "⟨VMESS ACCOUNT⟩") atau mengandung "TRIAL".
_NO_BANNER_KEYWORDS = ("account⟩", "trial")
_MD_STRIP_RE = re.compile(r"\*+|_+|`+")
_SEP_RE = re.compile(r"[━]{3,}|[─]{3,}")

def _banner_visible_len(text):
    """Perkiraan panjang teks setelah penanda markdown dihapus."""
    return len(_MD_STRIP_RE.sub("", text))

def _banner_wants_photo(text):
    """True kalau pesan ini bukan loading / bukan prompt input /
    bukan hasil pembuatan akun & trial.
    (Pesan yang terlalu panjang untuk caption foto ditangani
    _banner_split_text: dipecah jadi foto + lanjutan teks.)"""
    if not isinstance(text, str) or not text.strip():
        return False
    plain = _MD_STRIP_RE.sub("", text).strip().lower()
    # 0) hasil pembuatan akun & trial -> TANPA gambar (teks biasa)
    for kw in _NO_BANNER_KEYWORDS:
        if kw in plain:
            return False
    # 1) pesan loading -> tanpa gambar
    for kw in _LOADING_KEYWORDS:
        if kw in plain:
            return False
    # 2) prompt input pendek ("Username:", "Password :", ...) -> tanpa gambar
    if not BANNER_ON_PROMPTS and len(plain) <= 48 and plain.endswith(":"):
        return False
    return True

def _banner_split_text(text, limit=BANNER_MAX_CAPTION):
    """Pecah pesan yang lebih panjang dari batas caption foto.
    Pemotongan dilakukan di garis pemisah (━/─) dan hanya di luar
    blok kode ``` supaya format kedua bagian tetap rapi.
    Return (bagian_caption, bagian_lanjutan) atau None kalau tak perlu."""
    if _banner_visible_len(text) <= limit:
        return None
    lines = text.split("\n")
    acc = 0
    in_code = False
    last_sep = None   # potongan terakhir di garis pemisah
    last_any = None   # potongan terakhir di baris mana pun (seimbang)
    for i, line in enumerate(lines):
        if line.count("```") % 2 == 1:
            in_code = not in_code
        vl = len(_MD_STRIP_RE.sub("", line))
        if acc + vl > limit - 8:
            break
        acc += vl + 1
        if in_code:
            continue
        if _SEP_RE.search(line):
            last_sep = i + 1
        last_any = i + 1
    cut = last_sep or last_any
    if not cut or cut >= len(lines):
        return None
    part1 = "\n".join(lines[:cut]).rstrip()
    part2 = "\n".join(lines[cut:]).strip()
    if not part1 or not part2:
        return None
    return part1, part2

def _banner_media():
    """Ambil banner.jpg / URL BANNER (None kalau tidak ada)."""
    try:
        return get_banner_file()
    except Exception:
        return None

# ============================================================
# === AUTO DELETE PESAN "Loading......" ===
# ============================================================
# Semua pesan loading ("Loading......", "Please Wait...", dll)
# dilacak dan OTOMATIS DIHAPUS:
#   1. begitu pesan hasil (menu / sukses / gagal / prompt input)
#      dikirim di chat yang sama, dan
#   2. sebagai cadangan, setelah LOADING_TTL_SEC detik
#      (kalau operasinya menggantung / chat ditinggal).
# ============================================================

LOADING_TTL_SEC = 90
_LOADING_TRACK = {}   # {chat_id: set(message_id)}

def _is_loading_text(text):
    """True kalau teks ini adalah pesan loading."""
    if not isinstance(text, str) or not text.strip():
        return False
    plain = _MD_STRIP_RE.sub("", text).strip().lower()
    for kw in _LOADING_KEYWORDS:
        if kw in plain:
            return True
    return False

def _is_prompt_text(text):
    """True kalau teks ini prompt input pendek ("Username :", dll)."""
    if not isinstance(text, str) or not text.strip():
        return False
    plain = _MD_STRIP_RE.sub("", text).strip().lower()
    return len(plain) <= 48 and plain.endswith(":")

def _track_loading(msg):
    """Catat pesan loading yang baru terkirim + jadwalkan auto delete."""
    try:
        chat_id = msg.chat_id
        if chat_id is None or msg.id is None:
            return
        _LOADING_TRACK.setdefault(chat_id, set()).add(msg.id)
    except Exception:
        return

    async def _ttl_delete():
        # cadangan: hapus pesan loading yang tidak pernah diganti hasil
        try:
            await asyncio.sleep(LOADING_TTL_SEC)
            ids = _LOADING_TRACK.get(chat_id)
            if ids and msg.id in ids:
                ids.discard(msg.id)
                if not ids:
                    _LOADING_TRACK.pop(chat_id, None)
                await bot.delete_messages(chat_id, [msg.id])
        except Exception:
            pass

    try:
        bot.loop.create_task(_ttl_delete())
    except Exception:
        pass

async def _flush_loading(self):
    """Hapus semua pesan loading yang tercatat di chat ini (best effort).
    Dipanggil sebelum mengirim pesan hasil (bukan loading/prompt)."""
    try:
        chat_id = self.chat_id
    except Exception:
        chat_id = None
    if chat_id is None:
        return
    ids = _LOADING_TRACK.pop(chat_id, None)
    if not ids:
        return
    try:
        await self._client.delete_messages(chat_id, list(ids))
    except Exception:
        pass

def _banner_free_kwargs(kwargs):
    """True kalau pemanggil tidak sedang mengirim file/caption sendiri."""
    return "file" not in kwargs and "caption" not in kwargs

# ---- simpan method asli milik Telethon ----
_orig_cbq_respond = _tg_events.CallbackQuery.Event.respond
_orig_cbq_reply   = _tg_events.CallbackQuery.Event.reply
_orig_cbq_edit    = _tg_events.CallbackQuery.Event.edit
_orig_msg_respond = _tg_message.respond
_orig_msg_reply   = _tg_message.reply

# ---- patch respond/reply milik event tombol (CallbackQuery) ----
async def _cbq_respond_banner(self, *args, **kwargs):
    text = args[0] if args and isinstance(args[0], str) else None
    if text is not None and _banner_free_kwargs(kwargs):
        # pesan loading -> kirim sbg teks + lacak utk auto delete
        if _is_loading_text(text):
            result = await _orig_cbq_respond(self, text, *args[1:], **kwargs)
            _track_loading(result)
            return result
        # pesan hasil/final -> hapus sisa pesan loading sebelumnya
        if not _is_prompt_text(text):
            await _flush_loading(self)
        if _banner_wants_photo(text):
            media = _banner_media()
            if media:
                self._client.loop.create_task(self.answer())
                chat = await self.get_input_chat()
                try:
                    split = _banner_split_text(text)
                    if split:
                        # pesan panjang: caption foto = bagian awal,
                        # sisanya dikirim sebagai teks lanjutan
                        part1, part2 = split
                        kw1 = dict(kwargs)
                        kw1.pop("buttons", None)
                        await self._client.send_file(
                            chat, media, caption=part1, **kw1)
                        return await self._client.send_message(
                            chat, part2, **kwargs)
                    return await self._client.send_file(
                        chat, media, caption=text, **kwargs)
                except Exception:
                    return await self._client.send_message(
                        chat, text, *args[1:], **kwargs)
    return await _orig_cbq_respond(self, *args, **kwargs)

async def _cbq_reply_banner(self, *args, **kwargs):
    text = args[0] if args and isinstance(args[0], str) else None
    if text is not None and _banner_free_kwargs(kwargs):
        if _is_loading_text(text):
            result = await _orig_cbq_reply(self, text, *args[1:], **kwargs)
            _track_loading(result)
            return result
        if not _is_prompt_text(text):
            await _flush_loading(self)
        if _banner_wants_photo(text):
            media = _banner_media()
            if media:
                self._client.loop.create_task(self.answer())
                kwargs.setdefault("reply_to", self.query.msg_id)
                chat = await self.get_input_chat()
                try:
                    split = _banner_split_text(text)
                    if split:
                        part1, part2 = split
                        kw1 = dict(kwargs)
                        kw1.pop("buttons", None)
                        await self._client.send_file(
                            chat, media, caption=part1, **kw1)
                        return await self._client.send_message(
                            chat, part2, **kwargs)
                    return await self._client.send_file(
                        chat, media, caption=text, **kwargs)
                except Exception:
                    return await self._client.send_message(
                        chat, text, *args[1:], **kwargs)
    return await _orig_cbq_reply(self, *args, **kwargs)

# ---- patch respond/reply milik pesan teks (NewMessage) ----
async def _msg_respond_banner(self, *args, **kwargs):
    text = args[0] if args and isinstance(args[0], str) else None
    if text is not None and self._client and _banner_free_kwargs(kwargs):
        if _is_loading_text(text):
            result = await _orig_msg_respond(self, text, *args[1:], **kwargs)
            _track_loading(result)
            return result
        if not _is_prompt_text(text):
            await _flush_loading(self)
        if _banner_wants_photo(text):
            media = _banner_media()
            if media:
                chat = await self.get_input_chat()
                try:
                    split = _banner_split_text(text)
                    if split:
                        part1, part2 = split
                        kw1 = dict(kwargs)
                        kw1.pop("buttons", None)
                        await self._client.send_file(
                            chat, media, caption=part1, **kw1)
                        return await self._client.send_message(
                            chat, part2, **kwargs)
                    return await self._client.send_file(
                        chat, media, caption=text, **kwargs)
                except Exception:
                    pass
    return await _orig_msg_respond(self, *args, **kwargs)

async def _msg_reply_banner(self, *args, **kwargs):
    text = args[0] if args and isinstance(args[0], str) else None
    if text is not None and self._client and _banner_free_kwargs(kwargs):
        if _is_loading_text(text):
            result = await _orig_msg_reply(self, text, *args[1:], **kwargs)
            _track_loading(result)
            return result
        if not _is_prompt_text(text):
            await _flush_loading(self)
        if _banner_wants_photo(text):
            media = _banner_media()
            if media:
                kwargs.setdefault("reply_to", self.id)
                chat = await self.get_input_chat()
                try:
                    split = _banner_split_text(text)
                    if split:
                        part1, part2 = split
                        kw1 = dict(kwargs)
                        kw1.pop("buttons", None)
                        await self._client.send_file(
                            chat, media, caption=part1, **kw1)
                        return await self._client.send_message(
                            chat, part2, **kwargs)
                    return await self._client.send_file(
                        chat, media, caption=text, **kwargs)
                except Exception:
                    pass
    return await _orig_msg_reply(self, *args, **kwargs)

# ---- patch edit milik event tombol (CallbackQuery) ----
async def _cbq_edit_banner(self, *args, **kwargs):
    # pemanggil mengatur sendiri gambarnya (start.py / menu.py) -> asli
    if "file" in kwargs or "caption" in kwargs:
        # menu/start bergambar = pesan final -> hapus sisa loading
        await _flush_loading(self)
        return await _orig_cbq_edit(self, *args, **kwargs)

    text = args[0] if args and isinstance(args[0], str) else None
    if text is None:
        return await _orig_cbq_edit(self, *args, **kwargs)

    # === LOADING: teks saja, TANPA gambar + lacak utk auto delete ===
    # Jangan pakai event.edit() di sini: kalau pesan yang diedit sedang
    # bergambar, caption "Loading......" akan tampil BERSAMA gambar.
    # Kirim sebagai pesan teks baru; pesan ini nanti DIHAPUS OTOMATIS
    # begitu pesan hasil terkirim (atau setelah LOADING_TTL_SEC detik).
    if _is_loading_text(text):
        result = await _orig_cbq_respond(self, text, *args[1:], **kwargs)
        _track_loading(result)
        return result

    # === pesan hasil/final -> hapus sisa pesan loading sebelumnya ===
    if not _is_prompt_text(text):
        await _flush_loading(self)

    # === PROMPT / hasil create-trial: teks saja, TANPA gambar ===
    if not _banner_wants_photo(text):
        return await _orig_cbq_respond(self, text, *args[1:], **kwargs)

    media = _banner_media()
    if not media:
        # tidak ada banner -> perilaku lama (edit teks biasa)
        return await _orig_cbq_edit(self, *args, **kwargs)

    # cek pesan yang sedang diedit: sudah bergambar atau belum?
    orig = None
    try:
        orig = await self.get_message()
    except Exception:
        orig = None
    orig_photo = orig is not None and orig.photo

    # === pesan terlalu panjang untuk caption foto (mis. hasil cek login) ===
    # caption foto maksimal 1024 karakter -> kirim sebagai pesan teks biasa
    if _banner_split_text(text) is not None:
        if orig_photo:
            self._client.loop.create_task(self.answer())
            try:
                await self._client.delete_messages(
                    await self.get_input_chat(), [self.query.msg_id])
            except Exception:
                pass
            chat = await self.get_input_chat()
            try:
                return await self._client.send_message(
                    chat, text, *args[1:], **kwargs)
            except Exception:
                pass
        return await _orig_cbq_edit(self, *args, **kwargs)

    if orig_photo:
        # sudah berupa foto -> edit caption saja, banner tetap tampil
        return await _orig_cbq_edit(self, *args, **kwargs)

    # pesan lama bukan foto -> hapus lalu kirim ulang dengan banner
    self._client.loop.create_task(self.answer())
    try:
        await self._client.delete_messages(
            await self.get_input_chat(), [self.query.msg_id])
    except Exception:
        pass
    chat = await self.get_input_chat()
    try:
        return await self._client.send_file(
            chat, media, caption=text, **kwargs)
    except Exception:
        return await self._client.send_message(
            chat, text, *args[1:], **kwargs)

# ---- pasang patch (berlaku untuk semua modul, tanpa mengubah script) ----
_tg_events.CallbackQuery.Event.respond = _cbq_respond_banner
_tg_events.CallbackQuery.Event.reply   = _cbq_reply_banner
_tg_events.CallbackQuery.Event.edit    = _cbq_edit_banner
_tg_message.respond = _msg_respond_banner
_tg_message.reply   = _msg_reply_banner