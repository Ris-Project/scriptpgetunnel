#!/usr/bin/env python3
import os
import sqlite3
import math
import logging
import re
import requests
import datetime as DT
from telethon import TelegramClient

logging.basicConfig(level=logging.INFO)

# === Konstanta path
# Bisa dioverride lewat env var (berguna untuk testing), default tetap sama:
VAR_FILE = os.environ.get("PRIVATE_VAR_FILE", "/usr/bin/private/var.txt")
DB_FILE = os.environ.get("PRIVATE_DB_FILE", "/usr/bin/private/database.db")
SESSION_NAME = "private"  # nama file session Telethon
API_ID = 6                # ganti jika kamu pakai API ID sendiri
API_HASH = "eb06d4abfb49dc3eeb1aeb98ae0f581e"  # ganti jika pakai milikmu

uptime = DT.datetime.now()

# === Pastikan var.txt ada
os.makedirs(os.path.dirname(VAR_FILE), exist_ok=True)
if not os.path.exists(VAR_FILE):
    with open(VAR_FILE, "w") as f:
        f.write("# BOT_TOKEN=123456:ABC-xxx\n# ADMIN=11111111\n# DOMAIN=example.com\n"
                "# NICK=sg1  (opsional: nama panggilan bot, default = menu)\n")

# === Fungsi util: baca var.txt (dipakai modul lain juga)
def load_env_vars(path: str = VAR_FILE):
    result = {"BOT_TOKEN": None, "ADMINS": [], "DOMAIN": None, "BANNER": None, "NICK": None}
    if os.path.exists(path):
        with open(path, "r") as f:
            for raw in f:
                line = raw.strip()
                if not line or line.startswith("#") or "=" not in line:
                    continue
                key, val = line.split("=", 1)
                key = key.strip()
                val = val.strip().strip('"').strip("'")
                if key == "BOT_TOKEN":
                    result["BOT_TOKEN"] = val
                elif key == "ADMIN":
                    result["ADMINS"].append(val)
                elif key == "DOMAIN":
                    result["DOMAIN"] = val
                elif key == "BANNER":
                    result["BANNER"] = val
                elif key == "NICK":
                    result["NICK"] = val
    return result

# === Pakai load_env_vars untuk inisialisasi global
env = load_env_vars()
BOT_TOKEN = env["BOT_TOKEN"]
ADMINS = env["ADMINS"]
DOMAIN = env["DOMAIN"]

if not BOT_TOKEN:
    raise RuntimeError("BOT_TOKEN belum diset di {}".format(VAR_FILE))

# ============================================================
# === NAMA PANGGILAN BOT (NICK) — konfigurasi di var.txt ===
# ============================================================
# Cara pakai: tambahkan satu baris di var.txt, contoh:  NICK=sg1
#   - Bot menu      : dipanggil dengan  .sg1  atau  /sg1
#   - Bot start     : dipanggil dengan  .startsg1  atau  /startsg1
#   - Semua tombol otomatis ikut ter-suffix, jadi 1 bot token (BOT_TOKEN)
#     bisa dipakai mengelola banyak server tanpa bentrok.
# Kalau NICK tidak ada / kosong / "menu", bot pakai panggilan default
#   .menu, /menu, .start, /start (perilaku lama).
# TIDAK PERLU LAGI edit kode modul satu per satu.
_raw_nick = str(env.get("NICK") or "").strip()
NICK = re.sub(r"[^a-zA-Z0-9_]", "", _raw_nick) or "menu"
SUFFIX = "" if NICK == "menu" else NICK

# (?:@\w+)? -> memungkinkan /perintah@NamaBot (Telegram kadang menambahkan
# @username saat command dipilih dari autocomplete, terutama di grup)
PATTERN_MENU = r"(?:\.{}|/{})(?:@\w+)?$".format(NICK, NICK)
PATTERN_START = r"(?:\.start{}|/start{})(?:@\w+)?$".format(SUFFIX, SUFFIX)
CB_MENU = NICK
CB_START = "start" + SUFFIX

def cbx(name):
    """Callback data dengan suffix NICK (bytes).
    Semua handler & tombol wajib pakai ini agar konsisten."""
    name = str(name)
    if name == "menu":
        return CB_MENU.encode()
    if name == "start":
        return CB_START.encode()
    return (name + SUFFIX).encode()

# === Inisialisasi DB + tabel
os.makedirs(os.path.dirname(DB_FILE), exist_ok=True)
conn = sqlite3.connect(DB_FILE)
c = conn.cursor()
c.execute("CREATE TABLE IF NOT EXISTS admin (user_id TEXT UNIQUE)")
conn.commit()

# === Sinkron admin dari var.txt ke DB
for admin_id in ADMINS:
    c.execute("INSERT OR IGNORE INTO admin (user_id) VALUES (?)", (str(admin_id),))
conn.commit()
conn.close()

# === Client Telethon
bot = TelegramClient(SESSION_NAME, API_ID, API_HASH).start(bot_token=BOT_TOKEN)

# === Helper DB
def get_db():
    x = sqlite3.connect(DB_FILE)
    x.row_factory = sqlite3.Row
    return x

def valid(id_):
    db = get_db()
    rows = db.execute("SELECT user_id FROM admin").fetchall()
    admin_list = [r[0] for r in rows]
    return "true" if str(id_) in admin_list else "false"

def convert_size(size_bytes):
    if size_bytes == 0:
        return "0B"
    size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
    i = int(math.floor(math.log(size_bytes, 1024)))
    p = math.pow(1024, i)
    s = round(size_bytes / p, 2)
    return f"{s} {size_name[i]}"

# ============================================================
# === Banner Info (mengikuti script pgetunnel) ===
# ============================================================
AUTH_URL = "https://raw.githubusercontent.com/Ris-Project/scriptpgetunnel/main/ip"
DAYS_ID = ("Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu")
MONTHS_ID = ("Januari", "Februari", "Maret", "April", "Mei", "Juni",
             "Juli", "Agustus", "September", "Oktober", "November", "Desember")

def _get_vps_ip():
    """Ambil IP publik VPS (sama seperti script: curl icanhazip.com)."""
    for url in ("https://api.ipify.org", "http://icanhazip.com"):
        try:
            ip = requests.get(url, timeout=5).text.strip()
            if ip:
                return ip
        except Exception:
            pass
    return ""

def get_expire_info(exp):
    """Format Exp Date spt script: 11-11-2026 9 Days Active / Lifetime / Unknown."""
    if exp == "lifetime":
        return "Lifetime"
    if not exp:
        return "Unknown"
    try:
        expd = DT.datetime.strptime(exp, "%Y-%m-%d").date()
    except Exception:
        return "Unknown"
    days = (expd - DT.date.today()).days
    status = "Expired" if days < 0 else ("Today Expire" if days == 0 else "Active")
    return "{} {} Days {}".format(expd.strftime("%d-%m-%Y"), days, status)

def get_banner_info():
    """Banner info akun: Username, Exp Date, Date, Time, Version (WIB).
    Urutan & spasi tunggal mengikuti contoh agar rapih di caption foto."""
    ip = _get_vps_ip()
    username, exp = "Unknown", ""
    try:
        raw = requests.get(AUTH_URL, timeout=5).text
        for line in raw.splitlines():
            cols = line.split()
            if ip and ip in cols:
                username = cols[1] if len(cols) > 1 else "Unknown"
                exp = cols[2] if len(cols) > 2 else ""
                break
    except Exception:
        pass

    # Versi mengikuti script pgetunnel (/etc/pgetunnel/.version)
    ver = "1.0"
    try:
        with open("/etc/pgetunnel/.version") as f:
            parts = f.read().split()
            if len(parts) >= 2:
                ver = parts[1]
    except Exception:
        pass

    # Hari, tanggal, jam (otomatis - Indonesia, sama seperti script)
    now = DT.datetime.now()
    day = DAYS_ID[(now.weekday() + 1) % 7]
    date_id = "{}, {} {} {}".format(day, now.strftime("%d"), MONTHS_ID[now.month - 1], now.strftime("%Y"))
    time_id = "{} {}".format(now.strftime("%H:%M:%S"), now.strftime("%Z") or "WIB")

    return (
        "┏━━━━━━━━━━━━━━━━━━━━━━━━━┓\n"
        "┃   👤 Username : {}\n"
        "┃   ⏰ Exp Date : {}\n"
        "┃   📆 Date : {}\n"
        "┃   🕒 Time : {}\n"
        "┃   🚀 Version : {} (Auto)\n"
        "┗━━━━━━━━━━━━━━━━━━━━━━━━━┛"
    ).format(username, get_expire_info(exp), date_id, time_id, ver)

# Alias agar pemanggilan banner_info() (mis. di modules/start.py, modules/menu.py
# dan modul dist) tetap berfungsi
banner_info = get_banner_info

# ============================================================
# === Banner Menu (gambar) ===
# ============================================================
BANNER_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "banner.jpg")

def get_banner_file():
    """Gambar banner menu: utamakan file banner.jpg di folder bot,
    kalau tidak ada pakai URL dari BANNER= di var.txt, kalau keduanya
    tidak ada kembalikan None (menu terkirim sebagai teks biasa)."""
    try:
        if os.path.exists(BANNER_FILE):
            return BANNER_FILE
    except Exception:
        pass
    return load_env_vars().get("BANNER") or None

# ============================================================
# === SEMUA TAMPILAN PAKAI GAMBAR (KECUALI LOADING) ===
# ============================================================
# Patch dipasang SEKALI di sini. Method respond / reply / edit milik
# event Telethon diubah sehingga:
#
#   1. SEMUA tampilan (menu service, info akun, hasil trial, cek
#      login, pesan sukses, dll) otomatis dikirim sebagai FOTO
#      banner.jpg + caption -> tidak perlu mengubah script modul
#      satu per satu (start.py, ssh.py, vmess.py, dst tetap utuh).
#
#   2. Pesan LOADING ("Loading......", "Please Wait...",
#      "Wait.. Setting up an Account", dll) SELALU dikirim sebagai
#      TEKS BIASA TANPA GAMBAR. Kalau tombol ditekan pada pesan
#      bergambar, pesan loading dikirim sebagai pesan teks baru
#      sehingga gambarnya tidak ikut tampil.
#
#   3. Prompt input ("Username:", "Password:", ...) ikut dianggap
#      teks biasa supaya chat tidak penuh gambar banner saat input
#      data. Ubah BANNER_ON_PROMPTS = True kalau prompt juga mau
#      bergambar.
#
#   4. Pesan yang lebih panjang dari 1024 karakter (batas caption
#      foto Telegram) otomatis DIPECAH: bagian awal jadi caption foto
#      banner, sisanya dikirim sebagai pesan teks lanjutan. Pesan
#      edit yang terlalu panjang tetap diedit sebagai teks biasa.
#
# Kalau banner.jpg / BANNER= tidak ada, semua kembali ke perilaku
# lama (teks biasa) - tidak ada yang rusak.
# ============================================================

from telethon import events as _tg_events
from telethon.tl.custom.message import Message as _tg_message

BANNER_ON_PROMPTS = False   # True -> prompt "Username:" dll ikut pakai gambar
BANNER_MAX_CAPTION = 1024   # batas karakter caption foto Telegram

_LOADING_KEYWORDS = ("loading", "please wait", "memuat", "wait..",
                     "setting up", "tunggu")
_MD_STRIP_RE = re.compile(r"\*+|_+|`+")
_SEP_RE = re.compile(r"[━]{3,}|[─]{3,}")

def _banner_visible_len(text):
    """Perkiraan panjang teks setelah penanda markdown dihapus."""
    return len(_MD_STRIP_RE.sub("", text))

def _banner_wants_photo(text):
    """True kalau pesan ini bukan loading / bukan prompt input.
    (Pesan yang terlalu panjang untuk caption foto ditangani
    _banner_split_text: dipecah jadi foto + lanjutan teks.)"""
    if not isinstance(text, str) or not text.strip():
        return False
    plain = _MD_STRIP_RE.sub("", text).strip().lower()
    # 1) pesan loading -> tanpa gambar
    for kw in _LOADING_KEYWORDS:
        if kw in plain:
            return False
    # 2) prompt input pendek ("Username:", "Password :", ...) -> tanpa gambar
    if not BANNER_ON_PROMPTS and len(plain) <= 48 and plain.endswith(":"):
        return False
    return True

def _banner_split_text(text, limit=BANNER_MAX_CAPTION):
    """Pecah pesan yang lebih panjang dari batas caption foto.
    Pemotongan dilakukan di garis pemisah (━/─) dan hanya di luar
    blok kode ``` supaya format kedua bagian tetap rapi.
    Return (bagian_caption, bagian_lanjutan) atau None kalau tak perlu."""
    if _banner_visible_len(text) <= limit:
        return None
    lines = text.split("\n")
    acc = 0
    in_code = False
    last_sep = None   # potongan terakhir di garis pemisah
    last_any = None   # potongan terakhir di baris mana pun (seimbang)
    for i, line in enumerate(lines):
        if line.count("```") % 2 == 1:
            in_code = not in_code
        vl = len(_MD_STRIP_RE.sub("", line))
        if acc + vl > limit - 8:
            break
        acc += vl + 1
        if in_code:
            continue
        if _SEP_RE.search(line):
            last_sep = i + 1
        last_any = i + 1
    cut = last_sep or last_any
    if not cut or cut >= len(lines):
        return None
    part1 = "\n".join(lines[:cut]).rstrip()
    part2 = "\n".join(lines[cut:]).strip()
    if not part1 or not part2:
        return None
    return part1, part2

def _banner_media():
    """Ambil banner.jpg / URL BANNER (None kalau tidak ada)."""
    try:
        return get_banner_file()
    except Exception:
        return None

def _banner_free_kwargs(kwargs):
    """True kalau pemanggil tidak sedang mengirim file/caption sendiri."""
    return "file" not in kwargs and "caption" not in kwargs

# ---- simpan method asli milik Telethon ----
_orig_cbq_respond = _tg_events.CallbackQuery.Event.respond
_orig_cbq_reply   = _tg_events.CallbackQuery.Event.reply
_orig_cbq_edit    = _tg_events.CallbackQuery.Event.edit
_orig_msg_respond = _tg_message.respond
_orig_msg_reply   = _tg_message.reply

# ---- patch respond/reply milik event tombol (CallbackQuery) ----
async def _cbq_respond_banner(self, *args, **kwargs):
    text = args[0] if args and isinstance(args[0], str) else None
    if (text is not None and _banner_free_kwargs(kwargs)
            and _banner_wants_photo(text)):
        media = _banner_media()
        if media:
            self._client.loop.create_task(self.answer())
            chat = await self.get_input_chat()
            try:
                split = _banner_split_text(text)
                if split:
                    # pesan panjang: caption foto = bagian awal,
                    # sisanya dikirim sebagai teks lanjutan
                    part1, part2 = split
                    kw1 = dict(kwargs)
                    kw1.pop("buttons", None)
                    await self._client.send_file(
                        chat, media, caption=part1, **kw1)
                    return await self._client.send_message(
                        chat, part2, **kwargs)
                return await self._client.send_file(
                    chat, media, caption=text, **kwargs)
            except Exception:
                return await self._client.send_message(
                    chat, text, *args[1:], **kwargs)
    return await _orig_cbq_respond(self, *args, **kwargs)

async def _cbq_reply_banner(self, *args, **kwargs):
    text = args[0] if args and isinstance(args[0], str) else None
    if (text is not None and _banner_free_kwargs(kwargs)
            and _banner_wants_photo(text)):
        media = _banner_media()
        if media:
            self._client.loop.create_task(self.answer())
            kwargs.setdefault("reply_to", self.query.msg_id)
            chat = await self.get_input_chat()
            try:
                split = _banner_split_text(text)
                if split:
                    part1, part2 = split
                    kw1 = dict(kwargs)
                    kw1.pop("buttons", None)
                    await self._client.send_file(
                        chat, media, caption=part1, **kw1)
                    return await self._client.send_message(
                        chat, part2, **kwargs)
                return await self._client.send_file(
                    chat, media, caption=text, **kwargs)
            except Exception:
                return await self._client.send_message(
                    chat, text, *args[1:], **kwargs)
    return await _orig_cbq_reply(self, *args, **kwargs)

# ---- patch respond/reply milik pesan teks (NewMessage) ----
async def _msg_respond_banner(self, *args, **kwargs):
    text = args[0] if args and isinstance(args[0], str) else None
    if (text is not None and self._client
            and _banner_free_kwargs(kwargs) and _banner_wants_photo(text)):
        media = _banner_media()
        if media:
            chat = await self.get_input_chat()
            try:
                split = _banner_split_text(text)
                if split:
                    part1, part2 = split
                    kw1 = dict(kwargs)
                    kw1.pop("buttons", None)
                    await self._client.send_file(
                        chat, media, caption=part1, **kw1)
                    return await self._client.send_message(
                        chat, part2, **kwargs)
                return await self._client.send_file(
                    chat, media, caption=text, **kwargs)
            except Exception:
                pass
    return await _orig_msg_respond(self, *args, **kwargs)

async def _msg_reply_banner(self, *args, **kwargs):
    text = args[0] if args and isinstance(args[0], str) else None
    if (text is not None and self._client
            and _banner_free_kwargs(kwargs) and _banner_wants_photo(text)):
        media = _banner_media()
        if media:
            kwargs.setdefault("reply_to", self.id)
            chat = await self.get_input_chat()
            try:
                split = _banner_split_text(text)
                if split:
                    part1, part2 = split
                    kw1 = dict(kwargs)
                    kw1.pop("buttons", None)
                    await self._client.send_file(
                        chat, media, caption=part1, **kw1)
                    return await self._client.send_message(
                        chat, part2, **kwargs)
                return await self._client.send_file(
                    chat, media, caption=text, **kwargs)
            except Exception:
                pass
    return await _orig_msg_reply(self, *args, **kwargs)

# ---- patch edit milik event tombol (CallbackQuery) ----
async def _cbq_edit_banner(self, *args, **kwargs):
    # pemanggil mengatur sendiri gambarnya (start.py / menu.py) -> asli
    if "file" in kwargs or "caption" in kwargs:
        return await _orig_cbq_edit(self, *args, **kwargs)

    text = args[0] if args and isinstance(args[0], str) else None
    if text is None:
        return await _orig_cbq_edit(self, *args, **kwargs)

    # === LOADING / PROMPT: teks saja, TANPA gambar ===
    # Jangan pakai event.edit() di sini: kalau pesan yang diedit sedang
    # bergambar, caption "Loading......" akan tampil BERSAMA gambar.
    # Kirim sebagai pesan teks baru (pesan lama dibiarkan apa adanya).
    if not _banner_wants_photo(text):
        return await _orig_cbq_respond(self, text, *args[1:], **kwargs)

    media = _banner_media()
    if not media:
        # tidak ada banner -> perilaku lama (edit teks biasa)
        return await _orig_cbq_edit(self, *args, **kwargs)

    # cek pesan yang sedang diedit: sudah bergambar atau belum?
    orig = None
    try:
        orig = await self.get_message()
    except Exception:
        orig = None
    orig_photo = orig is not None and orig.photo

    # === pesan terlalu panjang untuk caption foto (mis. hasil cek login) ===
    # caption foto maksimal 1024 karakter -> kirim sebagai pesan teks biasa
    if _banner_split_text(text) is not None:
        if orig_photo:
            self._client.loop.create_task(self.answer())
            try:
                await self._client.delete_messages(
                    await self.get_input_chat(), [self.query.msg_id])
            except Exception:
                pass
            chat = await self.get_input_chat()
            try:
                return await self._client.send_message(
                    chat, text, *args[1:], **kwargs)
            except Exception:
                pass
        return await _orig_cbq_edit(self, *args, **kwargs)

    if orig_photo:
        # sudah berupa foto -> edit caption saja, banner tetap tampil
        return await _orig_cbq_edit(self, *args, **kwargs)

    # pesan lama bukan foto -> hapus lalu kirim ulang dengan banner
    self._client.loop.create_task(self.answer())
    try:
        await self._client.delete_messages(
            await self.get_input_chat(), [self.query.msg_id])
    except Exception:
        pass
    chat = await self.get_input_chat()
    try:
        return await self._client.send_file(
            chat, media, caption=text, **kwargs)
    except Exception:
        return await self._client.send_message(
            chat, text, *args[1:], **kwargs)

# ---- pasang patch (berlaku untuk semua modul, tanpa mengubah script) ----
_tg_events.CallbackQuery.Event.respond = _cbq_respond_banner
_tg_events.CallbackQuery.Event.reply   = _cbq_reply_banner
_tg_events.CallbackQuery.Event.edit    = _cbq_edit_banner
_tg_message.respond = _msg_respond_banner
_tg_message.reply   = _msg_reply_banner