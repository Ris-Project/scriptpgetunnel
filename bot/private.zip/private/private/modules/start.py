from private import *
import subprocess
import requests
from telethon import events, Button

env = load_env_vars()
DOMAIN = env.get("DOMAIN", "Tidak Diketahui")

def run_shell_command(command):
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            check=True
        )
        return result.stdout.strip()
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        print(f"Error running command '{command}': {e}")
        return "0"

@bot.on(events.NewMessage(pattern=PATTERN_START))
@bot.on(events.CallbackQuery(data=cbx("start")))
async def start(event):
    sender = await event.get_sender()
    
    is_valid = valid(str(sender.id))

    if is_valid == "true":

        try:
            inline_buttons = [[Button.inline("Menu", cbx("menu"), style="success")]]
            
            if isinstance(event, events.CallbackQuery):
                await event.answer("Memuat data server...")

            ssh = run_shell_command('cat /etc/passwd | grep "home" | grep "false" | wc -l')
            vms = run_shell_command('cat /etc/xray/config.json | grep "###" | wc -l')
            vls = run_shell_command('cat /etc/xray/config.json | grep "#&" | wc -l')
            trj = run_shell_command('cat /etc/xray/config.json | grep "#!" | wc -l')
            shadowsocks = run_shell_command('cat /etc/xray/config.json | grep "#@&" | wc -l')
            
            namaos = run_shell_command("grep PRETTY_NAME /etc/os-release | sed 's/PRETTY_NAME=//g; s/\"//g'")
            ipsaya = run_shell_command("curl -s ipv4.icanhazip.com")

            ip_info = requests.get(f"http://ip-api.com/json/{ipsaya}?fields=country,regionName,city,timezone,isp").json()

            vms_half = int(vms or 0) // 2
            vls_half = int(vls or 0) // 2
            trj_half = int(trj or 0) // 2
            shadowsocks_half = int(shadowsocks or 0) // 1

            # Statistik global semua layanan: Total / Online / Offline
            total_all, online_all, offline_all = get_global_stats(
                ssh, vms_half, vls_half, trj_half, shadowsocks_half)

            msg = f"""
┏━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃   <b>❇️ ROBOT PRIVATE ❇️</b>
┣━━━━━━━━━━━━━━━━━━━━━━━━━┫
┃   <b>» OS :</b> {namaos}
┃   <b>» IP :</b> <code>{ipsaya}</code>
┃   <b>» ISP :</b> {ip_info.get('isp', 'N/A')}
┃   <b>» Lokasi :</b> {ip_info.get('city', 'N/A')}, {ip_info.get('regionName', 'N/A')} ({ip_info.get('country', 'N/A')})
┃   <b>» Domain :</b> <code>{DOMAIN}</code>
┃   <b>» Zona Waktu :</b> {ip_info.get('timezone', 'N/A')}
┣━━━━━━━━━━━━━━━━━━━━━━━━━┫
┃   <b>🌀 Total Akun Di Buat:</b>
┃   🏷️ SSH: <b>{ssh}</b>
┃   🏷️ Vmess: <b>{vms_half}</b>
┃   🏷️ Vless: <b>{vls_half}</b>
┃   🏷️ Trojan: <b>{trj_half}</b>
┃   🏷️ Shadowsocks: <b>{shadowsocks_half}</b>
┣━━━━━━━━━━━━━━━━━━━━━━━━━┫
┃   🌐 <b>Global Total Akun:</b> <b>{total_all}</b>
┃   🟢 <b>Online:</b> <b>{online_all}</b>
┃   ⚪ <b>Offline:</b> <b>{offline_all}</b>
┗━━━━━━━━━━━━━━━━━━━━━━━━━┛

{get_banner_info()}

Tekan tombol di bawah untuk menampilkan menu bot
"""

            media = get_banner_file()
            if isinstance(event, events.CallbackQuery):
                if media:
                    try:
                        await event.edit(msg, parse_mode="html", file=media, buttons=inline_buttons)
                    except Exception:
                        try:
                            await event.delete()
                        except Exception:
                            pass
                        await bot.send_file(event.chat_id, media, caption=msg,
                                            parse_mode="html", buttons=inline_buttons)
                else:
                    await event.edit(msg, parse_mode="html", buttons=inline_buttons)
            else:
                if media:
                    await event.respond(msg, parse_mode="html", file=media, buttons=inline_buttons)
                else:
                    await event.respond(msg, parse_mode="html", buttons=inline_buttons)

        except Exception as e:
            error_message = f"Terjadi kesalahan: {e}"
            if isinstance(event, events.CallbackQuery):
                await event.answer(error_message, alert=True)
            else:
                await event.reply(error_message)
    
    else:  
        message = "Akses ditolak. Silahkan beli premium di @zenviora_id"
        try:
            await event.answer(message, alert=True)
        except:
            await event.reply(message)