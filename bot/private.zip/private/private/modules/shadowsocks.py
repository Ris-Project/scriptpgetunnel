from private import *
import subprocess
import json
import base64
import datetime as DT
import requests
import time
import random
import asyncio
import tempfile
import re
from telethon import events, Button

env = load_env_vars()
DOMAIN = env.get("DOMAIN", "Tidak Diketahui")

@bot.on(events.CallbackQuery(data=cbx("create-shadowsocks")))
async def create_shadowsocks(event):
    user_id = str(event.sender_id)

    async def create_shadowsocks_(event):
        try:
            async with bot.conversation(chat) as user_conv:
                await event.respond('**Username :**')
                user_msg = user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                user = (await user_msg).raw_text

            async with bot.conversation(chat) as exp_conv:
                await event.respond('**Expired :**')
                exp_msg = exp_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                exp = (await exp_msg).raw_text
   
            
            async with bot.conversation(chat) as ip_limit_conv:
                await event.respond('**Limit Quota :**')
                ip_limit_msg = ip_limit_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                ip_limit = (await ip_limit_msg).raw_text
                      
                      
            async with bot.conversation(chat) as Quota_conv:
                await event.respond('**Limit Ip :**')
                Quota_msg = Quota_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                Quota = (await Quota_msg).raw_text
                 
            await event.edit("**Loading......**")    
            cmd = f'printf "%s\n" "{user}" "{exp}" "{ip_limit}" "{Quota}" | addss-bot'

            a = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")

        except subprocess.CalledProcessError as e:
            print(f"Error executing command: {e}")
            print(f"Exit code: {e.returncode}")
            print(f"Output: {e.output.decode('utf-8')}")
            await event.respond(f"Error executing command: {e}")
            return  # Stop execution to prevent further processing on error

        except Exception as ex:
            print(f"Unexpected error: {ex}")
            await event.respond("An unexpected error occurred.")
            return  # Stop execution to prevent further processing on error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        x = [x.group() for x in re.finditer("ss://(.*)", a)]
        uuid = re.search("ss://(.*?)@", x[0]).group(1)

        msg = f"""
        
**◇━━━━━━━━━━━━━━━━━◇**
**◇⟨SHDOWSOCKS ACCOUNT⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» Username :** `{user}`
**» Domain :** `{DOMAIN}`
**» Limit Quota :** `{ip_limit} GB`
**» Limit Login :** `{Quota} HP`
**» HTTP :** `80,8880,2052,2086,2095`
**» HTTPS :** `443,2053,2087,2096`
**» UUID    :** `{uuid}`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/viip-ss-ws`
**» ServiceName :** `ss-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK TLS 443      :**
```{x[0]}```
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK NON-TLS 80   :** 
```{x[1].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK gRPC TLS 443 :** 
```{x[2].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**◇⟨Link Save Account⟩◇**
https://{DOMAIN}:81/ss-{user}.txt
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
»  🤖@zenviora_id

        """

        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await create_shadowsocks_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)





@bot.on(events.CallbackQuery(data=cbx("cek-shadowsocks")))
async def cek_shadowsocks(event):
    # List Member SHADOWSOCKS + tombol Next
    async def cek_shadowsocks_(event):
        try:
            await event.edit("**Loading......**")
            msg, buttons = render_member_page("shadowsocks", 1)
            await event.edit(msg, buttons=buttons)
        except Exception as e:
            await event.respond(f"Error: {e}",
                buttons=[[Button.inline("‹ Main Menu ›", cbx("menu"), style="primary")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await cek_shadowsocks_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)

# navigasi halaman List Member SHADOWSOCKS (tombol Next / Back)
@bot.on(events.CallbackQuery(pattern=r"^listss-(\d+)"))
async def list_shadowsocks_page(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Buy Premium Chat: @zenviora_id", alert=True)
    try:
        page = int(event.pattern_match.group(1))
    except Exception:
        page = 1
    msg, buttons = render_member_page("shadowsocks", page)
    await event.edit(msg, buttons=buttons)




@bot.on(events.CallbackQuery(data=cbx("delete-shadowsocks")))
async def delete_shadowsocks(event):
    async def delete_shadowsocks_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username :**')
            user_event = user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user_text = (await user_event).raw_text
        await event.edit("**Loading......**")
        cmd = f'printf "%s\n" "{user_text}" | bot-del-ss'
        try:
            output = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except subprocess.CalledProcessError:
            await event.respond("**Successfully Deleted**")
        else:
            msg = "**Successfully Deleted**"
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await delete_shadowsocks_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)







@bot.on(events.CallbackQuery(data=cbx("trial-shadowsocks")))
async def trial_shadowsocks(event):
    user_id = str(event.sender_id)
    async def trial_shadowsocks_(event):
        

        try:
            await event.edit("**Loading......**")
            cmd = f'printf "%s\n" "TrialSS`</dev/urandom tr -dc X-Z0-9 | head -c4`" "1" "1" "1" | bot-trialshd'
            a = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT).decode("utf-8")

        except subprocess.CalledProcessError as e:
            print(f"Error executing command: {e}")
            print(f"Exit code: {e.returncode}")
            print(f"Output: {e.output.decode('utf-8')}")
            await event.respond(f"Error executing command: {e}")
            return  # Stop execution to prevent further processing on error

        except Exception as ex:
            print(f"Unexpected error: {ex}")
            await event.respond("An unexpected error occurred.")
            return  # Stop execution to prevent further processing on error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(1))
        x = [x.group() for x in re.finditer("ss://(.*)", a)]
        uuid = re.search("ss://(.*?)@", x[0]).group(1)
        remarks = re.search("#(.*)", x[0]).group(1)

        msg = f"""
        
**◇━━━━━━━━━━━━━━━━━◇**
**◇⟨TRIAL SHDWSK ACCOUNT⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» Username :** `{remarks}`
**» Host Server :** `{DOMAIN}`
**» HTTP :** `80,8880,2052,2086,2095`
**» HTTPS :** `443,2053,2087,2096`
**» UUID    :** `{uuid}`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/viip-ss-ws`
**» ServiceName :** `ss-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK TLS 443      :**
```{x[0]}```
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK NON-TLS 80   :** 
```{x[1].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK gRPC TLS 443 :** 
```{x[2].replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**◇⟨Link Save Account⟩◇**
https://{DOMAIN}:81/ss-{remarks}.txt
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** 30 Minutes
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@zenviora_id

        """

        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trial_shadowsocks_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)

@bot.on(events.CallbackQuery(data=cbx("renew-ss-ws")))
async def ren_ss(event):
    async def ren_ss_(event):
        chat = event.chat_id
        sender = await event.get_sender()

        # Check if the user is valid before continuing
        a = valid(str(sender.id))
        if a != "true":
            await event.answer("Buy Premium Chat: @zenviora_id", alert=True)
            return

        # Get user input for Username, Expiry, IP limit, and Quota
        async with bot.conversation(chat) as conv:
            await event.respond('**Username :**')
            user_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user_msg.raw_text

            await event.respond('**Expired :**')
            exp_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = exp_msg.raw_text

            await event.respond('**Limit Quota :**')
            ip_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            ip = ip_msg.raw_text

            await event.respond('**Limit Ip :**')
            quota_msg = await conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            quota = quota_msg.raw_text

        await event.edit("**Loading......**")
        cmd = f'printf "%s\n" "{user}" "{exp}" "{ip}" "{quota}" | bot-renew-ss'
        # exit code backend diabaikan (script bot-renew-ss selalu exit 1
        # walau sukses) - keberhasilan diverifikasi dari kondisi sistem
        run_renew(cmd)
        # masa aktif & tanggal expired baru dibaca langsung dari sistem
        info = get_member_info("shadowsocks", user)
        if info["exp"] == "Unknown":
            await event.respond(f"**❌ Gagal Renew User** `{user}`\n**Periksa Kembali Username-nya**",
                buttons=[[Button.inline("‹ Main Menu ›", cbx("menu"), style="primary")]])
            return
        msg = f"""
**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**
**┃   ⟨RENEW SHDWSK BERHASIL⟩**
**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**
**┃   👤 Username :** `{user}`
**┃   ➕ Diperpanjang :** `{exp} Hari`
**┃   ⏳ Masa Aktif :** `{info["days"]}`
**┃   📅 Expired :** `{info["exp"]}`
**┃   📦 Limit Kuota :** `{ip} GB`
**┃   🔗 Limit IP :** `{quota} IP`
**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**
**» 🤖@zenviora_id**
"""
        await event.respond(msg, buttons=[[Button.inline("‹ Main Menu ›", cbx("menu"), style="primary")]])

    # Call the renew function
    await ren_ss_(event)

@bot.on(events.CallbackQuery(data=cbx("limit-shadowsocks")))
async def limit_shadowsocks(event):
        async def limit_shadowsocks_(event):
                async with bot.conversation(chat) as user:
                        await event.respond("**Username :**")
                        user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        user = (await user).raw_text
                async with bot.conversation(chat) as pw:
                        await event.respond("**Limit IP :**")
                        pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        pw = (await pw).raw_text
                        await event.edit("**Loading......**")
                        cmd = f'printf "%s\n" "{user}" "{pw}" | bot-ganti-ip-ss'
                try:
                        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                except:
                        await event.respond(f"`{user}` **Succesfully Change Limit IP**")
                else:
                        await event.respond(f"""
```
{a}
```
**GANTI IP shadowsocks**
**» 🤖@zenviora_id**
""",buttons=[[Button.inline("‹ Main Menu ›",cbx("menu"), style="primary")]])
        chat = event.chat_id
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await limit_shadowsocks_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)

@bot.on(events.CallbackQuery(data=cbx("quota-shadowsocks")))
async def quota_shadowsocks(event):
        async def quota_shadowsocks_(event):
                async with bot.conversation(chat) as user:
                        await event.respond("**Username :**")
                        user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        user = (await user).raw_text
                async with bot.conversation(chat) as pw:
                        await event.respond("**Limit Quota :**")
                        pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        pw = (await pw).raw_text
                        await event.edit("**Loading......**")
                        cmd = f'printf "%s\n" "{user}" "{pw}" | bot-quota-shd'
                try:
                        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                except:
                        await event.respond(f"`{user}` **Succesfully Change Limit Quota**")
                else:
                        await event.respond(f"""
```
{a}
```
**GANTI QUOTA shadowsocks**
**» 🤖@zenviora_id**
""",buttons=[[Button.inline("‹ Main Menu ›",cbx("menu"), style="primary")]])
        chat = event.chat_id
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await quota_shadowsocks_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)

@bot.on(events.CallbackQuery(data=cbx("lock-shadowsocks")))
async def lock_shadowsocks(event):
        async def lock_shadowsocks_(event):
                async with bot.conversation(chat) as exp:
                        await event.respond("**Username :**")
                        exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        exp = (await exp).raw_text
                await event.edit("**Loading......**")
                cmd = f'printf "%s\n" "{exp}" | bot-lock-shd'
                try:
                        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                except:
                        await event.respond(f"**User** `{exp}` **Successfully Locked**")
                else:
                        msg = f"""**Successfully Locked**"""
                        await event.respond(msg)
        chat = event.chat_id
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await lock_shadowsocks_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)
#UNLOCK ssh
@bot.on(events.CallbackQuery(data=cbx("unlock-shadowsocks")))
async def unlock_shadowsocks(event):
        async def unlock_shadowsocks_(event):
                async with bot.conversation(chat) as exp:
                        await event.respond("**Username :**")
                        exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        exp = (await exp).raw_text
                await event.edit("**Loading......**")
                cmd = f'printf "%s\n" "{exp}" | bot-unlock-shd'
                try:
                        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                except:
                        await event.respond(f"**User** `{exp}` **Successfully Unlocked**")
                else:
                        msg = f"""**Successfully Unlocked**"""
                        await event.respond(msg)
        chat = event.chat_id
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await unlock_shadowsocks_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)




@bot.on(events.CallbackQuery(data=cbx("shadowsocks")))
async def shadowsocks(event):
    user_id = str(event.sender_id)

    async def shadowsocks_(event):
        # Layout rapih per baris (warna seragam dalam 1 baris):
        #   Baris 1 HIJAU (success)  : aksi utama akun
        #   Baris 2 BIRU (primary)  : info & monitoring
        #   Baris 3 MERAH (danger)  : hapus / blokir / buka blokir
        #   Baris 4 BIRU (primary)  : ubah limit akun
        #   Baris 5 BIRU (primary)  : navigasi
        inline = [
            [Button.inline("Trial", cbx("trial-shadowsocks"), style="success"),
             Button.inline("Create", cbx("create-shadowsocks"), style="success"),
             Button.inline("Renew", cbx("renew-ss-ws"), style="success")],
            [Button.inline("List Member", cbx("cek-shadowsocks"), style="primary")],
            [Button.inline("Delete", cbx("delete-shadowsocks"), style="danger"),
             Button.inline("Lock", cbx("lock-shadowsocks"), style="danger"),
             Button.inline("Unlock", cbx("unlock-shadowsocks"), style="danger")],
            [Button.inline("Change Limit IP", cbx("limit-shadowsocks"), style="primary"),
             Button.inline("Change Limit Quota", cbx("quota-shadowsocks"), style="primary")],
            [Button.inline("‹ Main Menu ›", cbx("menu"), style="primary")]]
        
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**
**┃   ⟨SHADOWSOCKS SERVICE⟩**
**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**
**┃   » Service :** `Shadowsocks`
**┃   » Domain :** `{DOMAIN}`
**┃   » ISP :** `{z["isp"]}`
**┃   » Country :** `{z["country"]}`
**┃   » 🤖@zenviora_id**
**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**
"""

        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await shadowsocks_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)


