from private import *
from private import _flush_loading   # nama underscore tidak ikut "import *"
import os
import stat
import time
import shutil
import zipfile
import datetime as DT
import subprocess
import requests
import asyncio
import re
from telethon import events, Button

env = load_env_vars()
DOMAIN = env.get("DOMAIN", "Tidak Diketahui")

# ============================================================
# === BACKUP & RESTORE VIA ID BOT ===
# ============================================================
# Backup & restore dilakukan LANGSUNG oleh bot ini (memakai
# BOT_TOKEN sendiri / "ID Bot"), tanpa perlu Setup Token-ID,
# rclone, atau Google Drive:
#
#   - BACKUP  : file-file penting server + config bot (var.txt,
#     database.db, banner.jpg) dikumpulkan jadi 1 file .zip lalu
#     DIKIRIM OLEH BOT ke chat admin (ID admin di var.txt juga
#     dikirim best-effort). Isi & formatnya sama dengan script
#     'cadangkan-bot' lama (folder backup/ di dalam zip), jadi
#     hasilnya tetap bisa di-restore dengan 'bot-restore' lama.
#
#   - RESTORE : admin kirim / forward FILE .zip backup ke chat
#     bot (atau kirim link download), bot yang mengekstrak dan
#     memulihkan semuanya, lalu service xray di-restart.
# ============================================================

# --- lokasi sumber backup & tujuan restore (mengikuti script lama) ---
_ETC = "/etc"
_WWW = "/var/www"
_DETAIL = "/detail"

# folder bot (var.txt / database.db) & folder package bot (banner.jpg)
_BOT_DIR = os.path.dirname(os.path.abspath(VAR_FILE))
_PKG_DIR = os.path.dirname(os.path.abspath(__file__))

WORK_DIR = "/root/.idbot-backup"   # folder kerja zip backup / restore

_SINGLE_FILES = ("passwd", "group", "shadow", "gshadow", "crontab")
_DB_FILES = (".vmess.db", ".vless.db", ".trojan.db", ".shadowsocks.db")
_SERVICE_DIRS = ("limit", "vmess", "vless", "trojan", "shadowsocks")
_MAX_FILE_BYTES = 100 * 1024 * 1024        # skip file > 100 MB (mis. log)
_SKIP_SUFFIX = (".log", ".session", ".pyc", ".pyo")


def _zip_add_file(zf, path, arcname):
    """Tambah satu file ke zip (skip kalau tidak ada / terlalu besar).
    Permission asli ikut disimpan supaya restore mengembalikannya."""
    try:
        st = os.stat(path)
    except OSError:
        return False
    if not stat.S_ISREG(st.st_mode) or st.st_size > _MAX_FILE_BYTES:
        return False
    if str(path).endswith(_SKIP_SUFFIX):
        return False
    try:
        zf.write(path, arcname, zipfile.ZIP_DEFLATED)
        return True
    except Exception:
        return False


def _zip_add_tree(zf, path, arcname):
    """Tambah seluruh isi folder (rekursif) ke zip. Return jumlah file."""
    if not os.path.isdir(path):
        return 0
    n = 0
    for root, dirs, files in os.walk(path):
        dirs.sort()
        for f in sorted(files):
            fp = os.path.join(root, f)
            rel = os.path.relpath(fp, path)
            if _zip_add_file(zf, fp, os.path.join(arcname, rel)):
                n += 1
    return n


def _cleanup_old_backups(keep=5):
    """Simpan maksimal `keep` zip backup terakhir di WORK_DIR."""
    try:
        files = [os.path.join(WORK_DIR, f) for f in os.listdir(WORK_DIR)
                 if f.endswith(".zip")]
        files.sort(key=os.path.getmtime, reverse=True)
        for old in files[keep:]:
            try:
                os.remove(old)
            except OSError:
                pass
    except Exception:
        pass


def create_backup_zip():
    """Buat file zip backup server + config bot.
    Return (path_zip, info_dict)."""
    os.makedirs(WORK_DIR, exist_ok=True)
    ip = ""
    for url in ("https://api.ipify.org", "http://icanhazip.com"):
        try:
            ip = requests.get(url, timeout=5).text.strip()
            if ip:
                break
        except Exception:
            continue
    try:
        domain = load_env_vars().get("DOMAIN") or DOMAIN or "-"
    except Exception:
        domain = DOMAIN or "-"
    stamp = DT.datetime.now().strftime("%d-%m-%Y")
    zip_path = os.path.join(
        WORK_DIR, "backup-{}-{}.zip".format(stamp, time.strftime("%H%M%S")))
    stage = "backup"   # nama folder di dalam zip (kompatibel bot-restore)
    info = {"files": 0, "date": stamp, "ip": ip, "domain": domain,
            "path": zip_path, "size": 0}
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        # file tunggal /etc (passwd, group, shadow, gshadow, crontab)
        for name in _SINGLE_FILES:
            if _zip_add_file(zf, os.path.join(_ETC, name),
                             "{}/{}".format(stage, name)):
                info["files"] += 1
        # database user xray (root zip backup, sama seperti script lama)
        for db, svc in ((".vmess.db", "vmess"), (".vless.db", "vless"),
                        (".trojan.db", "trojan"),
                        (".shadowsocks.db", "shadowsocks")):
            if _zip_add_file(zf, os.path.join(_ETC, svc, db),
                             "{}/{}".format(stage, db)):
                info["files"] += 1
        # folder layanan (limit, vmess, vless, trojan, shadowsocks)
        for name in _SERVICE_DIRS:
            info["files"] += _zip_add_tree(
                zf, os.path.join(_ETC, name), "{}/{}".format(stage, name))
        # config xray (config.json, db, sertifikat; *.log di-skip)
        info["files"] += _zip_add_tree(
            zf, os.path.join(_ETC, "xray"), "{}/xray".format(stage))
        # website
        info["files"] += _zip_add_tree(
            zf, os.path.join(_WWW, "html"), "{}/html".format(stage))
        # detail
        info["files"] += _zip_add_tree(
            zf, _DETAIL, "{}/detail".format(stage))
        # config bot (ID Bot): var.txt, database.db, banner.jpg
        for pth in (VAR_FILE, DB_FILE):
            if pth and _zip_add_file(zf, pth,
                                     "{}/bot/{}".format(stage,
                                                        os.path.basename(pth))):
                info["files"] += 1
        if _zip_add_file(zf, os.path.join(_PKG_DIR, "banner.jpg"),
                         "{}/bot/banner.jpg".format(stage)):
            info["files"] += 1
    try:
        info["size"] = os.path.getsize(zip_path)
    except OSError:
        info["size"] = 0
    _cleanup_old_backups()
    return zip_path, info


def _safe_extract(zf, dest):
    """Extract zip secara aman (tolong path absolut / path traversal)."""
    members = []
    for zi in zf.infolist():
        name = zi.filename.replace("\\", "/")
        if name.startswith("/") or ".." in name.split("/"):
            continue
        members.append(zi)
    zf.extractall(dest, members=members)
    return len(members)


def _fix_mode(path, mode):
    try:
        os.chmod(path, mode)
    except OSError:
        pass


def restore_backup_zip(zip_path):
    """Pulihkan file backup ke sistem. Return (sukses, pesan).
    Mendukung zip buatan fitur ini maupun zip lama 'cadangkan-bot'
    (yang berisi folder backup/ di root zip)."""
    if not os.path.isfile(zip_path):
        return False, "File backup tidak ditemukan."
    if not zipfile.is_zipfile(zip_path):
        return False, "File bukan backup .zip yang valid."
    base = os.path.join(WORK_DIR,
                        "restore-{}".format(int(time.time())))
    try:
        os.makedirs(base, exist_ok=True)
        with zipfile.ZipFile(zip_path) as zf:
            _safe_extract(zf, base)
    except Exception as e:
        shutil.rmtree(base, ignore_errors=True)
        return False, "Gagal mengekstrak backup: {}".format(e)
    src = os.path.join(base, "backup")
    if not os.path.isdir(src):
        src = base   # zip tanpa folder backup/ di root
    done = []

    def cf(rel, dst, mode=None):
        p = os.path.join(src, rel)
        if os.path.isfile(p):
            try:
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(p, dst)
                if mode is not None:
                    _fix_mode(dst, mode)
                done.append(rel)
                return True
            except Exception:
                pass
        return False

    def ct(rel, dst):
        p = os.path.join(src, rel)
        if os.path.isdir(p):
            try:
                shutil.copytree(p, dst, dirs_exist_ok=True)
                done.append(rel + "/")
                return True
            except Exception:
                pass
        return False

    etc = _ETC
    for name in _SINGLE_FILES:
        mode = 0o600 if name in ("shadow", "gshadow") else 0o644
        cf(name, os.path.join(etc, name), mode)
    for db, svc in ((".vmess.db", "vmess"), (".vless.db", "vless"),
                    (".trojan.db", "trojan"),
                    (".shadowsocks.db", "shadowsocks")):
        cf(db, os.path.join(etc, svc, db), 0o644)
    for name in _SERVICE_DIRS:
        ct(name, os.path.join(etc, name))
    ct("xray", os.path.join(etc, "xray"))
    ct("html", os.path.join(_WWW, "html"))
    ct("detail", _DETAIL)
    # config bot di dalam backup TIDAK langsung ditimpa (token bisa
    # beda VPS / beda bot). Disimpan sebagai cadangan, dipasang manual.
    bot_note = ""
    bot_src = os.path.join(src, "bot")
    if os.path.isdir(bot_src):
        stage_bot = os.path.join(WORK_DIR, "restored-bot")
        try:
            os.makedirs(stage_bot, exist_ok=True)
            saved = []
            for fn in ("var.txt", "database.db"):
                if os.path.isfile(os.path.join(bot_src, fn)):
                    shutil.copy2(os.path.join(bot_src, fn),
                                 os.path.join(stage_bot, fn))
                    _fix_mode(os.path.join(stage_bot, fn), 0o600)
                    saved.append(fn)
            if os.path.isfile(os.path.join(bot_src, "banner.jpg")):
                try:
                    shutil.copy2(os.path.join(bot_src, "banner.jpg"),
                                 os.path.join(_PKG_DIR, "banner.jpg"))
                    saved.append("banner.jpg (terpasang)")
                except Exception:
                    pass
            if saved:
                bot_note = (
                    "Config bot disimpan di {} ({}) - copy manual "
                    "kalau mau memakai token/domain dari backup."
                    .format(stage_bot, ", ".join(saved)))
        except Exception:
            pass
    shutil.rmtree(base, ignore_errors=True)
    if not done:
        return False, ("Tidak ada file yang bisa dipulihkan. Pastikan "
                       "file zip berasal dari backup bot/script yang benar.")
    # restart service xray best-effort (abaikan kalau gagal)
    try:
        subprocess.run("systemctl restart xray", shell=True,
                       stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL, timeout=60)
    except Exception:
        pass
    note = "{} item dipulihkan: {}".format(len(done), ", ".join(done))
    if bot_note:
        note += "\n" + bot_note
    return True, note


# ============================================================
# === HANDLER TOMBOL ===
# ============================================================

@bot.on(events.CallbackQuery(data=cbx("botbackup")))
async def backup_idbot(event):
    """Backup Via ID Bot: bot membuat zip backup lalu mengirim
    filenya langsung ke chat admin (pakai BOT_TOKEN bot ini)."""
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Buy Premium Chat: @zenviora_id",
                                  alert=True)
    try:
        await event.edit("**Please Wait...**")
    except Exception:
        pass
    try:
        zip_path, info = create_backup_zip()
    except Exception as e:
        return await event.respond(
            "**❌ Backup gagal:**\n`{}`".format(e),
            buttons=[[Button.inline("‹ Main Menu ›", cbx("menu"), style="primary")]])
    # kirim file (bukan lewat jalur banner) -> hapus pesan loading manual
    try:
        await _flush_loading(event)
    except Exception:
        pass
    size = convert_size(info["size"]) if info["size"] else "0B"
    msg = (
        "**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**\n"
        "**┃   ⟨BACKUP VIA ID BOT⟩**\n"
        "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
        "**┃   ✅ Backup Berhasil**\n"
        "**┃   📅 Tanggal :** `{}`\n"
        "**┃   🌐 IP Server :** `{}`\n"
        "**┃   🌍 Domain :** `{}`\n"
        "**┃   📦 Isi Backup :** `{} File`\n"
        "**┃   💾 Ukuran :** `{}`\n"
        "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
        "**┃   File backup dikirim oleh bot**\n"
        "**┃   ini (ID Bot) ke chat admin.**\n"
        "**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**\n"
        "**» 🤖@zenviora_id**"
    ).format(info["date"], info["ip"] or "-", info["domain"],
             info["files"], size)
    try:
        await event.respond(msg, file=zip_path, force_document=True,
                            buttons=[[Button.inline("‹ Main Menu ›",
                                                    cbx("menu"), style="primary")]])
    except Exception:
        # gagal kirim dokumen (jarang) -> kirim info + lokasi file saja
        await event.respond(
            msg + "\n**📦 File :** `{}`".format(zip_path),
            buttons=[[Button.inline("‹ Main Menu ›", cbx("menu"), style="primary")]])
    # kirim juga ke ID admin lain di var.txt (best effort)
    try:
        for admin in ADMINS:
            if str(admin) == str(sender.id):
                continue
            try:
                await bot.send_file(int(admin), zip_path, caption=msg,
                                    force_document=True)
            except Exception:
                continue
    except Exception:
        pass


@bot.on(events.CallbackQuery(data=cbx("botrestore")))
async def restore_idbot(event):
    """Restore Via ID Bot: admin kirim / forward file .zip backup
    (atau link download), bot yang mengekstrak & memulihkan."""
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Buy Premium Chat: @zenviora_id",
                                  alert=True)
    chat_id = event.chat_id
    menu_btn = [[Button.inline("‹ Main Menu ›", cbx("menu"), style="primary")]]
    prompt = (
        "**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**\n"
        "**┃   ⟨RESTORE VIA ID BOT⟩**\n"
        "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
        "**┃   📤 Kirim / forward FILE**\n"
        "**┃   backup (.zip) ke chat ini,**\n"
        "**┃   atau kirim link download.**\n"
        "**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**\n"
        "**Ketik** `/cancel` **untuk membatalkan.**")
    async with bot.conversation(chat_id) as conv:
        await event.respond(prompt, buttons=None)
        try:
            resp = await conv.wait_event(
                events.NewMessage(incoming=True, from_users=sender.id),
                timeout=300)
        except asyncio.TimeoutError:
            return await event.respond(
                "**⏱ Waktu input habis (5 menit). Restore dibatalkan.**",
                buttons=menu_btn)
        raw = (resp.raw_text or "").strip()
        if raw.lower() in ("/cancel", ".cancel", "cancel", "!cancel"):
            return await event.respond("**❌ Restore dibatalkan.**",
                                       buttons=menu_btn)
        os.makedirs(WORK_DIR, exist_ok=True)
        zip_path = os.path.join(WORK_DIR, "restore-upload.zip")
        try:
            if resp.file is not None:
                name = (resp.file.name or "").lower()
                if name and not name.endswith(".zip"):
                    return await event.respond(
                        "**❌ File harus backup dalam format .zip**",
                        buttons=menu_btn)
                await asyncio.wait_for(
                    resp.download_media(file=zip_path), timeout=600)
            elif raw.lower().startswith(("http://", "https://")):
                p = subprocess.run(["wget", "-q", "-O", zip_path, raw],
                                   timeout=600)
                if p.returncode != 0:
                    return await event.respond(
                        "**❌ Gagal mengunduh file dari link tersebut.**",
                        buttons=menu_btn)
            else:
                return await event.respond(
                    "**❌ Kirim FILE backup (.zip) atau link download.**",
                    buttons=menu_btn)
        except asyncio.TimeoutError:
            return await event.respond(
                "**⏱ Mengambil file backup gagal (timeout).**",
                buttons=menu_btn)
        except Exception as e:
            return await event.respond(
                "**❌ Gagal mengambil file backup:**\n`{}`".format(e),
                buttons=menu_btn)
        await event.respond("**Loading......**")
        ok, note = restore_backup_zip(zip_path)
        if not ok:
            return await event.respond(
                "**❌ Restore gagal:**\n{}".format(note),
                buttons=menu_btn)
        # hitung jumlah item dari note (format: "N item dipulihkan: ...")
        try:
            n_items = int(note.split("item")[0].strip())
        except Exception:
            n_items = "?"
        msg = (
            "**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**\n"
            "**┃   ⟨RESTORE VIA ID BOT⟩**\n"
            "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
            "**┃   ✅ Restore Berhasil**\n"
            "**┃   📦 {} item dipulihkan**\n"
            "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
            "**┃   Service xray di-restart**\n"
            "**┃   otomatis. Reboot VPS**\n"
            "**┃   disarankan setelah ini.**\n"
            "**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**\n"
            "**» 🤖@zenviora_id**"
        ).format(n_items)
        detail = note if "\n" not in note else note.replace("\n", "\n📝 ")
        await event.respond(msg + "\n📝 " + detail, buttons=menu_btn)


# ============================================================
# === AUTO BACKUP TERJADWAL (SET AUTO WAKTU BACKUP) ===
# ============================================================
# Backup otomatis sesuai jadwal yang dipilih admin. Hasil zip
# DIKIRIM OLEH BOT INI ke chat admin (sama seperti Backup Via
# ID Bot), jadi file backup tetap aman di Telegram walau server
# tiba-tiba mati / hilang.
#
#   - Jadwal diatur lewat Menu Settings -> Backup & Restore ->
#     "⏰ Auto Backup" (preset 1/3/6/12 jam atau custom:
#     "6h" tiap 6 jam, "30m" tiap 30 menit, "12:30" tiap hari).
#   - Setting disimpan di /root/.idbot-backup/autobackup.conf
#     sehingga TETAP AKTIF setelah bot/server di-restart.
#   - Kalau bot/server mati melewati jadwal, backup langsung
#     dijalankan beberapa detik setelah bot hidup lagi.
#   - Backup gagal (mis. internet putus) dicoba ulang tiap
#     10 menit sampai berhasil.
# ============================================================

AUTO_MIN_INTERVAL = 600     # jadwal tercepat yang diizinkan (10 menit)
AUTO_BOOT_DELAY = 15        # tunggu bot siap setelah start (detik)
AUTO_TICK = 20              # interval cek jadwal (detik)
AUTO_RETRY_DELAY = 600      # ulangi backup gagal setelah (detik)

_AUTO_STATE = {"next": 0.0, "running": False, "retry": 0.0, "fails": 0}


# ---------- config (persisten di disk) ----------

def _auto_conf_path():
    try:
        return os.path.join(WORK_DIR, "autobackup.conf")
    except Exception:
        return "/root/.idbot-backup/autobackup.conf"


def _auto_conf_load():
    """Baca setting auto backup. Default: MATI."""
    conf = {"mode": "off", "value": "", "last": 0.0}
    try:
        with open(_auto_conf_path()) as f:
            for raw in f:
                line = raw.strip()
                if not line or "=" not in line:
                    continue
                k, v = line.split("=", 1)
                k = k.strip().lower()
                if k == "mode":
                    conf["mode"] = v.strip().lower()
                elif k == "value":
                    conf["value"] = v.strip()
                elif k == "last":
                    try:
                        conf["last"] = float(v.strip() or 0)
                    except ValueError:
                        pass
    except Exception:
        pass
    return conf


def _auto_conf_save(mode, value="", last=None):
    """Simpan setting auto backup (mode/value/last-run)."""
    if last is None:
        last = time.time()
    try:
        os.makedirs(WORK_DIR, exist_ok=True)
        with open(_auto_conf_path(), "w") as f:
            f.write("mode={}\nvalue={}\nlast={}\n".format(
                mode, value or "", float(last)))
    except Exception:
        pass


def _parse_auto_input(text):
    """Parse input admin 'set waktu auto backup'.
    Return (mode, value) atau (None, pesan_kesalahan)."""
    t = (text or "").strip().lower()
    if not t:
        return None, "Input kosong."
    # 12:30 / 12.30 -> setiap hari jam 12:30
    m = re.match(r"^(\d{1,2})\s*[:.]\s*(\d{1,2})$", t)
    if m:
        hh, mm = int(m.group(1)), int(m.group(2))
        if hh > 23 or mm > 59:
            return None, "Jam harus 00:00 - 23:59."
        return "daily", "{:02d}:{:02d}".format(hh, mm)
    # 30m / 30 menit / 30min -> interval menit
    m = re.match(r"^(\d{1,4})\s*(m|menit|min|minutes?)\.?$", t)
    if m:
        menit = int(m.group(1))
        if menit < 10:
            return None, "Minimal 10 menit."
        return "interval", str(min(menit, 1440) * 60)
    # 6 / 6h / 6j / 6 jam -> interval jam
    m = re.match(r"^(\d{1,3})\s*(h|j|jam|hour|hours)?\.?$", t)
    if m:
        jam = int(m.group(1))
        if jam < 1:
            return None, "Minimal 1 jam."
        return "interval", str(min(jam, 720) * 3600)
    return None, ("Format tidak dikenal. Contoh: 6h (tiap 6 jam), "
                  "30m (tiap 30 menit), 12:30 (tiap hari jam 12:30).")


def _auto_jadwal_text(conf):
    """Jadwal dalam bentuk teks manusiawi."""
    mode = (conf.get("mode") or "off").strip()
    if mode == "interval":
        try:
            sec = int(float(conf.get("value")))
        except Exception:
            sec = 21600
        sec = max(sec, AUTO_MIN_INTERVAL)
        if sec % 3600 == 0:
            return "Setiap {} Jam".format(sec // 3600)
        if sec % 60 == 0:
            return "Setiap {} Menit".format(sec // 60)
        return "Setiap {} Detik".format(sec)
    if mode == "daily":
        return "Setiap Hari Jam {}".format(conf.get("value") or "00:00")
    return "MATI (Nonaktif)"


def _auto_next_run(conf, now=None):
    """Timestamp backup berikutnya sesuai jadwal.
    Boleh berada di masa lalu -> berarti backup harus SEGERA
    dijalankan (mis. bot/server sempat mati). 0 kalau off."""
    mode = (conf.get("mode") or "off").strip()
    now = now if now is not None else time.time()
    last = float(conf.get("last") or 0)
    if mode == "interval":
        try:
            iv = int(float(conf.get("value")))
        except Exception:
            iv = 21600
        iv = max(iv, AUTO_MIN_INTERVAL)
        return last + iv
    if mode == "daily":
        m = re.match(r"^(\d{1,2}):(\d{2})$", str(conf.get("value") or ""))
        if m:
            hh, mm = int(m.group(1)), int(m.group(2))
        else:
            hh, mm = 0, 0
        target = DT.datetime.now().replace(hour=hh, minute=mm,
                                           second=0, microsecond=0)
        ttarget = target.timestamp()
        if ttarget > now:
            return ttarget
        if last < ttarget:
            # jam backup hari ini terlewat (bot mati) ->
            # return jadwal hari ini (= masa lalu) -> segera jalan
            return ttarget
        return (target + DT.timedelta(days=1)).timestamp()
    return 0.0


def _fmt_dt(ts):
    try:
        return DT.datetime.fromtimestamp(float(ts)).strftime("%d-%m-%Y %H:%M")
    except Exception:
        return "-"


def _auto_display_next(conf):
    """Backup berikutnya utk ditampilkan (ikutkan retry pending)."""
    mode = (conf.get("mode") or "off").strip()
    if mode not in ("interval", "daily"):
        return "-"
    nxt = float(_AUTO_STATE.get("retry") or 0)
    if nxt > time.time():
        return "{} (coba lagi)".format(_fmt_dt(nxt))
    nxt = _auto_next_run(conf)
    if nxt and nxt <= time.time():
        return "Segera"
    return _fmt_dt(nxt)


# ---------- pengiriman ----------

def _all_admin_ids():
    """Semua ID admin (dari database bot + var.txt)."""
    ids = []
    try:
        db = get_db()
        for r in db.execute("SELECT user_id FROM admin").fetchall():
            s = str(r[0])
            if s and s not in ids:
                ids.append(s)
    except Exception:
        pass
    try:
        for a in ADMINS:
            s = str(a)
            if s and s not in ids:
                ids.append(s)
    except Exception:
        pass
    return ids


def _auto_caption(info, jadwal):
    size = convert_size(info["size"]) if info["size"] else "0B"
    now = DT.datetime.now()
    return (
        "**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**\n"
        "**┃   ⟨AUTO BACKUP⟩**\n"
        "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
        "**┃   ✅ Backup Otomatis Berhasil**\n"
        "**┃   📅 Tanggal :** `{}`\n"
        "**┃   🕒 Jam :** `{}`\n"
        "**┃   ⏰ Jadwal :** `{}`\n"
        "**┃   🌐 IP Server :** `{}`\n"
        "**┃   🌍 Domain :** `{}`\n"
        "**┃   📦 Isi Backup :** `{} File`\n"
        "**┃   💾 Ukuran :** `{}`\n"
        "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
        "**┃   File backup dikirim otomatis**\n"
        "**┃   bot ini ke chat admin sebagai**\n"
        "**┃   jaga-jaga server mati.**\n"
        "**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**\n"
        "**» 🤖@zenviora_id**"
    ).format(now.strftime("%d-%m-%Y"), now.strftime("%H:%M:%S"), jadwal,
             info["ip"] or "-", info["domain"], info["files"], size)


async def _auto_backup_run(conf=None):
    """Buat zip backup lalu kirim ke semua admin.
    Return (ok, detail) - detail = info dict saat sukses,
    pesan kesalahan saat gagal."""
    if conf is None:
        conf = _auto_conf_load()
    jadwal = _auto_jadwal_text(conf)
    try:
        loop = asyncio.get_running_loop()
        zip_path, info = await loop.run_in_executor(None, create_backup_zip)
    except Exception as e:
        return False, "Gagal membuat zip backup: {}".format(e)
    caption = _auto_caption(info, jadwal)
    sent = 0
    for admin in _all_admin_ids():
        try:
            await bot.send_file(int(admin), zip_path, caption=caption,
                                force_document=True)
            sent += 1
        except Exception:
            continue
    if not sent:
        return False, ("File backup tidak bisa dikirim. Pastikan admin "
                       "sudah pernah menekan /start di bot ini.")
    return True, info


async def _auto_notify_error(detail):
    """Kabari admin kalau auto backup gagal (best effort)."""
    alasan = str(detail or "-")
    if len(alasan) > 300:
        alasan = alasan[:300] + "..."
    msg = (
        "**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**\n"
        "**┃   ⟨AUTO BACKUP GAGAL⟩**\n"
        "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
        "**┃   ❌ Backup otomatis gagal**\n"
        "**┃   🕒 Waktu :** `{}`\n"
        "**┃   » Alasan :**\n"
        "**┃** `{}`\n"
        "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
        "**┃   Bot mencoba lagi otomatis**\n"
        "**┃   10 menit kemudian.**\n"
        "**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**\n"
        "**» 🤖@zenviora_id**"
    ).format(_fmt_dt(time.time()), alasan)
    for admin in _all_admin_ids():
        try:
            await bot.send_message(int(admin), msg)
        except Exception:
            continue


# ---------- scheduler (task latar belakang) ----------

async def _autobackup_loop():
    await asyncio.sleep(AUTO_BOOT_DELAY)
    while True:
        try:
            conf = _auto_conf_load()
            mode = (conf.get("mode") or "off").strip()
            if mode not in ("interval", "daily"):
                _AUTO_STATE["next"] = 0.0
                _AUTO_STATE["retry"] = 0.0
                await asyncio.sleep(AUTO_TICK)
                continue
            now = time.time()
            nxt = float(_AUTO_STATE.get("retry") or 0)
            if nxt <= 0:
                nxt = _auto_next_run(conf)
            _AUTO_STATE["next"] = nxt
            if nxt > now:
                await asyncio.sleep(min(nxt - now, AUTO_TICK))
                continue
            if _AUTO_STATE.get("running"):
                await asyncio.sleep(AUTO_TICK)
                continue
            _AUTO_STATE["running"] = True
            try:
                ok, detail = await _auto_backup_run(conf)
            finally:
                _AUTO_STATE["running"] = False
            if ok:
                _AUTO_STATE["retry"] = 0.0
                _AUTO_STATE["fails"] = 0
                conf2 = _auto_conf_load()
                if (conf2.get("mode") or "off") in ("interval", "daily"):
                    _auto_conf_save(conf2.get("mode"), conf2.get("value"),
                                    last=time.time())
            else:
                fails = int(_AUTO_STATE.get("fails") or 0) + 1
                _AUTO_STATE["fails"] = fails
                _AUTO_STATE["retry"] = time.time() + AUTO_RETRY_DELAY
                # kabari admin: gagal pertama & tiap 6x gagal beruntun
                if fails == 1 or fails % 6 == 0:
                    try:
                        await _auto_notify_error(detail)
                    except Exception:
                        pass
            await asyncio.sleep(2)
        except asyncio.CancelledError:
            raise
        except Exception as e:
            try:
                print("[auto-backup] loop:", e)
            except Exception:
                pass
            await asyncio.sleep(AUTO_TICK)


def _start_autobackup_loop():
    try:
        loop = getattr(bot, "loop", None)
        if loop is not None:
            loop.create_task(_autobackup_loop())
    except Exception:
        pass


_start_autobackup_loop()


# ---------- handler tombol ----------

def _auto_menu_msg(conf):
    mode = (conf.get("mode") or "off").strip()
    aktif = mode in ("interval", "daily")
    status = "✅ AKTIF" if aktif else "❌ MATI"
    last = float(conf.get("last") or 0)
    last_s = _fmt_dt(last) if last else "Belum pernah"
    return (
        "**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**\n"
        "**┃   ⟨AUTO BACKUP⟩**\n"
        "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
        "**┃   » Status :** `{}`\n"
        "**┃   » Jadwal :** `{}`\n"
        "**┃   » Backup Terakhir :** `{}`\n"
        "**┃   » Backup Berikutnya :** `{}`\n"
        "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
        "**┃   Backup otomatis dikirim bot**\n"
        "**┃   ini ke chat admin sesuai**\n"
        "**┃   jadwal (jaga-jaga server**\n"
        "**┃   tiba-tiba mati).**\n"
        "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
        "**┃   Set Waktu Custom contoh:**\n"
        "**┃   `6h` = tiap 6 jam**\n"
        "**┃   `30m` = tiap 30 menit**\n"
        "**┃   `12:30` = tiap hari jam 12:30**\n"
        "**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**\n"
        "**» 🤖@zenviora_id**"
    ).format(status, _auto_jadwal_text(conf), last_s,
             _auto_display_next(conf))


def _auto_menu_buttons(conf):
    mode = (conf.get("mode") or "off").strip()
    # Layout rapih per baris (warna seragam dalam 1 baris):
    #   Baris 1-2 HIJAU (success) : pilih jadwal cepat
    #   Baris 3 HIJAU (success) : custom & backup manual
    #   Baris 4 MERAH (danger)  : matikan auto backup (kalau aktif)
    #   Baris 5 BIRU (primary)  : navigasi
    inline = [
        [Button.inline("⏰ 1 Jam", cbx("autob1"), style="success"),
         Button.inline("⏰ 3 Jam", cbx("autob3"), style="success")],
        [Button.inline("⏰ 6 Jam", cbx("autob6"), style="success"),
         Button.inline("⏰ 12 Jam", cbx("autob12"), style="success")],
        [Button.inline("⏰ Set Waktu Custom", cbx("autoset"), style="success"),
         Button.inline("📦 Backup Sekarang", cbx("botbackup"), style="success")],
    ]
    if mode in ("interval", "daily"):
        inline.append([Button.inline("❌ Matikan Auto Backup",
                                     cbx("autooff"), style="danger")])
    inline.append([Button.inline("‹ Back ›", cbx("backer"), style="primary")])
    return inline


@bot.on(events.CallbackQuery(data=cbx("autobackup")))
async def autobackup_menu(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Buy Premium Chat: @zenviora_id",
                                  alert=True)
    conf = _auto_conf_load()
    try:
        await event.edit(_auto_menu_msg(conf),
                         buttons=_auto_menu_buttons(conf))
    except Exception:
        pass


async def _auto_apply(event, mode, value):
    """Simpan jadwal baru lalu tampilkan konfirmasi."""
    _auto_conf_save(mode, value, last=time.time())
    _AUTO_STATE["retry"] = 0.0
    _AUTO_STATE["fails"] = 0
    conf = {"mode": mode, "value": value, "last": time.time()}
    msg = (
        "**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**\n"
        "**┃   ⟨AUTO BACKUP⟩**\n"
        "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
        "**┃   ✅ Auto Backup DIAKTIFKAN**\n"
        "**┃   ⏰ Jadwal :** `{}`\n"
        "**┃   📦 Backup Pertama :** `{}`\n"
        "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
        "**┃   File backup dikirim otomatis**\n"
        "**┃   ke chat admin oleh bot ini.**\n"
        "**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**\n"
        "**» 🤖@zenviora_id**"
    ).format(_auto_jadwal_text(conf), _fmt_dt(_auto_next_run(conf)))
    btn = [[Button.inline("⏰ Menu Auto Backup", cbx("autobackup"), style="primary")],
           [Button.inline("‹ Back ›", cbx("backer"), style="primary")]]
    try:
        await event.edit(msg, buttons=btn)
    except Exception:
        pass


@bot.on(events.CallbackQuery(data=cbx("autob1")))
async def autob1(event):
    await _auto_apply(event, "interval", "3600")


@bot.on(events.CallbackQuery(data=cbx("autob3")))
async def autob3(event):
    await _auto_apply(event, "interval", "10800")


@bot.on(events.CallbackQuery(data=cbx("autob6")))
async def autob6(event):
    await _auto_apply(event, "interval", "21600")


@bot.on(events.CallbackQuery(data=cbx("autob12")))
async def autob12(event):
    await _auto_apply(event, "interval", "43200")


@bot.on(events.CallbackQuery(data=cbx("autooff")))
async def autooff(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Buy Premium Chat: @zenviora_id",
                                  alert=True)
    _auto_conf_save("off", "", last=_auto_conf_load().get("last") or 0.0)
    _AUTO_STATE["retry"] = 0.0
    _AUTO_STATE["fails"] = 0
    msg = (
        "**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**\n"
        "**┃   ⟨AUTO BACKUP⟩**\n"
        "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
        "**┃   ❌ Auto Backup DIMATIKAN**\n"
        "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
        "**┃   Backup manual masih bisa**\n"
        "**┃   lewat tombol Backup Via**\n"
        "**┃   ID Bot di menu Backup.**\n"
        "**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**\n"
        "**» 🤖@zenviora_id**"
    )
    btn = [[Button.inline("⏰ Menu Auto Backup", cbx("autobackup"), style="primary")],
           [Button.inline("‹ Back ›", cbx("backer"), style="primary")]]
    try:
        await event.edit(msg, buttons=btn)
    except Exception:
        pass


@bot.on(events.CallbackQuery(data=cbx("autoset")))
async def autoset(event):
    """Set waktu auto backup custom via input admin."""
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Buy Premium Chat: @zenviora_id",
                                  alert=True)
    menu_btn = [[Button.inline("⏰ Menu Auto Backup", cbx("autobackup"), style="primary")],
                [Button.inline("‹ Back ›", cbx("backer"), style="primary")]]
    prompt = (
        "**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**\n"
        "**┃   ⟨SET WAKTU AUTO BACKUP⟩**\n"
        "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
        "**┃   Kirim waktu backup:**\n"
        "**┃   `6h` / `6` = tiap 6 jam**\n"
        "**┃   `30m` = tiap 30 menit**\n"
        "**┃   `12:30` = tiap hari jam 12:30**\n"
        "**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**\n"
        "**Ketik** `/cancel` **untuk membatalkan.**")
    async with bot.conversation(event.chat_id) as conv:
        await event.respond(prompt, buttons=None)
        try:
            resp = await conv.wait_event(
                events.NewMessage(incoming=True, from_users=sender.id),
                timeout=180)
        except asyncio.TimeoutError:
            return await event.respond(
                "**⏱ Waktu input habis (3 menit). Set waktu dibatalkan.**",
                buttons=menu_btn)
        raw = (resp.raw_text or "").strip()
        if raw.lower() in ("/cancel", ".cancel", "cancel", "!cancel"):
            return await event.respond("**❌ Set waktu dibatalkan.**",
                                       buttons=menu_btn)
        mode, value = _parse_auto_input(raw)
        if mode is None:
            return await event.respond("**❌ {}**".format(value),
                                       buttons=menu_btn)
        _auto_conf_save(mode, value, last=time.time())
        _AUTO_STATE["retry"] = 0.0
        _AUTO_STATE["fails"] = 0
        conf = {"mode": mode, "value": value, "last": time.time()}
        msg = (
            "**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**\n"
            "**┃   ⟨AUTO BACKUP⟩**\n"
            "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
            "**┃   ✅ Waktu Backup Disimpan**\n"
            "**┃   ⏰ Jadwal :** `{}`\n"
            "**┃   📦 Backup Pertama :** `{}`\n"
            "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
            "**┃   File backup dikirim otomatis**\n"
            "**┃   ke chat admin oleh bot ini.**\n"
            "**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**\n"
            "**» 🤖@zenviora_id**"
        ).format(_auto_jadwal_text(conf), _fmt_dt(_auto_next_run(conf)))
        await event.respond(msg, buttons=menu_btn)
