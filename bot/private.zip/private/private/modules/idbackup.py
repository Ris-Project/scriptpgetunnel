from private import *
import os
import stat
import time
import shutil
import zipfile
import datetime as DT
import subprocess
import requests
import asyncio
import re
from telethon import events, Button

env = load_env_vars()
DOMAIN = env.get("DOMAIN", "Tidak Diketahui")

# ============================================================
# === BACKUP & RESTORE VIA ID BOT ===
# ============================================================
# Backup & restore dilakukan LANGSUNG oleh bot ini (memakai
# BOT_TOKEN sendiri / "ID Bot"), tanpa perlu Setup Token-ID,
# rclone, atau Google Drive:
#
#   - BACKUP  : file-file penting server + config bot (var.txt,
#     database.db, banner.jpg) dikumpulkan jadi 1 file .zip lalu
#     DIKIRIM OLEH BOT ke chat admin (ID admin di var.txt juga
#     dikirim best-effort). Isi & formatnya sama dengan script
#     'cadangkan-bot' lama (folder backup/ di dalam zip), jadi
#     hasilnya tetap bisa di-restore dengan 'bot-restore' lama.
#
#   - RESTORE : admin kirim / forward FILE .zip backup ke chat
#     bot (atau kirim link download), bot yang mengekstrak dan
#     memulihkan semuanya, lalu service xray di-restart.
# ============================================================

# --- lokasi sumber backup & tujuan restore (mengikuti script lama) ---
_ETC = "/etc"
_WWW = "/var/www"
_DETAIL = "/detail"

# folder bot (var.txt / database.db) & folder package bot (banner.jpg)
_BOT_DIR = os.path.dirname(os.path.abspath(VAR_FILE))
_PKG_DIR = os.path.dirname(os.path.abspath(__file__))

WORK_DIR = "/root/.idbot-backup"   # folder kerja zip backup / restore

_SINGLE_FILES = ("passwd", "group", "shadow", "gshadow", "crontab")
_DB_FILES = (".vmess.db", ".vless.db", ".trojan.db", ".shadowsocks.db")
_SERVICE_DIRS = ("limit", "vmess", "vless", "trojan", "shadowsocks")
_MAX_FILE_BYTES = 100 * 1024 * 1024        # skip file > 100 MB (mis. log)
_SKIP_SUFFIX = (".log", ".session", ".pyc", ".pyo")


def _zip_add_file(zf, path, arcname):
    """Tambah satu file ke zip (skip kalau tidak ada / terlalu besar).
    Permission asli ikut disimpan supaya restore mengembalikannya."""
    try:
        st = os.stat(path)
    except OSError:
        return False
    if not stat.S_ISREG(st.st_mode) or st.st_size > _MAX_FILE_BYTES:
        return False
    if str(path).endswith(_SKIP_SUFFIX):
        return False
    try:
        zf.write(path, arcname, zipfile.ZIP_DEFLATED)
        return True
    except Exception:
        return False


def _zip_add_tree(zf, path, arcname):
    """Tambah seluruh isi folder (rekursif) ke zip. Return jumlah file."""
    if not os.path.isdir(path):
        return 0
    n = 0
    for root, dirs, files in os.walk(path):
        dirs.sort()
        for f in sorted(files):
            fp = os.path.join(root, f)
            rel = os.path.relpath(fp, path)
            if _zip_add_file(zf, fp, os.path.join(arcname, rel)):
                n += 1
    return n


def _cleanup_old_backups(keep=5):
    """Simpan maksimal `keep` zip backup terakhir di WORK_DIR."""
    try:
        files = [os.path.join(WORK_DIR, f) for f in os.listdir(WORK_DIR)
                 if f.endswith(".zip")]
        files.sort(key=os.path.getmtime, reverse=True)
        for old in files[keep:]:
            try:
                os.remove(old)
            except OSError:
                pass
    except Exception:
        pass


def create_backup_zip():
    """Buat file zip backup server + config bot.
    Return (path_zip, info_dict)."""
    os.makedirs(WORK_DIR, exist_ok=True)
    ip = ""
    for url in ("https://api.ipify.org", "http://icanhazip.com"):
        try:
            ip = requests.get(url, timeout=5).text.strip()
            if ip:
                break
        except Exception:
            continue
    try:
        domain = load_env_vars().get("DOMAIN") or DOMAIN or "-"
    except Exception:
        domain = DOMAIN or "-"
    stamp = DT.datetime.now().strftime("%d-%m-%Y")
    zip_path = os.path.join(
        WORK_DIR, "backup-{}-{}.zip".format(stamp, time.strftime("%H%M%S")))
    stage = "backup"   # nama folder di dalam zip (kompatibel bot-restore)
    info = {"files": 0, "date": stamp, "ip": ip, "domain": domain,
            "path": zip_path, "size": 0}
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        # file tunggal /etc (passwd, group, shadow, gshadow, crontab)
        for name in _SINGLE_FILES:
            if _zip_add_file(zf, os.path.join(_ETC, name),
                             "{}/{}".format(stage, name)):
                info["files"] += 1
        # database user xray (root zip backup, sama seperti script lama)
        for db, svc in ((".vmess.db", "vmess"), (".vless.db", "vless"),
                        (".trojan.db", "trojan"),
                        (".shadowsocks.db", "shadowsocks")):
            if _zip_add_file(zf, os.path.join(_ETC, svc, db),
                             "{}/{}".format(stage, db)):
                info["files"] += 1
        # folder layanan (limit, vmess, vless, trojan, shadowsocks)
        for name in _SERVICE_DIRS:
            info["files"] += _zip_add_tree(
                zf, os.path.join(_ETC, name), "{}/{}".format(stage, name))
        # config xray (config.json, db, sertifikat; *.log di-skip)
        info["files"] += _zip_add_tree(
            zf, os.path.join(_ETC, "xray"), "{}/xray".format(stage))
        # website
        info["files"] += _zip_add_tree(
            zf, os.path.join(_WWW, "html"), "{}/html".format(stage))
        # detail
        info["files"] += _zip_add_tree(
            zf, _DETAIL, "{}/detail".format(stage))
        # config bot (ID Bot): var.txt, database.db, banner.jpg
        for pth in (VAR_FILE, DB_FILE):
            if pth and _zip_add_file(zf, pth,
                                     "{}/bot/{}".format(stage,
                                                        os.path.basename(pth))):
                info["files"] += 1
        if _zip_add_file(zf, os.path.join(_PKG_DIR, "banner.jpg"),
                         "{}/bot/banner.jpg".format(stage)):
            info["files"] += 1
    try:
        info["size"] = os.path.getsize(zip_path)
    except OSError:
        info["size"] = 0
    _cleanup_old_backups()
    return zip_path, info


def _safe_extract(zf, dest):
    """Extract zip secara aman (tolong path absolut / path traversal)."""
    members = []
    for zi in zf.infolist():
        name = zi.filename.replace("\\", "/")
        if name.startswith("/") or ".." in name.split("/"):
            continue
        members.append(zi)
    zf.extractall(dest, members=members)
    return len(members)


def _fix_mode(path, mode):
    try:
        os.chmod(path, mode)
    except OSError:
        pass


def restore_backup_zip(zip_path):
    """Pulihkan file backup ke sistem. Return (sukses, pesan).
    Mendukung zip buatan fitur ini maupun zip lama 'cadangkan-bot'
    (yang berisi folder backup/ di root zip)."""
    if not os.path.isfile(zip_path):
        return False, "File backup tidak ditemukan."
    if not zipfile.is_zipfile(zip_path):
        return False, "File bukan backup .zip yang valid."
    base = os.path.join(WORK_DIR,
                        "restore-{}".format(int(time.time())))
    try:
        os.makedirs(base, exist_ok=True)
        with zipfile.ZipFile(zip_path) as zf:
            _safe_extract(zf, base)
    except Exception as e:
        shutil.rmtree(base, ignore_errors=True)
        return False, "Gagal mengekstrak backup: {}".format(e)
    src = os.path.join(base, "backup")
    if not os.path.isdir(src):
        src = base   # zip tanpa folder backup/ di root
    done = []

    def cf(rel, dst, mode=None):
        p = os.path.join(src, rel)
        if os.path.isfile(p):
            try:
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(p, dst)
                if mode is not None:
                    _fix_mode(dst, mode)
                done.append(rel)
                return True
            except Exception:
                pass
        return False

    def ct(rel, dst):
        p = os.path.join(src, rel)
        if os.path.isdir(p):
            try:
                shutil.copytree(p, dst, dirs_exist_ok=True)
                done.append(rel + "/")
                return True
            except Exception:
                pass
        return False

    etc = _ETC
    for name in _SINGLE_FILES:
        mode = 0o600 if name in ("shadow", "gshadow") else 0o644
        cf(name, os.path.join(etc, name), mode)
    for db, svc in ((".vmess.db", "vmess"), (".vless.db", "vless"),
                    (".trojan.db", "trojan"),
                    (".shadowsocks.db", "shadowsocks")):
        cf(db, os.path.join(etc, svc, db), 0o644)
    for name in _SERVICE_DIRS:
        ct(name, os.path.join(etc, name))
    ct("xray", os.path.join(etc, "xray"))
    ct("html", os.path.join(_WWW, "html"))
    ct("detail", _DETAIL)
    # config bot di dalam backup TIDAK langsung ditimpa (token bisa
    # beda VPS / beda bot). Disimpan sebagai cadangan, dipasang manual.
    bot_note = ""
    bot_src = os.path.join(src, "bot")
    if os.path.isdir(bot_src):
        stage_bot = os.path.join(WORK_DIR, "restored-bot")
        try:
            os.makedirs(stage_bot, exist_ok=True)
            saved = []
            for fn in ("var.txt", "database.db"):
                if os.path.isfile(os.path.join(bot_src, fn)):
                    shutil.copy2(os.path.join(bot_src, fn),
                                 os.path.join(stage_bot, fn))
                    _fix_mode(os.path.join(stage_bot, fn), 0o600)
                    saved.append(fn)
            if os.path.isfile(os.path.join(bot_src, "banner.jpg")):
                try:
                    shutil.copy2(os.path.join(bot_src, "banner.jpg"),
                                 os.path.join(_PKG_DIR, "banner.jpg"))
                    saved.append("banner.jpg (terpasang)")
                except Exception:
                    pass
            if saved:
                bot_note = (
                    "Config bot disimpan di {} ({}) - copy manual "
                    "kalau mau memakai token/domain dari backup."
                    .format(stage_bot, ", ".join(saved)))
        except Exception:
            pass
    shutil.rmtree(base, ignore_errors=True)
    if not done:
        return False, ("Tidak ada file yang bisa dipulihkan. Pastikan "
                       "file zip berasal dari backup bot/script yang benar.")
    # restart service xray best-effort (abaikan kalau gagal)
    try:
        subprocess.run("systemctl restart xray", shell=True,
                       stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL, timeout=60)
    except Exception:
        pass
    note = "{} item dipulihkan: {}".format(len(done), ", ".join(done))
    if bot_note:
        note += "\n" + bot_note
    return True, note


# ============================================================
# === HANDLER TOMBOL ===
# ============================================================

@bot.on(events.CallbackQuery(data=cbx("botbackup")))
async def backup_idbot(event):
    """Backup Via ID Bot: bot membuat zip backup lalu mengirim
    filenya langsung ke chat admin (pakai BOT_TOKEN bot ini)."""
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Buy Premium Chat: @zenviora_id",
                                  alert=True)
    try:
        await event.edit("**Please Wait...**")
    except Exception:
        pass
    try:
        zip_path, info = create_backup_zip()
    except Exception as e:
        return await event.respond(
            "**❌ Backup gagal:**\n`{}`".format(e),
            buttons=[[Button.inline("‹ Main Menu ›", cbx("menu"))]])
    # kirim file (bukan lewat jalur banner) -> hapus pesan loading manual
    try:
        await _flush_loading(event)
    except Exception:
        pass
    size = convert_size(info["size"]) if info["size"] else "0B"
    msg = (
        "**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**\n"
        "**┃   ⟨BACKUP VIA ID BOT⟩**\n"
        "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
        "**┃   ✅ Backup Berhasil**\n"
        "**┃   📅 Tanggal :** `{}`\n"
        "**┃   🌐 IP Server :** `{}`\n"
        "**┃   🌍 Domain :** `{}`\n"
        "**┃   📦 Isi Backup :** `{} File`\n"
        "**┃   💾 Ukuran :** `{}`\n"
        "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
        "**┃   File backup dikirim oleh bot**\n"
        "**┃   ini (ID Bot) ke chat admin.**\n"
        "**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**\n"
        "**» 🤖@zenviora_id**"
    ).format(info["date"], info["ip"] or "-", info["domain"],
             info["files"], size)
    try:
        await event.respond(msg, file=zip_path, force_document=True,
                            buttons=[[Button.inline("‹ Main Menu ›",
                                                    cbx("menu"))]])
    except Exception:
        # gagal kirim dokumen (jarang) -> kirim info + lokasi file saja
        await event.respond(
            msg + "\n**📦 File :** `{}`".format(zip_path),
            buttons=[[Button.inline("‹ Main Menu ›", cbx("menu"))]])
    # kirim juga ke ID admin lain di var.txt (best effort)
    try:
        for admin in ADMINS:
            if str(admin) == str(sender.id):
                continue
            try:
                await bot.send_file(int(admin), zip_path, caption=msg,
                                    force_document=True)
            except Exception:
                continue
    except Exception:
        pass


@bot.on(events.CallbackQuery(data=cbx("botrestore")))
async def restore_idbot(event):
    """Restore Via ID Bot: admin kirim / forward file .zip backup
    (atau link download), bot yang mengekstrak & memulihkan."""
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Buy Premium Chat: @zenviora_id",
                                  alert=True)
    chat_id = event.chat_id
    menu_btn = [[Button.inline("‹ Main Menu ›", cbx("menu"))]]
    prompt = (
        "**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**\n"
        "**┃   ⟨RESTORE VIA ID BOT⟩**\n"
        "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
        "**┃   📤 Kirim / forward FILE**\n"
        "**┃   backup (.zip) ke chat ini,**\n"
        "**┃   atau kirim link download.**\n"
        "**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**\n"
        "**Ketik** `/cancel` **untuk membatalkan.**")
    async with bot.conversation(chat_id) as conv:
        await event.respond(prompt, buttons=None)
        try:
            resp = await conv.wait_event(
                events.NewMessage(incoming=True, from_users=sender.id),
                timeout=300)
        except asyncio.TimeoutError:
            return await event.respond(
                "**⏱ Waktu input habis (5 menit). Restore dibatalkan.**",
                buttons=menu_btn)
        raw = (resp.raw_text or "").strip()
        if raw.lower() in ("/cancel", ".cancel", "cancel", "!cancel"):
            return await event.respond("**❌ Restore dibatalkan.**",
                                       buttons=menu_btn)
        os.makedirs(WORK_DIR, exist_ok=True)
        zip_path = os.path.join(WORK_DIR, "restore-upload.zip")
        try:
            if resp.file is not None:
                name = (resp.file.name or "").lower()
                if name and not name.endswith(".zip"):
                    return await event.respond(
                        "**❌ File harus backup dalam format .zip**",
                        buttons=menu_btn)
                await asyncio.wait_for(
                    resp.download_media(file=zip_path), timeout=600)
            elif raw.lower().startswith(("http://", "https://")):
                p = subprocess.run(["wget", "-q", "-O", zip_path, raw],
                                   timeout=600)
                if p.returncode != 0:
                    return await event.respond(
                        "**❌ Gagal mengunduh file dari link tersebut.**",
                        buttons=menu_btn)
            else:
                return await event.respond(
                    "**❌ Kirim FILE backup (.zip) atau link download.**",
                    buttons=menu_btn)
        except asyncio.TimeoutError:
            return await event.respond(
                "**⏱ Mengambil file backup gagal (timeout).**",
                buttons=menu_btn)
        except Exception as e:
            return await event.respond(
                "**❌ Gagal mengambil file backup:**\n`{}`".format(e),
                buttons=menu_btn)
        await event.respond("**Loading......**")
        ok, note = restore_backup_zip(zip_path)
        if not ok:
            return await event.respond(
                "**❌ Restore gagal:**\n{}".format(note),
                buttons=menu_btn)
        # hitung jumlah item dari note (format: "N item dipulihkan: ...")
        try:
            n_items = int(note.split("item")[0].strip())
        except Exception:
            n_items = "?"
        msg = (
            "**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**\n"
            "**┃   ⟨RESTORE VIA ID BOT⟩**\n"
            "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
            "**┃   ✅ Restore Berhasil**\n"
            "**┃   📦 {} item dipulihkan**\n"
            "**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**\n"
            "**┃   Service xray di-restart**\n"
            "**┃   otomatis. Reboot VPS**\n"
            "**┃   disarankan setelah ini.**\n"
            "**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**\n"
            "**» 🤖@zenviora_id**"
        ).format(n_items)
        detail = note if "\n" not in note else note.replace("\n", "\n📝 ")
        await event.respond(msg + "\n📝 " + detail, buttons=menu_btn)
