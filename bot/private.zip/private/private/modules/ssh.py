from private import *
import subprocess
import json
import base64
import datetime as DT
import requests
import time
import random
import asyncio
import tempfile
import re
from telethon import events, Button

env = load_env_vars()
DOMAIN = env.get("DOMAIN", "Tidak Diketahui")

@bot.on(events.CallbackQuery(data=cbx("lock-ssh")))
async def lock_ssh(event):
        async def lock_ssh_(event):
                async with bot.conversation(chat) as exp:
                        await event.respond("**Username:**")
                        exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        exp = (await exp).raw_text
                
                cmd = f'printf "%s\n" "{exp}" | bot-lock'
                try:
                        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                except:
                        await event.respond(f"**User** `{exp}` **Successfully Locked**")
                else:
                        msg = f"**User** `{exp}` **Successfully Locked**"
                        await event.respond(msg)
        chat = event.chat_id
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await lock_ssh_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)
#UNLOCK ssh
@bot.on(events.CallbackQuery(data=cbx("unlock-ssh")))
async def unlock_ssh(event):
        async def unlock_ssh_(event):
                async with bot.conversation(chat) as exp:
                        await event.respond("**Username:**")
                        exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        exp = (await exp).raw_text
                
                cmd = f'printf "%s\n" "{exp}" | bot-unlock'
                try:
                        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                except:
                        await event.respond(f"**User** `{exp}` **Successfully Unlocked**")
                else:
                        msg = f"""**User** `{exp}` **Successfully Unlocked**"""
                        await event.respond(msg)
        chat = event.chat_id
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await unlock_ssh_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)
#DELETESSH
@bot.on(events.CallbackQuery(data=cbx("delete-ssh")))
async def delete_ssh(event):
        async def delete_ssh_(event):
                async with bot.conversation(chat) as user:
                        await event.respond("**Username :**")
                        user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        user = (await user).raw_text
                        cmd = f'printf "%s\n" "{user}" | bot-del-ssh'
                try:
                        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                except:
                        await event.respond(f"**User** `{user}` **Successfully Deleted**")
                else:
                        await event.respond(f"**Successfully Deleted** `{user}`")
        chat = event.chat_id
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await delete_ssh_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)
#RENEWSSH
@bot.on(events.CallbackQuery(data=cbx("recov-ssh")))
async def recov_ssh(event):
        async def recov_ssh_(event):
                async with bot.conversation(chat) as user:
                        await event.respond("**Username :**")
                        user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        user = (await user).raw_text
                async with bot.conversation(chat) as pw:
                        await event.respond("**Days :**")
                        pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        pw = (await pw).raw_text
                async with bot.conversation(chat) as iplimit:
                        await event.respond("**Ip Limit :**")
                        iplimit = iplimit.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        iplimit = (await iplimit).raw_text
                async with bot.conversation(chat) as Quota:
                        await event.respond("**Quota :**")
                        Quota = Quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        Quota = (await Quota).raw_text
                await event.edit("**Loading......**")
                # urutan input bot-renew-ssh: username, days, quota (GB), ip limit
                cmd = f'printf "%s\n" "{user}" "{pw}" "{Quota}" "{iplimit}" | bot-renew-ssh'
                # exit code backend diabaikan - keberhasilan diverifikasi
                # dari kondisi sistem (sama seperti layanan lain)
                run_renew(cmd)
                # masa aktif & tanggal expired baru dibaca langsung dari sistem
                info = get_member_info("ssh", user)
                if info["exp"] == "Unknown":
                        await event.respond(f"**❌ Gagal Renew User** `{user}`\n**Periksa Kembali Username-nya**",
                                buttons=[[Button.inline("‹ Main Menu ›",cbx("menu"), style="success")]])
                        return
                msg = f"""
**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**
**┃   ⟨RENEW SSH BERHASIL⟩**
**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**
**┃   👤 Username :** `{user}`
**┃   ➕ Diperpanjang :** `{pw} Hari`
**┃   ⏳ Masa Aktif :** `{info["days"]}`
**┃   📅 Expired :** `{info["exp"]}`
**┃   📦 Limit Kuota :** `{Quota} GB`
**┃   🔗 Limit IP :** `{iplimit} IP`
**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**
**» 🤖@zenviora_id**
"""
                await event.respond(msg,buttons=[[Button.inline("‹ Main Menu ›",cbx("menu"), style="success")]])
        chat = event.chat_id
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await recov_ssh_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)
        
#LIMITSSH
@bot.on(events.CallbackQuery(data=cbx("limit-ssh")))
async def limit_ssh(event):
        async def limit_ssh_(event):
                async with bot.conversation(chat) as user:
                        await event.respond("**Username :**")
                        user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        user = (await user).raw_text
                async with bot.conversation(chat) as pw:
                        await event.respond("**Limit-IP :**")
                        pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        pw = (await pw).raw_text
                        cmd = f'printf "%s\n" "{user}" "{pw}" | bot-ganti-ip-ssh'
                try:
                        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                except:
                        await event.respond(f"`{user}` **Succesfully Change Limit IP**")
                else:
                        await event.respond(f"""
```
{a}
```
**CHANGE IP SSH**
**» 🤖@zenviora_id**
""",buttons=[[Button.inline("‹ Main Menu ›",cbx("menu"), style="success")]])
        chat = event.chat_id
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await limit_ssh_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)

@bot.on(events.CallbackQuery(data=cbx("quota-ssh")))
async def quota_ssh(event):
        async def quota_ssh_(event):
                async with bot.conversation(chat) as user:
                        await event.respond("**Username :**")
                        user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        user = (await user).raw_text
                async with bot.conversation(chat) as pw:
                        await event.respond("**Limit Quota :**")
                        pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        pw = (await pw).raw_text
                        cmd = f'printf "%s\n" "{user}" "{pw}" | bot-quota-ssh'
                try:
                        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                except:
                        await event.respond(f"`{user}` **Succesfully Change Limit Quota**")
                else:
                        await event.respond(f"""
```
{a}
```
**CHANGE QUOTA SSH**
**» 🤖@zenviora_id**
""",buttons=[[Button.inline("‹ Main Menu ›",cbx("menu"), style="success")]])
        chat = event.chat_id
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await quota_ssh_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)


@bot.on(events.CallbackQuery(data=cbx("show-ssh")))
async def show_ssh(event):
    # List Member SSH: box per user (username, expired, sisa hari,
    # limit kuota, terpakai, sisa kuota) + tombol Next/Back halaman.
    async def show_ssh_(event):
        try:
            await event.edit("**Loading......**")
            msg, buttons = render_member_page("ssh", 1)
            await event.edit(msg, buttons=buttons)
        except Exception as e:
            await event.respond(f"Error: {e}",
                buttons=[[Button.inline("‹ Main Menu ›", cbx("menu"), style="success")]])

    # Validasi apakah pengirim memiliki akses
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Fungsi `valid()` harus tersedia
    if a == "true":
        await show_ssh_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)

# navigasi halaman List Member SSH (tombol Next / Back)
@bot.on(events.CallbackQuery(pattern=r"^listssh-(\d+)"))
async def show_ssh_page(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Buy Premium Chat: @zenviora_id", alert=True)
    try:
        page = int(event.pattern_match.group(1))
    except Exception:
        page = 1
    msg, buttons = render_member_page("ssh", page)
    await event.edit(msg, buttons=buttons)

                
@bot.on(events.CallbackQuery(data=cbx("login-ssh")))
async def login_ssh(event):
        async def login_ssh_(event):
                cmd = 'cek-ssh'.strip()
                x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
                print(x)
                z = subprocess.check_output(cmd, shell=True).decode("utf-8")
                await event.respond(f"""

{z}

**shows logged in users SSH Ovpn**
**» 🤖@zenviora_id**
""",buttons=[[Button.inline("‹ Main Menu ›",cbx("menu"), style="success")]])
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await login_ssh_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)


@bot.on(events.CallbackQuery(data=cbx("ssh")))
async def ssh(event):
        async def ssh_(event):
                inline = [
[Button.inline("Trial",cbx("trial-ssh"), style="success"),
Button.inline("Create",cbx("create-akun"), style="success")],
[Button.inline("Check User Login",cbx("login-ssh"), style="success")],
[Button.inline("Renew",cbx("recov-ssh"), style="success"),
Button.inline("Delete",cbx("delete-ssh"), style="danger")],
[Button.inline("List Member",cbx("show-ssh"), style="success")],
[Button.inline("Lock",cbx("lock-ssh"), style="danger"),
Button.inline("Unlock",cbx("unlock-ssh"), style="success")],
[Button.inline("Change Limit IP",cbx("limit-ssh"), style="success")],
[Button.inline("Change Limit Quota",cbx("quota-ssh"), style="success")],
[Button.inline("‹ Main Menu ›",cbx("menu"), style="success")]]
                z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
                msg = f"""
**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**
**┃   ⟨SSH SERVICE⟩**
**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**
**┃   » Service :** `SSH OVPN`
**┃   » Domain :** `{DOMAIN}`
**┃   » ISP :** `{z["isp"]}`
**┃   » Country :** `{z["country"]}`
**┃   » 🤖@zenviora_id**
**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**
"""
                await event.edit(msg,buttons=inline)
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await ssh_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)
