from private import *
import subprocess
import json
import base64
import datetime as DT
import requests
import time
import random
import asyncio
import tempfile
import re
from telethon import events, Button

env = load_env_vars()
DOMAIN = env.get("DOMAIN", "Tidak Diketahui")

@bot.on(events.NewMessage(pattern=PATTERN_MENU))
@bot.on(events.CallbackQuery(data=cbx("menu")))
async def menu(event):
    # Inline button
    inline = [
        [Button.inline(" SSH ", cbx("ssh")), Button.inline(" Vmess ", cbx("vmess"))],
        [Button.inline(" Vless ", cbx("vless")), Button.inline(" Trojan ", cbx("trojan"))],
        [Button.inline(" Shadowsocks ", cbx("shadowsocks"))],
        [Button.inline(" Info ", cbx("info")), Button.inline(" Settings ", cbx("setting"))],
        [Button.inline(" ‹ Back To Start › ", cbx("start"))]
    ]

    sender = await event.get_sender()
    val = valid(str(sender.id))

    if val == "false":
        try:
            await event.answer("Buy Premium Chat: @zenviora_id", alert=True)
        except:
            await event.reply("Buy Premium Chat: @zenviora_id")
        return

    elif val == "true":
        try:
            # Collecting data
            ssh = subprocess.check_output('cat /etc/passwd | grep "home" | grep "false" | wc -l', shell=True).decode("ascii").strip()
            vms = subprocess.check_output('cat /etc/xray/config.json | grep "###" | wc -l', shell=True).decode("ascii").strip()
            vls = subprocess.check_output('cat /etc/xray/config.json | grep "#&" | wc -l', shell=True).decode("ascii").strip()
            trj = subprocess.check_output('cat /etc/xray/config.json | grep "#!" | wc -l', shell=True).decode("ascii").strip()
            shadowsocks = subprocess.check_output('cat /etc/xray/config.json | grep "#@&" | wc -l', shell=True).decode("ascii").strip()
            namaos = subprocess.check_output("cat /etc/os-release | grep -w PRETTY_NAME | head -n1 | sed 's/\"//g' | sed 's/PRETTY_NAME=//g'", shell=True).decode("ascii").strip()
            ipsaya = subprocess.check_output("curl -s ipv4.icanhazip.com", shell=True).decode("ascii").strip()
            z = requests.get("http://ip-api.com/json/?fields=country,region,city,timezone,isp", timeout=10).json()

        except subprocess.CalledProcessError as e:
            out = e.output
            if out is None:
                out = ""
            elif isinstance(out, bytes):
                out = out.decode(errors="replace")
            await event.reply(f"Error collecting data: {out}")
            return
        except Exception as e:
            await event.reply(f"Error collecting data: {e}")
            return

        # Membagi hasil dengan 2
        vms_half = int(vms or 0) // 2
        vls_half = int(vls or 0) // 2
        trj_half = int(trj or 0) // 2
        shadowsocks_half = int(shadowsocks or 0) // 1
        ssh_half = int(ssh or 0) // 2

        # Building the message (pakai .get agar tidak mati kalau ip-api gagal)
        msg = f"""
**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**
**┃              ❇️ ROBOT PRIVATE ❇️**
**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**
**┃   » Os :** `{namaos}`
**┃   » IP :** `{ipsaya.strip()}`
**┃   » ISP :** `{z.get("isp", "N/A")}`
**┃   » Lokasi :** `{z.get("country", "N/A")}`
**┃   » Domain :** `{DOMAIN}`
**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**
**┃   🌀 Total Akun Di Buat:**
**┃   🏷️ SSH :** `{ssh}` __account__
**┃   🏷️ Vmess :** `{vms_half}` __account__
**┃   🏷️ Vless :** `{vls_half}` __account__
**┃   🏷️ Trojan :** `{trj_half}` __account__
**┃   🏷️ Shadowsocks :** `{shadowsocks_half}` __account__
**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**
{get_banner_info()}
"""
        # ============================================================
        # PENTING (bug fix):
        # - Dipanggil lewat TEKS  (.idv4 / /idv4)  -> event.edit()
        #   pada pesan MASUK hanya return None (tidak error, tidak
        #   mengirim apa pun). Wajib pakai event.respond().
        # - Dipanggil lewat TOMBOL (CallbackQuery)  -> event.edit()
        #   benar karena mengedit pesan bot sendiri.
        # ============================================================
        media = get_banner_file()
        try:
            # NB: pengecekan yang benar adalah events.CallbackQuery.Event
            # (events.CallbackQuery saja tidak pernah match saat runtime)
            if isinstance(event, events.CallbackQuery.Event):
                # dipanggil dari tombol -> edit pesan yang sedang tampil
                if media:
                    try:
                        await event.edit(msg, file=media, buttons=inline)
                    except Exception:
                        try:
                            await event.delete()
                        except Exception:
                            pass
                        await bot.send_file(event.chat_id, media, caption=msg, buttons=inline)
                else:
                    try:
                        await event.edit(msg, buttons=inline)
                    except Exception:
                        await event.respond(msg, buttons=inline)
            else:
                # dipanggil lewat teks -> kirim sebagai balasan (seperti /start)
                if media:
                    await event.respond(msg, file=media, buttons=inline)
                else:
                    await event.respond(msg, buttons=inline)
        except Exception as e:
            # jangan diam saja kalau gagal - error tampil di chat biar bisa dilacak
            try:
                await event.reply(f"Error menampilkan menu: {e}")
            except Exception:
                pass
