from private import *
import subprocess
import json
import base64
import datetime as DT
import requests
import time
import random
import asyncio
import tempfile
import re
from telethon import events, Button

env = load_env_vars()
DOMAIN = env.get("DOMAIN", "Tidak Diketahui")

@bot.on(events.CallbackQuery(data=cbx("create-vless")))
async def create_vless(event):
    async def create_vless_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username :**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        
        async with bot.conversation(chat) as exp:
            await event.respond('**Expired :**')
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text

        async with bot.conversation(chat) as ip:
            await event.respond('**Limit Quota :**')
            ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            ip = (await ip).raw_text

        async with bot.conversation(chat) as Quota:
            await event.respond('**Limit Ip :**')
            Quota = Quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            Quota = (await Quota).raw_text

        
        

        await event.edit("**Loading......**")
        cmd = f'printf "%s\n" "{user}" "{exp}" "{ip}" "{Quota}" | addvless-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"Terjadi kesalahan: {e}\nSubproses output: {a}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        x = [x.group() for x in re.finditer("vless://(.*)", a)]
        print(x)
        uuid = re.search("vless://(.*?)@", x[0]).group(1)
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
        **◇⟨VLESS ACCOUNT⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» Username :** `{user}`
**» Domain :** `{DOMAIN}`
**» Limit Quota :** `{ip} GB`
**» Limit Login :** `{Quota} HP`
**» HTTP :** `80,8880,2052,2086,2095`
**» HTTPS :** `443,2053,2087,2096`
**» UUID    :** `{uuid}`
**» Networks     :** `(WS) or (gRPC)`
**» Path        :** `/viip-vless`
**» ServiceName :** `vless-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK TLS 443      :**
```{x[0].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK NON-TLS 80   :**
```{x[1].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK gRPC TLS 443 :** 
```{x[2].strip("'")}```
**◇━━━━━━━━━━━━━━━━━◇**
**⟨Link Save Account⟩**
https://{DOMAIN}:81/vless-{user}.txt
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@zenviora_id
"""
        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await create_vless_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)

@bot.on(events.CallbackQuery(data=cbx("cek-vless")))
async def cek_vless(event):
    async def cek_vless_(event):
        cmd = 'cek-vless'.strip()
        result = subprocess.check_output(
            cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True, env={"TERM": "xterm"}
        )

        # Hapus karakter escape ANSI
        clean_result = re.sub(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])', '', result).strip()

        await event.edit(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
 ** ◇⟨Cek Vless User Login⟩◇**
**◇━━━━━━━━━━━━━━━━━━◇**
{clean_result}

**Shows Logged In Users Vless**
""", buttons=[[Button.inline("‹ Main Menu ›", cbx("vless"), style="primary")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await cek_vless_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)
                
@bot.on(events.CallbackQuery(data=cbx("renew-vless")))
async def ren_vless(event):
    async def ren_vless_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username :**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text

        async with bot.conversation(chat) as exp:
            await event.respond('**Expired :**')
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text


        async with bot.conversation(chat) as ip:
            await event.respond('**Limit Quota :**')
            ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            ip = (await ip).raw_text


        async with bot.conversation(chat) as Quota:
            await event.respond('**Limit Ip :**')
            Quota = Quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            Quota = (await Quota).raw_text

        await event.edit("**Loading......**")
        cmd = f'printf "%s\n" "{user}" "{exp}" "{ip}" "{Quota}" | bot-renew-vle'
        # exit code backend diabaikan (script bot-renew-vle selalu exit 1
        # walau sukses) - keberhasilan diverifikasi dari kondisi sistem
        run_renew(cmd)
        # masa aktif & tanggal expired baru dibaca langsung dari sistem
        info = get_member_info("vless", user)
        if info["exp"] == "Unknown":
            await event.respond(f"**❌ Gagal Renew User** `{user}`\n**Periksa Kembali Username-nya**",
                buttons=[[Button.inline("‹ Main Menu ›", cbx("menu"), style="primary")]])
            return
        msg = f"""
**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**
**┃   ⟨RENEW VLESS BERHASIL⟩**
**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**
**┃   👤 Username :** `{user}`
**┃   ➕ Diperpanjang :** `{exp} Hari`
**┃   ⏳ Masa Aktif :** `{info["days"]}`
**┃   📅 Expired :** `{info["exp"]}`
**┃   📦 Limit Kuota :** `{ip} GB`
**┃   🔗 Limit IP :** `{Quota} IP`
**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**
**» 🤖@zenviora_id**
"""
        await event.respond(msg, buttons=[[Button.inline("‹ Main Menu ›", cbx("menu"), style="primary")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await ren_vless_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)


# CEK member VLESS (List Member + tombol Next)
@bot.on(events.CallbackQuery(data=cbx("cek-membervl")))
async def cek_vless(event):
    async def cek_vless_(event):
        try:
            await event.edit("**Loading......**")
            msg, buttons = render_member_page("vless", 1)
            await event.edit(msg, buttons=buttons)
        except Exception as e:
            await event.respond(f"Error: {e}",
                buttons=[[Button.inline("‹ Main Menu ›", cbx("menu"), style="primary")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await cek_vless_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)

# navigasi halaman List Member VLESS (tombol Next / Back)
@bot.on(events.CallbackQuery(pattern=r"^listvl-(\d+)"))
async def list_vless_page(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Buy Premium Chat: @zenviora_id", alert=True)
    try:
        page = int(event.pattern_match.group(1))
    except Exception:
        page = 1
    msg, buttons = render_member_page("vless", page)
    await event.edit(msg, buttons=buttons)



@bot.on(events.CallbackQuery(data=cbx("delete-vless")))
async def delete_vless(event):
    async def delete_vless_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username :**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        await event.edit("**Loading......**")
        cmd = f'printf "%s\n" "{user}" | bot-del-vle'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**Successfully Delete User**")
        else:
            msg = f"""**Successfully Deleted**"""
            await event.respond(msg)


    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await delete_vless_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)



@bot.on(events.CallbackQuery(data=cbx("trial-vless")))
async def trial_vless(event):
    async def trial_vless_(event):
        cmd = f'printf "%s\n" "TrialVL`</dev/urandom tr -dc X-Z0-9 | head -c4`" "1" "1" "1" | bot-trialvless'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(1))
            x = [x.group() for x in re.finditer("vless://(.*)", a)]
            print(x)
            remarks = re.search("#(.*)", x[0]).group(1)
            # domain = re.search("@(.*?):", x[0]).group(1)
            uuid = re.search("vless://(.*?)@", x[0]).group(1)
            # path = re.search("path=(.*)&", x[0]).group(1)
            msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
 **◇⟨TRIAL VLESS ACCOUNT⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» Username :** `{remarks}`
**» Host Server :** `{DOMAIN}`
**» HTTP :** `80,8880,2052,2086,2095`
**» HTTPS :** `443,2053,2087,2096`
**» UUID    :** `{uuid}`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/viip-vless`
**» ServiceName :** `vless-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK TLS 443      :**
```{x[0].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK NON-TLS 80   :**
```{x[1].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK gRPC TLS 443 :** 
```{x[2].strip("'")}```
**◇━━━━━━━━━━━━━━━━━◇**
**⟨Link Save Account⟩**
https://{DOMAIN}:81/vless-{remarks}.txt
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** 30 Minutes
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@zenviora_id
"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trial_vless_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)

@bot.on(events.CallbackQuery(data=cbx("limit-vless")))
async def limit_vless(event):
        async def limit_vless_(event):
                async with bot.conversation(chat) as user:
                        await event.respond("**Username :**")
                        user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        user = (await user).raw_text
                async with bot.conversation(chat) as pw:
                        await event.respond("**Limit Ip :**")
                        pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        pw = (await pw).raw_text
                        await event.edit("**Loading......**")
                        cmd = f'printf "%s\n" "{user}" "{pw}" | bot-ganti-ip-vless'
                try:
                        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                except:
                        await event.respond(f"`{user}` **Succesfully Change Limit IP**")
                else:
                        await event.respond(f"""
```
{a}
```
**GANTI IP vless**
**» 🤖@zenviora_id**
""",buttons=[[Button.inline("‹ Main Menu ›",cbx("menu"), style="primary")]])
        chat = event.chat_id
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await limit_vless_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)

@bot.on(events.CallbackQuery(data=cbx("quota-vless")))
async def quota_vless(event):
        async def quota_vless_(event):
                async with bot.conversation(chat) as user:
                        await event.respond("**Username :**")
                        user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        user = (await user).raw_text
                async with bot.conversation(chat) as pw:
                        await event.respond("**Limit Quota :**")
                        pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        pw = (await pw).raw_text
                        await event.edit("**Loading......**")
                        cmd = f'printf "%s\n" "{user}" "{pw}" | bot-quota-vl'
                try:
                        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                except:
                        await event.respond(f"`{user}` **Succesfully Change Limit Quota**")
                else:
                        await event.respond(f"""
```
{a}
```
**GANTI QUOTA vless**
**» 🤖@zenviora_id**
""",buttons=[[Button.inline("‹ Main Menu ›",cbx("menu"), style="primary")]])
        chat = event.chat_id
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await quota_vless_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)

@bot.on(events.CallbackQuery(data=cbx("lock-vless")))
async def lock_vless(event):
        async def lock_vless_(event):
                async with bot.conversation(chat) as exp:
                        await event.respond("**Username:**")
                        exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        exp = (await exp).raw_text
                await event.edit("**Loading......**")
                cmd = f'printf "%s\n" "{exp}" | bot-lock-vl'
                try:
                        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                except:
                        await event.respond(f"**User** `{exp}` **Successfully Locked**")
                else:
                        msg = f"""**Successfully Locked**"""
                        await event.respond(msg)
        chat = event.chat_id
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await lock_vless_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)
#UNLOCK ssh
@bot.on(events.CallbackQuery(data=cbx("unlock-vless")))
async def unlock_vless(event):
        async def unlock_vless_(event):
                async with bot.conversation(chat) as exp:
                        await event.respond("**Username :**")
                        exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        exp = (await exp).raw_text
                await event.edit("**Loading......**")
                cmd = f'printf "%s\n" "{exp}" | bot-unlock-vl'
                try:
                        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                except:
                        await event.respond(f"**User** `{exp}` **Successfully Unlocked**")
                else:
                        msg = f"""**Successfully Unlocked**"""
                        await event.respond(msg)
        chat = event.chat_id
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await unlock_vless_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)
                

@bot.on(events.CallbackQuery(data=cbx("vless")))
async def vless(event):
    async def vless_(event):
        # Layout rapih per baris (warna seragam dalam 1 baris):
        #   Baris 1 HIJAU (success)  : aksi utama akun
        #   Baris 2 BIRU (primary)  : info & monitoring
        #   Baris 3 MERAH (danger)  : hapus / blokir / buka blokir
        #   Baris 4 BIRU (primary)  : ubah limit akun
        #   Baris 5 BIRU (primary)  : navigasi
        inline = [
            [Button.inline("Trial", cbx("trial-vless"), style="success"),
             Button.inline("Create", cbx("create-vless"), style="success"),
             Button.inline("Renew", cbx("renew-vless"), style="success")],
            [Button.inline("Check User Login", cbx("cek-vless"), style="primary"),
             Button.inline("List member", cbx("cek-membervl"), style="primary")],
            [Button.inline("Delete", cbx("delete-vless"), style="danger"),
             Button.inline("Lock", cbx("lock-vless"), style="danger"),
             Button.inline("Unlock", cbx("unlock-vless"), style="danger")],
            [Button.inline("Change Limit IP", cbx("limit-vless"), style="primary"),
             Button.inline("Change Limit Quota", cbx("quota-vless"), style="primary")],
            [Button.inline("‹ Main Menu ›", cbx("menu"), style="primary")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**
**┃   ⟨VLESS SERVICE⟩**
**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**
**┃   » Service :** `Vless`
**┃   » Domain :** `{DOMAIN}`
**┃   » ISP :** `{z["isp"]}`
**┃   » Country :** `{z["country"]}`
**┃   » 🤖@zenviora_id**
**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**
"""
        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await vless_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)

