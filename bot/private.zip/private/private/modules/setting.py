from private import *
import subprocess
import json
import base64
import datetime as DT
import requests
import time
import random
import asyncio
import tempfile
import re
from telethon import events, Button

env = load_env_vars()
DOMAIN = env.get("DOMAIN", "Tidak Diketahui")

@bot.on(events.NewMessage(pattern='/cancel'))
async def cancel_command(event):
    sender = await event.get_sender()
    user_id = str(sender.id)

    if valid(user_id) != "true":
        await event.reply("Buy Premium Chat: @zenviora_id")
        return

    await event.reply(
        "**❌ Operasi dibatalkan.**",
        buttons=[[Button.inline("‹ Menu ›", cbx("menu"))]]
    )
    
    
@bot.on(events.CallbackQuery(data=cbx("reboot")))
async def rebooot(event):
        async def rebooot_(event):
                await event.edit("**Loading......**")
                cmd = f'reboot'
                
                subprocess.check_output(cmd, shell=True)
                await event.edit(f"""
**» REBOOT SERVER**
**» 🤖@zenviora_id**"""
    ,buttons=[[Button.inline("‹ Main Menu ›",cbx("menu"))]])
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await rebooot_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)


@bot.on(events.CallbackQuery(data=cbx("resx")))
async def rebooot(event):
        async def rebooot_(event):
                cmd = f'bot-restart'
                await asyncio.sleep(5)
                await event.edit("**✅ Successfully Restart All Service**")
                
                z = subprocess.check_output(cmd, shell=True).decode("utf-8")
                await event.edit(f"""
**{z}**
**» 🤖@zenviora_id**"""
    ,buttons=[[Button.inline("‹ Main Menu ›",cbx("menu"))]])
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await rebooot_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)
        

@bot.on(events.CallbackQuery(data=cbx("speedtest")))
async def speedtest(event):
        async def speedtest_(event):
                await event.edit("**Loading......**")
                cmd = 'speedtest-cli --share'.strip()
                x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
                print(x)
                z = subprocess.check_output(cmd, shell=True).decode("utf-8")

                await event.respond(f"""
**
{z}
**
**» 🤖@zenviora_id**
""",buttons=[[Button.inline("‹ Main Menu ›",cbx("menu"))]])
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await speedtest_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)

@bot.on(events.CallbackQuery(data=cbx("setup_backup")))
async def set_backupbot(event):
    sender = await event.get_sender()
    user_id = str(sender.id)

    # Validasi user yang boleh set token & id (hanya admin)
    if valid(user_id) != "true":
        await event.answer("❌ Akses ditolak. Hubungi admin: @zenviora_id", alert=True)
        return

    async with bot.conversation(event.chat_id) as user:
        await event.respond('**Input Bot Token (bot untuk kirim backup) :**')
        token_input = await user.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
        token = token_input.raw_text.strip()

        await event.respond('**Input Telegram ID tujuan backup :**')
        id_input = await user.wait_event(events.NewMessage(incoming=True, from_users=event.sender_id))
        admin_id = id_input.raw_text.strip()

        # Pastikan direktori /root ada (biasanya sudah ada, tapi untuk jaga-jaga)
        try:
            os.makedirs("/root", exist_ok=True)

            with open("/root/.bckupbot", "w") as f:
                f.write(f"{token}\n{admin_id}\n")

            await event.respond("**✅ Token dan ID berhasil disimpan.**\n"
                                "**Setiap backup akan dikirim juga ke ID tersebut.**\n"
                                "**Catatan: ID harus sudah menekan START di bot tsb "
                                "agar bot bisa mengirim file backup.")
        except Exception as e:
            await event.respond(f"**❌ Gagal menyimpan data:**\n`{e}`")
            
     
@bot.on(events.CallbackQuery(data=cbx("backup")))
async def run_backupku(event):
    sender = await event.get_sender()
    user_id = str(sender.id)

    if valid(user_id) != "true":
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)
        return

    await event.edit("**Loading......**")

    # 1) buat file zip backup (data akun, config xray, config bot)
    try:
        fpath = create_bot_backup()
    except Exception as e:
        await event.respond(f"**\u274c Backup gagal dibuat:**\n`{e}`",
            buttons=[[Button.inline("\u2039 Main Menu \u203a", cbx("menu"))]])
        return

    fname = os.path.basename(fpath)
    caption = ("**\u2705 Backup Successfully**\n"
               f"**\u00bb File :** `{fname}`\n"
               "**\u00bb Simpan file ini di HP/Telegram Anda.\n"
               "Untuk Restore: kirim/forward file ini ke bot lewat menu "
               "Restore.**\n**\u00bb \U0001F916@zenviora_id**")

    # 2) kirim file backup LANGSUNG ke chat bot ini (bisa langsung disimpan)
    sent_chat = False
    try:
        await event.respond(caption, file=fpath,
            buttons=[[Button.inline("\u2039 Main Menu \u203a", cbx("menu"))]])
        sent_chat = True
    except Exception as e:
        print(f"Backup: gagal kirim file ke chat: {e}")

    # 3) kalau Setup Backup (Token + ID) sudah diisi, kirim juga ke ID tsb
    sent_id = False
    has_setup = False
    try:
        if os.path.exists("/root/.bckupbot"):
            with open("/root/.bckupbot", "r") as f:
                blines = [x.strip() for x in f.readlines() if x.strip()]
            if len(blines) >= 2 and blines[0] and blines[1]:
                has_setup = True
                sent_id = send_backup_via_api(blines[0], blines[1], fpath)
    except Exception as e:
        print(f"Backup: gagal kirim ke ID backup: {e}")
        has_setup = True

    if has_setup:
        if sent_id:
            extra = "**\u00bb \u2705 File backup juga dikirim ke Telegram ID backup.**"
        else:
            extra = ("**\u00bb \u26a0\ufe0f Gagal kirim ke Telegram ID backup.**\n"
                     "**Cek ulang Bot Token / ID di menu Setup Backup "
                     "(ID harus sudah tekan START di bot tsb).**")
        try:
            await event.respond(f"**\U0001F4BE Info Backup**\n{extra}",
                buttons=[[Button.inline("\u2039 Main Menu \u203a", cbx("menu"))]])
        except Exception:
            pass

    if not sent_chat:
        await event.respond(
            f"**\u26a0\ufe0f File tidak terkirim ke chat, tapi tersimpan di server:**\n`{fpath}`",
            buttons=[[Button.inline("\u2039 Main Menu \u203a", cbx("menu"))]])


@bot.on(events.CallbackQuery(data=cbx("restore")))
async def restore(event):
    async def restore_(event):
        # minta file backup langsung dikirim ke bot (tanpa link URL)
        await event.respond(
            "**\u267b\ufe0f RESTORE BACKUP**\n"
            "**\u00bb Kirim / forward FILE backup (.zip) ke bot ini sekarang.**\n"
            "**\u00bb File dari menu Backup bot ini atau dari script cadangkan lama sama-sama bisa.**\n"
            "**\u00bb Ketik /cancel untuk membatalkan.**",
            buttons=[[Button.inline("\u2039 Main Menu \u203a", cbx("menu"))]])

        doc_msg = None
        try:
            async with bot.conversation(chat) as conv:
                while True:
                    m = await conv.wait_event(
                        events.NewMessage(incoming=True, from_users=sender.id),
                        timeout=300)
                    raw = (m.raw_text or "").strip().lower()
                    if raw == "/cancel":
                        await event.respond("**\u274c Restore dibatalkan.**",
                            buttons=[[Button.inline("\u2039 Main Menu \u203a", cbx("menu"))]])
                        return
                    if m.document:
                        doc_msg = m
                        break
                    await event.respond(
                        "**\u26a0\ufe0f Itu bukan file. Kirim FILE backup (.zip)** "
                        "**atau ketik /cancel.**")
        except asyncio.TimeoutError:
            await event.respond("**\u23f3 Timeout: tidak ada file backup dikirim.**",
                buttons=[[Button.inline("\u2039 Main Menu \u203a", cbx("menu"))]])
            return
        except Exception as e:
            await event.respond(f"**\u274c Gagal menerima file:** `{e}`",
                buttons=[[Button.inline("\u2039 Main Menu \u203a", cbx("menu"))]])
            return

        if doc_msg is None:
            return

        name = "backup.zip"
        try:
            if doc_msg.file and doc_msg.file.name:
                name = doc_msg.file.name
        except Exception:
            pass
        if not name.lower().endswith(".zip"):
            await event.respond("**\u274c File harus backup (.zip).**\n**Ulangi lewat menu Restore.**",
                buttons=[[Button.inline("\u2039 Main Menu \u203a", cbx("menu"))]])
            return

        await event.respond("**Loading......**")
        try:
            path = await doc_msg.download_media(file="/root/" + name)
        except Exception as e:
            await event.respond(f"**\u274c Gagal mengunduh file:** `{e}`",
                buttons=[[Button.inline("\u2039 Main Menu \u203a", cbx("menu"))]])
            return

        ok, pesan = restore_bot_backup(path)
        try:
            os.remove(path)
        except Exception:
            pass
        if ok:
            await event.respond(
                "**\u2705 RESTORE BERHASIL!**\n"
                f"**\u00bb {pesan}**\n"
                "**\u00bb Semua data akun & config sudah dipulihkan, xray di-restart.**\n"
                "**\u00bb \U0001F916@zenviora_id**",
                buttons=[[Button.inline("\u2039 Main Menu \u203a", cbx("menu"))]])
        else:
            await event.respond(f"**\u274c RESTORE GAGAL:**\n`{pesan}`",
                buttons=[[Button.inline("\u2039 Main Menu \u203a", cbx("menu"))]])

    chat = event.chat_id
    sender = await event.get_sender()

    # Validate user permission
    a = valid(str(sender.id))
    if a == "true":
        await restore_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)
@bot.on(events.CallbackQuery(data=cbx("backer")))
async def backers(event):
        async def backers_(event):
                inline = [
[Button.inline("\U0001F4BE Backup",cbx("backup")),
Button.inline("\u267b\ufe0f Restore",cbx("restore"))],
[Button.inline("\u2699\ufe0f Setup Backup (Token & ID)",cbx("setup_backup"))],
[Button.inline("\u2039 Main Menu \u203a",cbx("menu"))]]
                z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
                msg = f"""
**\u250f\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2513**
**\u2503   \u27e8MENU BACKUP & RESTORE\u27e9**
**\u2523\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u252b**
**\u2503   \u00bb Domain :** `{DOMAIN}`
**\u2503   \u00bb ISP :** `{z["isp"]}`
**\u2503   \u00bb Region :** `{z["country"]}`
**\u2523\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u252b**
**\u2503   \U0001F4BE Backup :**
**\u2503   membuat file zip backup lalu**
**\u2503   mengirim file-nya LANGSUNG ke**
**\u2503   chat bot ini (tinggal disimpan),**
**\u2503   plus ke Telegram ID backup**
**\u2503   bila Setup sudah diisi.**
**\u2523\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u252b**
**\u2503   \u267b\ufe0f Restore :**
**\u2503   kirim/forward FILE backup (.zip)**
**\u2503   ke bot ini, semua data akun &**
**\u2503   config otomatis dipulihkan**
**\u2503   ke server (xray di-restart).**
**\u2523\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u252b**
**\u2503   \u2699\ufe0f Setup : simpan Bot Token &**
**\u2503   Telegram ID tujuan backup.**
**\u2517\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u2501\u251b**
**\u00bb \U0001F916@zenviora_id**
"""
                await event.edit(msg,buttons=inline)
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await backers_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)

@bot.on(events.CallbackQuery(data=cbx("setting")))
async def settings(event):
        async def settings_(event):
                inline = [
[Button.inline("Backup & Restore",cbx("backer"))],
[Button.inline("Speedtest",cbx("speedtest"))],
[Button.inline("Reboot server",cbx("reboot")),
Button.inline("Restart Server",cbx("resx"))],
[Button.inline("‹ Main Menu ›",cbx("menu"))]]
                z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
                msg = f"""
**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**
**┃   ⟨MENU SETTINGS⟩**
**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**
**┃   » Domain :** `{DOMAIN}`
**┃   » ISP :** `{z["isp"]}`
**┃   » Region :** `{z["country"]}`
**┃   » 🤖@zenviora_id**
**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**
"""
                await event.edit(msg,buttons=inline)
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await settings_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)
