from private import *
import subprocess
import json
import base64
import datetime as DT
import requests
import time
import random
import asyncio
import tempfile
import re
from telethon import events, Button

env = load_env_vars()
DOMAIN = env.get("DOMAIN", "Tidak Diketahui")

@bot.on(events.NewMessage(pattern='/cancel'))
async def cancel_command(event):
    sender = await event.get_sender()
    user_id = str(sender.id)

    if valid(user_id) != "true":
        await event.reply("Buy Premium Chat: @zenviora_id")
        return

    await event.reply(
        "**❌ Operasi dibatalkan.**",
        buttons=[[Button.inline("‹ Menu ›", cbx("menu"), style="primary")]]
    )
    
    
@bot.on(events.CallbackQuery(data=cbx("reboot")))
async def rebooot(event):
        async def rebooot_(event):
                await event.edit("**Loading......**")
                cmd = f'reboot'
                
                subprocess.check_output(cmd, shell=True)
                await event.edit(f"""
**» REBOOT SERVER**
**» 🤖@zenviora_id**"""
    ,buttons=[[Button.inline("‹ Main Menu ›",cbx("menu"), style="primary")]])
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await rebooot_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)


@bot.on(events.CallbackQuery(data=cbx("resx")))
async def rebooot(event):
        async def rebooot_(event):
                cmd = f'bot-restart'
                await asyncio.sleep(5)
                await event.edit("**✅ Successfully Restart All Service**")
                
                z = subprocess.check_output(cmd, shell=True).decode("utf-8")
                await event.edit(f"""
**{z}**
**» 🤖@zenviora_id**"""
    ,buttons=[[Button.inline("‹ Main Menu ›",cbx("menu"), style="primary")]])
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await rebooot_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)
        

@bot.on(events.CallbackQuery(data=cbx("speedtest")))
async def speedtest(event):
        async def speedtest_(event):
                await event.edit("**Loading......**")
                cmd = 'speedtest-cli --share'.strip()
                x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
                print(x)
                z = subprocess.check_output(cmd, shell=True).decode("utf-8")

                await event.respond(f"""
**
{z}
**
**» 🤖@zenviora_id**
""",buttons=[[Button.inline("‹ Main Menu ›",cbx("menu"), style="primary")]])
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await speedtest_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)

# ============================================================
# CATATAN V7:
# Fitur backup/restore versi lama (Setup Backup, Backup GDrive
# via `cadangkan-bot`, dan Restore via Link `bot-restore`)
# SUDAH DIHAPUS total (handler + tombol).
# Backup & Restore sekarang hanya lewat ID Bot / Auto Backup
# (lihat modules/idbackup.py).
# ============================================================

@bot.on(events.CallbackQuery(data=cbx("backer")))
async def backers(event):
        async def backers_(event):
                # Layout rapih per baris (warna seragam dalam 1 baris):
                #   Baris 1 HIJAU (success) : backup/restore via ID Bot
                #   Baris 2 HIJAU (success) : auto backup terjadwal
                #   Baris 3 BIRU (primary)  : navigasi
                # (V7: tombol versi lama Setup Backup / Restore (Link) /
                #  Backup (GDrive) sudah dihapus)
                inline = [
[Button.inline("📤 Backup Via ID Bot",cbx("botbackup"), style="success"),
Button.inline("📥 Restore Via ID Bot",cbx("botrestore"), style="success")],
[Button.inline("⏰ Auto Backup",cbx("autobackup"), style="success")],
[Button.inline("‹ Main Menu ›",cbx("menu"), style="primary")]]
                z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
                msg = f"""
**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**
**┃   ⟨MENU BACKUP & RESTORE⟩**
**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**
**┃   » Domain :** `{DOMAIN}`
**┃   » ISP :** `{z["isp"]}`
**┃   » Region :** `{z["country"]}`
**┃   » 🤖@zenviora_id**
**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**
**┃   Backup Via ID Bot = file backup**
**┃   dikirim bot ini langsung ke**
**┃   chat admin.**
**┃   Restore Via ID Bot = kirim**
**┃   file .zip backup ke chat bot.**
**┃   Auto Backup = backup otomatis**
**┃   terjadwal ke chat admin.**
"""
                await event.edit(msg,buttons=inline)
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await backers_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)

@bot.on(events.CallbackQuery(data=cbx("setting")))
async def settings(event):
        async def settings_(event):
                # Layout rapih per baris (warna seragam dalam 1 baris):
                #   Baris 1 HIJAU (success) : utilitas aman
                #   Baris 2 MERAH (danger)  : aksi destruktif (reboot/restart)
                #   Baris 3 BIRU (primary)  : navigasi
                inline = [
[Button.inline("Backup & Restore",cbx("backer"), style="success"),
Button.inline("Speedtest",cbx("speedtest"), style="success")],
[Button.inline("Reboot server",cbx("reboot"), style="danger"),
Button.inline("Restart Server",cbx("resx"), style="danger")],
[Button.inline("‹ Main Menu ›",cbx("menu"), style="primary")]]
                z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
                msg = f"""
**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**
**┃   ⟨MENU SETTINGS⟩**
**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**
**┃   » Domain :** `{DOMAIN}`
**┃   » ISP :** `{z["isp"]}`
**┃   » Region :** `{z["country"]}`
**┃   » 🤖@zenviora_id**
**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**
"""
                await event.edit(msg,buttons=inline)
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await settings_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)
