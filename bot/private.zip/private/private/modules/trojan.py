from private import *
import subprocess
import json
import base64
import datetime as DT
import requests
import time
import random
import asyncio
import tempfile
import re
from telethon import events, Button

env = load_env_vars()
DOMAIN = env.get("DOMAIN", "Tidak Diketahui")

@bot.on(events.CallbackQuery(data=cbx("create-trojan")))
async def create_trojan(event):
    async def create_trojan_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username :**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        
        async with bot.conversation(chat) as exp:
            await event.respond('**Expired :**')
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text

        async with bot.conversation(chat) as ip:
            await event.respond('**Limit Quota :**')
            ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            ip = (await ip).raw_text
        
        async with bot.conversation(chat) as Quota:
            await event.respond('**Limit Ip :**')
            Quota = Quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            Quota = (await Quota).raw_text


        await event.edit("**Loading......**")
        cmd = f'printf "%s\n" "{user}" "{exp}" "{ip}" "{Quota}" | addtr-bot'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"Terjadi kesalahan: {e}\nSubproses output: {a}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        b = [x.group() for x in re.finditer("trojan://(.*)", a)]
        print(b)
        domain = re.search("@(.*?):", b[0]).group(1)
        uuid = re.search("trojan://(.*?)@", b[0]).group(1)
        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
     **◇⟨TROJAN ACCOUNT⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» Username :** `{user}`
**» Domain :** `{DOMAIN}`
**» Limit Quota :** `{ip} GB`
**» Limit Login :** `{Quota} HP`
**» HTTP :** `80,8880,2052,2086,2095`
**» HTTPS :** `443,2053,2087,2096`
**» UUID    :** `{uuid}`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/viip-trojan-ws/multi-path`
**» ServiceName :** `trojan-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK TLS 443      :**
```{b[0].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK NON-TLS 80   :**
```{b[1].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK gRPC TLS 443 :** 
```{b[2].strip("'")}```
**◇━━━━━━━━━━━━━━━━━◇**
**⟨Link Save Account⟩**
https://{DOMAIN}:81/trojan-{user}.txt
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@zenviora_id
"""
        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await create_trojan_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)

@bot.on(events.CallbackQuery(data=cbx("cek-tr")))
async def cek_trojan(event):
    async def cek_trojan_(event):
        cmd = 'cek-tr'.strip()
        result = subprocess.check_output(
            cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True, env={"TERM": "xterm"}
        )

        # Hapus karakter escape ANSI
        clean_result = re.sub(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])', '', result).strip()

        await event.edit(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
  **◇⟨Cek Trojan User Login⟩◇**
**◇━━━━━━━━━━━━━━━━━━◇**
{clean_result}

**Shows Logged In Users Trojan**
""", buttons=[[Button.inline("‹ Main Menu ›", cbx("trojan"), style="success")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await cek_trojan_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)


@bot.on(events.CallbackQuery(data=cbx("trial-trojan")))
async def trial_trojan(event):
    async def trial_trojan_(event):
        cmd = f'printf "%s\n" "TrialTR-`</dev/urandom tr -dc X-Z0-9 | head -c4`" "1" "1" "1" | bot-trialtrojan'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**User Already Exist**")
        else:
            today = DT.date.today()
            later = today + DT.timedelta(days=int(1))
            b = [x.group() for x in re.finditer("trojan://(.*)", a)]
            print(b)
            remarks = re.search("#(.*)", b[0]).group(1)
            domain = re.search("@(.*?):", b[0]).group(1)
            uuid = re.search("trojan://(.*?)@", b[0]).group(1)
            msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**◇⟨TRIAL TROJAN ACCOUNT⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» Username :** `{remarks}`
**» Host Server :** `{DOMAIN}`
**» HTTP :** `80,8880,2052,2086,2095`
**» HTTPS :** `443,2053,2087,2096`
**» UUID    :** `{uuid}`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/viip-trojan-ws`
**» ServiceName :** `trojan-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK TLS 443      :**
```{b[0].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK NON-TLS 80   :**
```{b[1].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK gRPC TLS 443 :** 
```{b[2].strip("'")}```
**◇━━━━━━━━━━━━━━━━━◇**
**⟨Link Save Account⟩**
https://{DOMAIN}:81/trojan-{remarks}.txt
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** 30 Minutes
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@zenviora_id
"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trial_trojan_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)

@bot.on(events.CallbackQuery(data=cbx("renew-trojan")))
async def ren_trojan(event):
    async def ren_trojan_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username :**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        
        async with bot.conversation(chat) as exp:
            await event.respond('**Expired :**')
            exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = (await exp).raw_text

        async with bot.conversation(chat) as ip:
            await event.respond('**Limit Quota :**')
            ip = ip.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            ip = (await ip).raw_text

        async with bot.conversation(chat) as Quota:
            await event.respond('**Limit Ip :**')
            Quota = Quota.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            Quota = (await Quota).raw_text


        await event.edit("**Loading......**")
        cmd = f'printf "%s\n" "{user}" "{exp}" "{ip}" "{Quota}" | bot-renew-tro'
        # exit code backend diabaikan (script bot-renew-tro selalu exit 1
        # walau sukses) - keberhasilan diverifikasi dari kondisi sistem
        run_renew(cmd)
        # masa aktif & tanggal expired baru dibaca langsung dari sistem
        info = get_member_info("trojan", user)
        if info["exp"] == "Unknown":
            await event.respond(f"**❌ Gagal Renew User** `{user}`\n**Periksa Kembali Username-nya**",
                buttons=[[Button.inline("‹ Main Menu ›", cbx("menu"), style="success")]])
            return
        msg = f"""
**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**
**┃   ⟨RENEW TROJAN BERHASIL⟩**
**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**
**┃   👤 Username :** `{user}`
**┃   ➕ Diperpanjang :** `{exp} Hari`
**┃   ⏳ Masa Aktif :** `{info["days"]}`
**┃   📅 Expired :** `{info["exp"]}`
**┃   📦 Limit Kuota :** `{ip} GB`
**┃   🔗 Limit IP :** `{Quota} IP`
**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**
**» 🤖@zenviora_id**
"""
        await event.respond(msg, buttons=[[Button.inline("‹ Main Menu ›", cbx("menu"), style="success")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await ren_trojan_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)



# CEK member TROJAN (List Member + tombol Next)
@bot.on(events.CallbackQuery(data=cbx("cek-membertr")))
async def cek_tr(event):
    async def cek_tr_(event):
        try:
            await event.edit("**Loading......**")
            msg, buttons = render_member_page("trojan", 1)
            await event.edit(msg, buttons=buttons)
        except Exception as e:
            await event.respond(f"Error: {e}",
                buttons=[[Button.inline("‹ Main Menu ›", cbx("menu"), style="success")]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await cek_tr_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)

# navigasi halaman List Member TROJAN (tombol Next / Back)
@bot.on(events.CallbackQuery(pattern=r"^listtr-(\d+)"))
async def list_trojan_page(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Buy Premium Chat: @zenviora_id", alert=True)
    try:
        page = int(event.pattern_match.group(1))
    except Exception:
        page = 1
    msg, buttons = render_member_page("trojan", page)
    await event.edit(msg, buttons=buttons)


                
@bot.on(events.CallbackQuery(data=cbx("delete-trojan")))
async def delete_trojan(event):
    async def delete_trojan_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username :**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
        await event.edit("**Loading......**")
        cmd = f'printf "%s\n" "{user}" | bot-del-tro'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**Successfully Delete User**")
        else:
            msg = f"""**Successfully Deleted**"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await delete_trojan_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)

@bot.on(events.CallbackQuery(data=cbx("limit-trojan")))
async def limit_trojan(event):
        async def limit_trojan_(event):
                async with bot.conversation(chat) as user:
                        await event.respond("**Username :**")
                        user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        user = (await user).raw_text
                async with bot.conversation(chat) as pw:
                        await event.respond("**Limit Ip :**")
                        pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        pw = (await pw).raw_text
                        await event.edit("**Loading......**")
                        cmd = f'printf "%s\n" "{user}" "{pw}" | bot-ganti-ip-trojan'
                try:
                        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                except:
                        await event.respond(f"`{user}` **Succesfully Change Limit IP**")
                else:
                        await event.respond(f"""
```
{a}
```
**GANTI IP trojan**
**» 🤖@zenviora_id**
""",buttons=[[Button.inline("‹ Main Menu ›",cbx("menu"), style="success")]])
        chat = event.chat_id
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await limit_trojan_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)

@bot.on(events.CallbackQuery(data=cbx("quota-trojan")))
async def quota_trojan(event):
        async def quota_trojan_(event):
                async with bot.conversation(chat) as user:
                        await event.respond("**Username :**")
                        user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        user = (await user).raw_text
                async with bot.conversation(chat) as pw:
                        await event.respond("**Limit Quota :**")
                        pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        pw = (await pw).raw_text
                        await event.edit("**Loading......**")
                        cmd = f'printf "%s\n" "{user}" "{pw}" | bot-quota-trj'
                try:
                        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                except:
                        await event.respond(f"`{user}` **Succesfully Change Limit Quota**")
                else:
                        await event.respond(f"""
```
{a}
```
**GANTI QUOTA trojan**
**» 🤖@zenviora_id**
""",buttons=[[Button.inline("‹ Main Menu ›",cbx("menu"), style="success")]])
        chat = event.chat_id
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await quota_trojan_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)

@bot.on(events.CallbackQuery(data=cbx("lock-trojan")))
async def lock_trojan(event):
        async def lock_trojan_(event):
                async with bot.conversation(chat) as exp:
                        await event.respond("**Username :**")
                        exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        exp = (await exp).raw_text
                await event.edit("**Loading......**")
                cmd = f'printf "%s\n" "{exp}" | bot-lock-trj'
                try:
                        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                except:
                        await event.respond(f"**User** `{exp}` **Successfully Locked**")
                else:
                        msg = f"""**Successfully Locked**"""
                        await event.respond(msg)
        chat = event.chat_id
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await lock_trojan_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)
#UNLOCK ssh
@bot.on(events.CallbackQuery(data=cbx("unlock-trojan")))
async def unlock_trojan(event):
        async def unlock_trojan_(event):
                async with bot.conversation(chat) as exp:
                        await event.respond("**Username :**")
                        exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        exp = (await exp).raw_text
                await event.edit("**Loading......**")
                cmd = f'printf "%s\n" "{exp}" | bot-unlock-trj'
                try:
                        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                except:
                        await event.respond(f"**User** `{exp}` **Successfully Unlocked**")
                else:
                        msg = f"""**Successfully Unlocked**"""
                        await event.respond(msg)
        chat = event.chat_id
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await unlock_trojan_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)

@bot.on(events.CallbackQuery(data=cbx("trojan")))
async def trojan(event):
    async def trojan_(event):
        inline = [
            [Button.inline("Trial", cbx("trial-trojan"), style="success"),
             Button.inline("Create", cbx("create-trojan"), style="success")],
            [Button.inline("Check User Login", cbx("cek-tr"), style="success")],
            [Button.inline("Renew", cbx("renew-trojan"), style="success"),
             Button.inline("Delete", cbx("delete-trojan"), style="danger")],           
            [Button.inline("List member", cbx("cek-membertr"), style="success")],
            [Button.inline("Lock", cbx("lock-trojan"), style="danger"),
             Button.inline("Unlock", cbx("unlock-trojan"), style="success")],
            [Button.inline("Change Limit IP", cbx("limit-trojan"), style="success")],
            [Button.inline("Change Limit Quota", cbx("quota-trojan"), style="success")],
             [Button.inline("‹ Main Menu ›", cbx("menu"), style="success")]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**
**┃   ⟨TROJAN SERVICE⟩**
**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**
**┃   » Service :** `Trojan`
**┃   » Domain :** `{DOMAIN}`
**┃   » ISP :** `{z["isp"]}`
**┃   » Country :** `{z["country"]}`
**┃   » 🤖@zenviora_id**
**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**
        """
        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trojan_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)