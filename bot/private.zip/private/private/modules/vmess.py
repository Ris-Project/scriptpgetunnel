from private import *
import subprocess
import json
import base64
import datetime as DT
import requests
import time
import random
import asyncio
import tempfile
import re
from telethon import events, Button

env = load_env_vars()
DOMAIN = env.get("DOMAIN", "Tidak Diketahui")

@bot.on(events.CallbackQuery(data=cbx("create-vmess")))
async def create_vmess(event):
    async def create_vmess_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username :**')
            user = (await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        async with bot.conversation(chat) as exp_conv:
            await event.respond('**Expired :**')
            exp = (await exp_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        async with bot.conversation(chat) as ip_conv:
            await event.respond('**Limit Quota :**')
            ip = (await ip_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text

        async with bot.conversation(chat) as Quota_conv:
            await event.respond('**Limit Ip :**')
            Quota = (await Quota_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))).raw_text
         
        await event.edit("**Loading......**")
        cmd = f'printf "%s\n" "{user}" "{exp}" "{ip}" "{Quota}" | addws-bot'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"An error occurred: {e}\nSubprocess output: {a}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=int(exp))
        b = [x.group() for x in re.finditer("vmess://(.*)", a)]

        z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
        z = json.loads(z)

        z1 = base64.b64decode(b[1].replace("vmess://", "")).decode("ascii")
        z1 = json.loads(z1)

        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
     **  ◇⟨VMESS ACCOUNT⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» Username :** `{user}`
**» Domain :** `{DOMAIN}`
**» Limit Quota :** `{ip} GB`
**» Limit Login :** `{Quota} HP`
**» HTTP :** `80,8880,2052,2086,2095`
**» HTTPS :** `443,2053,2087,2096`
**» UUID    :** `{z["id"]}`
**» Network     :** `(WS) or (gRPC)`
**» Path        :** `/viip-vmess`
**» ServiceName :** `vmess-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK TLS 443      :**
```{b[0].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK NON-TLS 80   :**
```{b[1].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK gRPC TLS 443 :** 
```{b[2].strip("'")}```
**◇━━━━━━━━━━━━━━━━━◇**
**⟨Link Save Account⟩**
https://{DOMAIN}:81/vmess-{user}.txt
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** `{later}`
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@zenviora_id


        """

        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await create_vmess_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)


@bot.on(events.CallbackQuery(data=cbx("trial-vmess")))
async def trial_vmess(event):
    async def trial_vmess_(event):
      
        await event.edit("**Loading......**")
        cmd = f'printf "%s\n" "TrialVM`</dev/urandom tr -dc X-Z0-9 | head -c4`" "1" "1" "1" | bot-trialvmess'

        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception as e:
            print(f'Error: {e}')
            print(f'Subprocess output: {a}')
            await event.respond(f"An error occurred: {e}\nSubprocess output: {a}")
            return  # Stop execution if there's an error

        today = DT.date.today()
        later = today + DT.timedelta(days=1)  # You may need to adjust this, as "exp" is not defined in the scope
        b = [x.group() for x in re.finditer("vmess://(.*)", a)]

        z = base64.b64decode(b[0].replace("vmess://", "")).decode("ascii")
        z = json.loads(z)

        z1 = base64.b64decode(b[1].replace("vmess://", "")).decode("ascii")
        z1 = json.loads(z1)
        
        remarks = z.get("ps", "N/A")

        msg = f"""
**◇━━━━━━━━━━━━━━━━━◇**
**◇⟨TRIAL VMESS ACCOUNT⟩◇**
**◇━━━━━━━━━━━━━━━━━◇**
**» Username :** `{remarks}`
**» Host Server :** `{DOMAIN}`
**» HTTP :** `80,8880,2052,2086,2095`
**» HTTPS :** `443,2053,2087,2096`
**» UUID    :** `{z["id"]}`
**» NetWork     :** `(WS) or (gRPC)`
**» Path        :** `/viip-vmess`
**» ServiceName :** `vmess-grpc`
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK TLS 443      :**
```{b[0].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK NON-TLS 80   :**
```{b[1].strip("'").replace(" ","")}```
**◇━━━━━━━━━━━━━━━━━◇**
**» LINK gRPC TLS 443 :** 
```{b[2].strip("'")}```
**◇━━━━━━━━━━━━━━━━━◇**
**⟨Link Save Account⟩**
https://{DOMAIN}:81/vmess-{remarks}.txt
**◇━━━━━━━━━━━━━━━━━◇**
**» Expired Until:** 30 Minutes
**◇━━━━━━━━━━━━━━━━━◇**
**» ** 🤖@zenviora_id
        """
        await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await trial_vmess_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)
        

#CEK VMESS
@bot.on(events.CallbackQuery(data=cbx("cek-vmess")))
async def cek_vmess(event):
    async def cek_vmess_(event):
        cmd = 'cek-ws'.strip()
        result = subprocess.check_output(
            cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True, env={"TERM": "xterm"}
        )

        # Hapus karakter escape ANSI
        clean_result = re.sub(r'\x1B(?:[@-Z\\-_]|\[[0-?]*[ -/]*[@-~])', '', result).strip()

        await event.edit(f"""
**◇━━━━━━━━━━━━━━━━━━◇**
 ** ◇⟨Cek Vmess User Login⟩◇**
**◇━━━━━━━━━━━━━━━━━━◇**
{clean_result}

**Shows Logged In Users Vmess**
""", buttons=[[Button.inline("‹ Main Menu ›", cbx("vmess"))]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await cek_vmess_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)



## CEK member VMESS (List Member + tombol Next)
@bot.on(events.CallbackQuery(data=cbx("cek-member")))
async def cek_vmess(event):
    async def cek_vmess_(event):
        try:
            await event.edit("**Loading......**")
            msg, buttons = render_member_page("vmess", 1)
            await event.edit(msg, buttons=buttons)
        except Exception as e:
            await event.respond(f"Error: {e}",
                buttons=[[Button.inline("‹ Main Menu ›", cbx("menu"))]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await cek_vmess_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)

# navigasi halaman List Member VMESS (tombol Next / Back)
@bot.on(events.CallbackQuery(pattern=r"^listvm-(\d+)"))
async def list_vmess_page(event):
    sender = await event.get_sender()
    if valid(str(sender.id)) != "true":
        return await event.answer("Buy Premium Chat: @zenviora_id", alert=True)
    try:
        page = int(event.pattern_match.group(1))
    except Exception:
        page = 1
    msg, buttons = render_member_page("vmess", page)
    await event.edit(msg, buttons=buttons)





@bot.on(events.CallbackQuery(data=cbx("delete-vmess")))
async def delete_vmess(event):
    async def delete_vmess_(event):
        async with bot.conversation(chat) as user:
            await event.respond('**Username:**')
            user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = (await user).raw_text
            await event.edit("**Loading......**")
        cmd = f'printf "%s\n" "{user}" | bot-del-vme'
        try:
            a = subprocess.check_output(cmd, shell=True).decode("utf-8")
        except:
            await event.respond("**Successfully Delete User**")
        else:
            msg = f"""**Successfully Deleted**"""
            await event.respond(msg)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await delete_vmess_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)
        

@bot.on(events.CallbackQuery(data=cbx("renew-vmess")))
async def ren_vmess(event):
    async def ren_vmess_(event):
        async with bot.conversation(chat) as user_conv:
            await event.respond('**Username :**')
            user = await user_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            user = user.raw_text

        async with bot.conversation(chat) as exp_conv:
            await event.respond('**Expired :**')
            exp = await exp_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            exp = exp.raw_text
            
        async with bot.conversation(chat) as ip_conv:
            await event.respond('**Limit Quota:**')
            ip = await ip_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            ip = ip.raw_text
            
        async with bot.conversation(chat) as Quota_conv:
            await event.respond('**Limit Ip :**')
            Quota = await Quota_conv.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
            Quota = Quota.raw_text         
    
        await event.edit("**Loading......**")
        cmd = f'printf "%s\n" "{user}" "{exp}" "{ip}" "{Quota}" | bot-renew-vme'

        try:
            subprocess.check_output(cmd, shell=True).decode("utf-8")
        except Exception:
            await event.respond(f"**❌ Gagal Renew User** `{user}`\n**Periksa Kembali Username-nya**",
                buttons=[[Button.inline("‹ Main Menu ›", cbx("menu"))]])
            return
        # masa aktif & tanggal expired baru dibaca langsung dari sistem
        info = get_member_info("vmess", user)
        msg = f"""
**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**
**┃   ⟨RENEW VMESS BERHASIL⟩**
**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**
**┃   👤 Username :** `{user}`
**┃   ➕ Diperpanjang :** `{exp} Hari`
**┃   ⏳ Masa Aktif :** `{info["days"]}`
**┃   📅 Expired :** `{info["exp"]}`
**┃   📦 Limit Kuota :** `{ip} GB`
**┃   🔗 Limit IP :** `{Quota} IP`
**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**
**» 🤖@zenviora_id**
"""
        await event.respond(msg, buttons=[[Button.inline("‹ Main Menu ›", cbx("menu"))]])

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await ren_vmess_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)

@bot.on(events.CallbackQuery(data=cbx("limit-vmess")))
async def limit_vmess(event):
        async def limit_vmess_(event):
                async with bot.conversation(chat) as user:
                        await event.respond("**Username :**")
                        user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        user = (await user).raw_text
                async with bot.conversation(chat) as pw:
                        await event.respond("**Limit Ip :**")
                        pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        pw = (await pw).raw_text
                        await event.edit("**Loading......**")
                        cmd = f'printf "%s\n" "{user}" "{pw}" | bot-ganti-ip-vmess'
                try:
                        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                except:
                        await event.respond(f"`{user}` **Succesfully Change Limit IP**")
                else:
                        await event.respond(f"""
```
{a}
```
**GANTI IP VMESS**
**» 🤖@zenviora_id**
""",buttons=[[Button.inline("‹ Main Menu ›",cbx("menu"))]])
        chat = event.chat_id
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await limit_vmess_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)

@bot.on(events.CallbackQuery(data=cbx("quota-vmess")))
async def quota_vmess(event):
        async def quota_vmess_(event):
                async with bot.conversation(chat) as user:
                        await event.respond("**Username :**")
                        user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        user = (await user).raw_text
                async with bot.conversation(chat) as pw:
                        await event.respond("**Limit Quota :**")
                        pw = pw.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        pw = (await pw).raw_text
                        await event.edit("**Loading......**")
                        cmd = f'printf "%s\n" "{user}" "{pw}" | bot-quota-vm'
                try:
                        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                except:
                        await event.respond(f"`{user}` **Succesfully Change Limit Quota**")
                else:
                        await event.respond(f"""
```
{a}
```
**GANTI QUOTA VMESS**
**» 🤖@zenviora_id**
""",buttons=[[Button.inline("‹ Main Menu ›",cbx("menu"))]])
        chat = event.chat_id
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await quota_vmess_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)

@bot.on(events.CallbackQuery(data=cbx("lock-vmess")))
async def lock_vmess(event):
        async def lock_vmess_(event):
                async with bot.conversation(chat) as exp:
                        await event.respond("**Username :**")
                        exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        exp = (await exp).raw_text
                await event.edit("**Loading......**")
                cmd = f'printf "%s\n" "{exp}" | bot-lock-vm'
                try:
                        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                except:
                        await event.respond(f"**User** `{exp}` **Successfully Locked**")
                else:
                        msg = f"""**User** `{exp}` **Successfully Locked**"""
                        await event.respond(msg)
        chat = event.chat_id
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await lock_vmess_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)
#UNLOCK ssh
@bot.on(events.CallbackQuery(data=cbx("unlock-vmess")))
async def unlock_vmess(event):
        async def unlock_vmess_(event):
                async with bot.conversation(chat) as exp:
                        await event.respond("**Username :**")
                        exp = exp.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
                        exp = (await exp).raw_text
                await event.edit("**Loading......**")
                cmd = f'printf "%s\n" "{exp}" | bot-unlock-vm'
                try:
                        a = subprocess.check_output(cmd, shell=True).decode("utf-8")
                except:
                        await event.respond(f"**User** `{exp}` **Successfully Unlocked**")
                else:
                        msg = f"""**User** `{exp}` **Successfully Unlocked**"""
                        await event.respond(msg)
        chat = event.chat_id
        sender = await event.get_sender()
        a = valid(str(sender.id))
        if a == "true":
                await unlock_vmess_(event)
        else:
                await event.answer("Buy Premium Chat: @zenviora_id",alert=True)
                
@bot.on(events.CallbackQuery(data=cbx("vmess")))
async def vmess(event):
    async def vmess_(event):
        inline = [
            [Button.inline("Trial", cbx("trial-vmess")),
             Button.inline("Create", cbx("create-vmess"))],
            [Button.inline("Check User Login", cbx("cek-vmess"))],
            [Button.inline("Renew", cbx("renew-vmess")),
            Button.inline("Delete", cbx("delete-vmess"))],
            [Button.inline("List Member", cbx("cek-member"))],
            [Button.inline("Lock", cbx("lock-vmess")),
            Button.inline("Unlock", cbx("unlock-vmess"))],
            [Button.inline("Change Limit IP", cbx("limit-vmess"))],
            [Button.inline("Change Limit Quota", cbx("quota-vmess"))],
            [Button.inline("‹ Main Menu ›", cbx("menu"))]
        ]
        z = requests.get(f"http://ip-api.com/json/?fields=country,region,city,timezone,isp").json()
        msg = f"""
**┏━━━━━━━━━━━━━━━━━━━━━━━━━┓**
**┃   ⟨VMESS SERVICE⟩**
**┣━━━━━━━━━━━━━━━━━━━━━━━━━┫**
**┃   » Service :** `Vmess`
**┃   » Domain :** `{DOMAIN}`
**┃   » ISP :** `{z["isp"]}`
**┃   » Country :** `{z["country"]}`
**┃   » 🤖@zenviora_id**
**┗━━━━━━━━━━━━━━━━━━━━━━━━━┛**
"""
        await event.edit(msg, buttons=inline)

    chat = event.chat_id
    sender = await event.get_sender()
    a = valid(str(sender.id))  # Memanggil fungsi valid

    if a == "true":
        await vmess_(event)
    else:
        await event.answer("Buy Premium Chat: @zenviora_id", alert=True)



