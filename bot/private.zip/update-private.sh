#!/bin/bash
# ============================================================
#  UPDATER BOT PRIVATE (private-fixed.zip)
#  - Auto-deteksi lokasi package bot yang terpasang di VPS
#  - Backup otomatis sebelum menimpa
#  - Tidak menyentuh var.txt & session bot (login tetap aman)
#  Pakai:  bash update-private.sh
# ============================================================

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
ok()   { echo -e "${GREEN}[OK]${NC} $1"; }
warn() { echo -e "${YELLOW}[!]${NC} $1"; }
err()  { echo -e "${RED}[GAGAL]${NC} $1"; }

# ---- folder sumber (file baru) : folder private/private di sebelah script ini
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC=""
for cand in "$SCRIPT_DIR/private/private" "$SCRIPT_DIR/private"; do
    [ -f "$cand/__init__.py" ] && SRC="$cand" && break
done
if [ -z "$SRC" ]; then
    err "Folder package baru tidak ditemukan di samping script ini ($SCRIPT_DIR)."
    err "Pastikan update-private.sh ada di dalam folder hasil extract private-fixed.zip"
    exit 1
fi
ok "Sumber file baru : $SRC"

# ---- cari lokasi package bot yang sedang terpasang
DST=""
for cand in "/usr/bin/private/private" "/usr/bin/private" \
            "/root/private/private" "/root/private" \
            "/opt/private/private" "/opt/private" \
            "/usr/local/private/private" "/usr/local/private"; do
    [ -f "$cand/__init__.py" ] && DST="$cand" && break
done
if [ -z "$DST" ]; then
    warn "Lokasi otomatis tidak ketemu, mencari di seluruh sistem (bisa sebentar)..."
    DST=$(find /usr /root /home /opt /etc -maxdepth 4 -name "__init__.py" \
          -path "*private*" 2>/dev/null | head -1 | xargs -r dirname)
fi
if [ -z "$DST" ] || [ ! -f "$DST/__init__.py" ]; then
    err "Package bot private tidak ditemukan di VPS ini."
    err "Install dulu seperti biasa, atau jalankan manual: copy isi folder"
    err "$SRC ke folder package bot kamu, lalu restart service bot."
    exit 1
fi
ok "Package terpasang di : $DST"

# ---- backup
BACKUP="${DST}_backup_$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP"
cp -a "$DST"/. "$BACKUP"/ 2>/dev/null
ok "Backup lama disimpan di : $BACKUP"

# ---- salin file baru (JANGAN timpa var.txt & session)
find "$SRC" -type f ! -name "var.txt" ! -name "*.session" | while read -r f; do
    rel="${f#$SRC/}"
    mkdir -p "$DST/$(dirname "$rel")"
    cp -f "$f" "$DST/$rel" && ok "  update: $rel"
done

# ---- upgrade Telethon (tombol berwarna success/primary/danger butuh >= 1.45)
if command -v pip3 >/dev/null 2>&1; then
    CUR=$(pip3 show telethon 2>/dev/null | awk '/^Version:/{print $2}')
    if [ "$CUR" = "1.45.0" ]; then
        ok "Telethon sudah 1.45.0"
    else
        warn "Upgrade Telethon ${CUR:-belum ada} -> 1.45.0 (butuh untuk tombol berwarna)..."
        if pip3 install -q --upgrade "telethon==1.45.0"; then
            ok "Telethon 1.45.0 terpasang - tombol success/primary/danger AKTIF"
        else
            warn "Upgrade telethon gagal. Jalankan manual: pip3 install -U telethon==1.45.0"
            warn "(Bot tetap jalan dengan telethon lama, tapi tombol tampil tanpa warna)"
        fi
    fi
else
    warn "pip3 tidak ketemu. Install manual: pip3 install -U telethon==1.45.0"
fi

# ---- restart service bot
RESTARTED=0
for svc in private bot-private; do
    if systemctl list-unit-files 2>/dev/null | grep -q "^${svc}.service"; then
        systemctl daemon-reload 2>/dev/null
        systemctl restart "$svc" && ok "Service $svc di-restart" && RESTARTED=1
        break
    fi
done
if [ "$RESTARTED" -eq 0 ]; then
    warn "Service bot tidak ketemu otomatis. Restart manual dengan cara biasa kamu menjalankan bot."
fi

echo ""
ok "SELESAI. Cek bot: kirim /menu ke bot, lalu coba Renew akun vmess/vless/trojan/shadowsocks."
warn "Catatan: kalau mau kembali ke versi lama, copy isi folder backup ke $DST"
