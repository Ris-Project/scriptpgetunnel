import logging
import subprocess
import requests
import time
import re
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, KeyboardButton, ReplyKeyboardMarkup
from telegram.ext import (
    Updater, CommandHandler, CallbackContext, ConversationHandler,
    MessageHandler, Filters, CallbackQueryHandler
)

# Ganti dengan TOKEN Anda
TOKEN = "8046744090:AAHABSWkRcILDhjvU9-Xn8nPoFz6SuBkJHQ"
IP_LIST_URL = 'https://raw.githubusercontent.com/Ris-Project/scriptpgetunnel/main/ip'

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

REGISTER_IP, REGISTER_NAME, REGISTER_EXP, EXTEND_IP, EXTEND_DAYS, DELETE_IP, CHANGE_IP_OLD, CHANGE_IP_NEW = range(8)

ip_cache = {"data": [], "raw_lines": [], "last_updated": 0}
CACHE_DURATION_SECONDS = 300

def update_ip_cache(force_update: bool = False) -> bool:
    global ip_cache
    current_time = time.time()
    if not force_update and (current_time - ip_cache['last_updated'] < CACHE_DURATION_SECONDS):
        return True
    try:
        headers = {'Cache-Control': 'no-cache'}
        response = requests.get(IP_LIST_URL, timeout=10, headers=headers)
        response.raise_for_status()
        lines = response.text.strip().splitlines()
        ip_cache['raw_lines'] = lines
        formatted_data = []
        for line in lines:
            if line.startswith("###"):
                parts = line.replace("### ", "").split()
                name, exp, ip = "N/A", "N/A", "N/A"
                if len(parts) >= 3:
                    name, exp, ip = parts[0], parts[1], parts[2]
                elif len(parts) == 2:
                    name, ip = parts[0], parts[1]; exp = "lifetime"
                # Menggunakan format Markdown biasa
                formatted_entry = (f"🏷️ » Client: `{name}`\n🏷️ » IP: `{ip}`\n🏷️ » Exp: `{exp}`")
                formatted_data.append(formatted_entry)
        ip_cache['data'] = formatted_data
        ip_cache['last_updated'] = current_time
        return True
    except requests.RequestException as e:
        logger.error(f"Gagal memperbarui cache IP: {e}")
        return False


def load_admin_ids(file_path):
    try:
        with open(file_path, 'r') as file:
            return {int(line.strip()) for line in file if line.strip().isdigit()}
    except Exception as e:
        logger.error(f"Error loading admin IDs: {e}"); return set()

ADMIN_IDS = load_admin_ids('lite.txt')

def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS

def run_script_with_loading(update: Update, context: CallbackContext, command: list, success_message: str):
    loading_message = update.message.reply_text("⏳ <b>Sedang memproses, mohon tunggu...</b>", parse_mode='HTML')
    try:
        result = subprocess.run(command, capture_output=True, text=True, check=True)
        html_output_from_bash = result.stdout
        context.bot.edit_message_text(
            chat_id=loading_message.chat_id, 
            message_id=loading_message.message_id,
            text=f"✅ <b>{success_message}</b>\n\n{html_output_from_bash}",
            parse_mode='HTML'
        )
        logger.info("Menunggu 3 detik untuk sinkronisasi GitHub...")
        time.sleep(3)
        update_ip_cache(force_update=True)
        logger.info("Cache diperbarui setelah jeda.")

    except subprocess.CalledProcessError as e:
        context.bot.edit_message_text(
            chat_id=loading_message.chat_id, message_id=loading_message.message_id,
            text=f"❌ <b>Gagal! Terjadi kesalahan.</b>\n\n<pre>{e.stderr}</pre>", parse_mode='HTML'
        )
    except Exception as e:
        logger.error(f"Error while running script: {e}"); context.bot.edit_message_text(
            chat_id=loading_message.chat_id, message_id=loading_message.message_id,
            text=f"🚨 <b>Terjadi kesalahan internal pada bot:</b> {e}", parse_mode='HTML')

def start(update: Update, context: CallbackContext) -> None:
    user_id = update.message.from_user.id
    if not is_admin(user_id): return
    keyboard = [
        [KeyboardButton("🥇 Daftarkan IP"), KeyboardButton("🥈 Perpanjang IP")],
        [KeyboardButton("🥉 Hapus IP"), KeyboardButton("✏️ Ubah IP")],
        [KeyboardButton("📋 Daftar IP")]
    ]
    reply_markup = ReplyKeyboardMarkup(keyboard, resize_keyboard=True)
    update_ip_cache()
    total_ips = len(ip_cache.get('data', []))
    username = update.message.from_user.username or "Tanpa_Username"
    update.message.reply_text(
        text=(
            f"◇⟨💠 <b>Tales Of Free Net Lite</b> 💠⟩◇\n\n"
            f"Username: @{username}\nID: <code>{user_id}</code>\n"
            f"Total IP Terdaftar: <b>{total_ips}</b>\n\n"
            "Silahkan pilih menu dari keyboard di bawah:"
        ),
        reply_markup=reply_markup,
        parse_mode='HTML'
    )

def main_menu_handler(update: Update, context: CallbackContext) -> int:
    user_text = update.message.text
    if user_text == "🥇 Daftarkan IP":
        update.message.reply_text("♂️ <b>Masukkan IP yang ingin didaftarkan:</b>", parse_mode='HTML')
        return REGISTER_IP
    elif user_text == "🥈 Perpanjang IP":
        update.message.reply_text("♻️ <b>Masukkan IP yang ingin diperpanjang:</b>", parse_mode='HTML')
        return EXTEND_IP
    elif user_text == "🥉 Hapus IP":
        update.message.reply_text("🗑️ <b>Masukkan IP yang ingin dihapus:</b>", parse_mode='HTML')
        return DELETE_IP
    elif user_text == "✏️ Ubah IP":
        update.message.reply_text("✏️ <b>Masukkan IP LAMA yang ingin diubah:</b>", parse_mode='HTML')
        return CHANGE_IP_OLD
    elif user_text == "📋 Daftar IP":
        update_ip_cache(force_update=True) 
        context.user_data['list_data'] = ip_cache['data']
        context.user_data['page'] = 0
        send_ip_page(update.message.chat.id, context)
        return ConversationHandler.END
    return ConversationHandler.END

# ... (Fungsi-fungsi registrasi, perpanjang, hapus, ubah tidak berubah) ...
def register_ip_step(update: Update, context: CallbackContext) -> int:
    context.user_data['ip'] = update.message.text
    update.message.reply_text("✍️ <b>Masukkan Nama:</b>", parse_mode='HTML')
    return REGISTER_NAME

def register_name_step(update: Update, context: CallbackContext) -> int:
    context.user_data['name'] = update.message.text
    update.message.reply_text("📅 <b>Masukkan Masa Berlaku (hari):</b>", parse_mode='HTML')
    return REGISTER_EXP

def register_finalize_step(update: Update, context: CallbackContext) -> int:
    command = ["/bin/bash", "literegis.sh", context.user_data['ip'], context.user_data['name'], update.message.text]
    run_script_with_loading(update, context, command, "IP Berhasil Didaftarkan")
    return ConversationHandler.END

def extend_ip_step(update: Update, context: CallbackContext) -> int:
    context.user_data['ip'] = update.message.text
    update.message.reply_text("📅 <b>Masukkan Tambahan Hari:</b>", parse_mode='HTML')
    return EXTEND_DAYS

def extend_finalize_step(update: Update, context: CallbackContext) -> int:
    command = ["/bin/bash", "liteextend.sh", context.user_data['ip'], update.message.text]
    run_script_with_loading(update, context, command, "Masa Berlaku Berhasil Diperpanjang")
    return ConversationHandler.END

def delete_finalize_step(update: Update, context: CallbackContext) -> int:
    command = ["/bin/bash", "litedelete.sh", update.message.text]
    run_script_with_loading(update, context, command, "IP Berhasil Dihapus")
    return ConversationHandler.END

def change_ip_old_step(update: Update, context: CallbackContext) -> int:
    context.user_data['old_ip'] = update.message.text
    update.message.reply_text("🏷️ <b>Masukkan IP BARU sebagai pengganti:</b>", parse_mode='HTML')
    return CHANGE_IP_NEW

def change_ip_finalize_step(update: Update, context: CallbackContext) -> int:
    command = ["/bin/bash", "liteubah.sh", context.user_data['old_ip'], update.message.text]
    run_script_with_loading(update, context, command, "IP Berhasil Diubah")
    return ConversationHandler.END

# ## PERUBAHAN DI SINI ##
def send_ip_page(chat_id: int, context: CallbackContext):
    data = context.user_data.get('list_data', [])
    page = context.user_data.get('page', 0)
    per_page = 5
    start_index, end_index = page * per_page, (page + 1) * per_page
    paginated_data = data[start_index:end_index]
    # Menggunakan *...* untuk bold dan `Markdown` biasa
    text = f"*📋 Daftar IP Terdaftar (Hal {page + 1})*\n\n" + "\n\n".join(paginated_data) if paginated_data else "*Tidak ada IP yang terdaftar.*"
    keyboard_row = []
    if page > 0: keyboard_row.append(InlineKeyboardButton("⬅️", callback_data='prev_page'))
    if end_index < len(data): keyboard_row.append(InlineKeyboardButton("➡️", callback_data='next_page'))
    reply_markup = InlineKeyboardMarkup([keyboard_row]) if keyboard_row else None
    
    # Menggunakan parse_mode="Markdown"
    message = context.bot.send_message(chat_id=chat_id, text=text, reply_markup=reply_markup, parse_mode="Markdown")
    context.user_data['message_id'] = message.message_id

# ## DAN PERUBAHAN DI SINI ##
def pagination_handler(update: Update, context: CallbackContext) -> None:
    query = update.callback_query
    query.answer()

    if 'message_id' not in context.user_data:
        return 

    if query.data == 'next_page': context.user_data['page'] += 1
    elif query.data == 'prev_page': context.user_data['page'] -= 1
    
    data = context.user_data.get('list_data', [])
    page = context.user_data.get('page', 0)
    per_page = 5
    start_index, end_index = page * per_page, (page + 1) * per_page
    paginated_data = data[start_index:end_index]
    # Menggunakan *...* untuk bold
    text = f"*📋 Daftar IP Terdaftar (Hal {page + 1})*\n\n" + "\n\n".join(paginated_data)
    keyboard_row = []
    if page > 0: keyboard_row.append(InlineKeyboardButton("⬅️", callback_data='prev_page'))
    if end_index < len(data): keyboard_row.append(InlineKeyboardButton("➡️", callback_data='next_page'))
    reply_markup = InlineKeyboardMarkup([keyboard_row]) if keyboard_row else None
    
    try:
        # Menggunakan parse_mode="Markdown"
        query.edit_message_text(text=text, reply_markup=reply_markup, parse_mode="Markdown")
    except Exception as e:
        logger.warning(f"Gagal edit pesan paginasi: {e}")


def main() -> None:
    updater = Updater(TOKEN)
    dispatcher = updater.dispatcher
    MENU_REGEX = "^(🥇 Daftarkan IP|🥈 Perpanjang IP|🥉 Hapus IP|✏️ Ubah IP|📋 Daftar IP)$"
    conv_handler = ConversationHandler(
        entry_points=[MessageHandler(Filters.regex(MENU_REGEX) & Filters.private, main_menu_handler)],
        states={
            REGISTER_IP: [MessageHandler(Filters.text & ~Filters.command, register_ip_step)],
            REGISTER_NAME: [MessageHandler(Filters.text & ~Filters.command, register_name_step)],
            REGISTER_EXP: [MessageHandler(Filters.text & ~Filters.command, register_finalize_step)],
            EXTEND_IP: [MessageHandler(Filters.text & ~Filters.command, extend_ip_step)],
            EXTEND_DAYS: [MessageHandler(Filters.text & ~Filters.command, extend_finalize_step)],
            DELETE_IP: [MessageHandler(Filters.text & ~Filters.command, delete_finalize_step)],
            CHANGE_IP_OLD: [MessageHandler(Filters.text & ~Filters.command, change_ip_old_step)],
            CHANGE_IP_NEW: [MessageHandler(Filters.text & ~Filters.command, change_ip_finalize_step)],
        },
        fallbacks=[CommandHandler('start', start)],
        allow_reentry=True
    )
    dispatcher.add_handler(CommandHandler("start", start))
    dispatcher.add_handler(CommandHandler("menu", start))
    dispatcher.add_handler(conv_handler)
    dispatcher.add_handler(CallbackQueryHandler(pagination_handler))
    update_ip_cache(force_update=True)
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()