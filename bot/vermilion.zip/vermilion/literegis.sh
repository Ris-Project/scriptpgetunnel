#!/bin/bash
export HOME=/root
export TERM=xterm
NC='\e[0m'
dateFromServer=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
biji=`date +"%Y-%m-%d" -d "$dateFromServer"`
ipsaya=$(curl -sS ipv4.icanhazip.com)
data_server=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
date_list=$(date +"%Y-%m-%d" -d "$data_server")
data_ip="https://raw.githubusercontent.com/Ris-Project/scriptpgetunnel/main/ip-bot"
checking_sc() {
  useexp=$(wget -qO- $data_ip | grep $ipsaya | awk '{print $3}')
  if [[ $date_list < $useexp ]]; then
    echo -ne
  else
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    echo -e "\033[42m          ANDA HARUS MENDAFTAR DAHULU UNTUK MENJADI SELLER         \033[0m"
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    echo -e ""
    echo -e "            ${RED}DAFTAR DULU DEK !${NC}"
    echo -e "   \033[0;33mYour VPS${NC} $ipsaya \033[0;33mHas been Banned${NC}"
    echo -e "     \033[0;33mBuy access permissions for scripts${NC}"
    echo -e "             \033[0;33mContact Admin :${NC}"
    echo -e "      \033[0;36mTelegram${NC} t.me/LITE_VERMILION"
    echo -e "      ${GREEN}WhatsApp${NC} wa.me/6281934335091"
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    exit
  fi
}
checking_sc
Repo1="https://raw.githubusercontent.com/Ris-Project/scriptpgetunnel/main/"
export MYIP=$( curl -sS ipv4.icanhazip.com/ )
SELLER=$(curl -sS ${Repo1}ip | grep $MYIP | awk '{print $2}')
Exp100=$(curl -sS ${Repo1}ip | grep $MYIP | awk '{print $3}')
data_ip="https://raw.githubusercontent.com/Ris-Project/scriptpgetunnel/main/ip"
d2=$(date -d "$date_list" +"+%s")
d1=$(date -d "$Exp" +"+%s")
dayleft=$(( ($d1 - $d2) / 86400 ))
####
REPO="https://github.com/Ris-Project/scriptpgetunnel.git"
TOKEN="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"
EMAIL="riswanxproject@gmail.com"
USER="Ris-Project"
today=$(date -d "0 days" +"%Y-%m-%d")
#####

# Ambil parameter dari perintah addip
ip="$1"
name="$2"
exp="$3"

git clone ${REPO} /root/ipvps/
CLIENT_EXISTS=$(grep -w $ip /root/ipvps/ip | wc -l)
if [[ ${CLIENT_EXISTS} == '1' ]]; then
echo "IP Already Exist !"
rm -rf /root/ipvps
exit 0
fi

exp2=`date -d "${exp} days" +"%Y-%m-%d"`
echo "### ${name} ${exp2} ${ip}" >> /root/ipvps/ip

cd /root/ipvps
git config --global user.email "${EMAIL}"
git config --global user.name "${USER}"
rm -rf .git &> /dev/null
git init &> /dev/null
git add . &> /dev/null
git commit -m literegis &> /dev/null
git branch -M main &> /dev/null
git remote add origin https://github.com/Ris-Project/scriptpgetunnel.git
git push -f https://${TOKEN}@github.com/Ris-Project/scriptpgetunnel.git &> /dev/null
rm -rf /root/ipvps

echo -e "◇━━━━━━━━━━━━━━━━━━━◇"
echo -e "<b>◇⟨SUCCESSFULLY REGISTERED⟩</b>◇"
echo -e "◇━━━━━━━━━━━━━━━━━━━◇"
echo -e "🏷️ <b>Username:</b> <code>${name}</code>"
echo -e "🏷️ <b>IP Address:</b> <code>${ip}</code>"
echo -e "🏷️ <b>Expired:</b> <code>${exp2}</code>"
echo -e "◇━━━━━━━━━━━━━━━━━━━◇"
echo -e "❇️ <b>» Pemasangan Tahap 1:</b>"
echo -e "◇━━━━━━━━━━━━━━━━━━━◇"
echo -e "<code>apt update -y && apt upgrade -y --fix-missing && apt install -y xxd bzip2 wget curl sudo lsof socat net-tools bc coreutils build-essential bsdmainutils screen dos2unix && update-grub && apt dist-upgrade -y && sleep 2 && reboot</code>"
echo -e "◇━━━━━━━━━━━━━━━━━━━◇"
echo -e "❇️ <b>» Pemasangan Tahap 2:</b>"
echo -e "◇━━━━━━━━━━━━━━━━━━━◇"
echo -e "<code>screen -S setup-session bash -c \"wget -q https://raw.githubusercontent.com/x-only/main/install.sh && chmod +x install.sh && ./install.sh; read -p 'Tekan enter untuk keluar...'\"</code>"
echo -e "◇━━━━━━━━━━━━━━━━━━━◇"
echo -e "⚠️ <b>Jika Terjadi Disconnect Saat Proses Penginstallan, Gunakan Perintah Di Bawah Ini:</b>"
echo -e "◇━━━━━━━━━━━━━━━━━━━◇"
echo -e "<code>screen -r -d setup</code>"
echo -e "◇━━━━━━━━━━━━━━━━━━━◇"
echo -e "❇️ <b>» Perintah Tersebut Untuk Menghubungkan Ulang</b>"
echo -e "◇━━━━━━━━━━━━━━━━━━━◇"