#!/bin/bash
export HOME=/root
export TERM=xterm
NC='\e[0m'
dateFromServer=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
biji=$(date +"%Y-%m-%d" -d "$dateFromServer")
ipsaya=$(curl -sS ipv4.icanhazip.com)
data_server=$(curl -v --insecure --silent https://google.com/ 2>&1 | grep Date | sed -e 's/< Date: //')
date_list=$(date +"%Y-%m-%d" -d "$data_server")
data_ip="https://raw.githubusercontent.com/Ris-Project/scriptpgetunnel/main/ip-bot"

checking_sc() {
  useexp=$(wget -qO- $data_ip | grep $ipsaya | awk '{print $3}')
  if [[ $date_list < $useexp ]]; then
    echo -ne
  else
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    echo -e "\033[42m     ANDA HARUS MENDAFTAR DAHULU UNTUK MENJADI SELLER     \033[0m"
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    echo -e ""
    echo -e "           ${RED}DAFTAR DULU DEK !${NC}"
    echo -e "   \033[0;33mYour VPS${NC} $ipsaya \033[0;33mHas been Banned${NC}"
    echo -e "   \033[0;33mBuy access permissions for scripts${NC}"
    echo -e "             \033[0;33mContact Admin :${NC}"
    echo -e "     \033[0;36mTelegram${NC} t.me/LITE_VERMILION"
    echo -e "     ${GREEN}WhatsApp${NC} wa.me/6281934335091"
    echo -e "\033[1;93m────────────────────────────────────────────\033[0m"
    exit
  fi
}
checking_sc

Repo1="https://raw.githubusercontent.com/Ris-Project/scriptpgetunnel/main/"
export MYIP=$(curl -sS ipv4.icanhazip.com/)
REPO="https://github.com/Ris-Project/scriptpgetunnel.git"
TOKEN="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"
EMAIL="riswanxproject@gmail.com"
USER="Ris-Project"
today=$(date -d "0 days" +"%Y-%m-%d")

if [ "$#" -ne 2 ]; then
    echo "Penggunaan: $0 <IP_LAMA> <IP_BARU>"
    exit 1
fi
old_ip="$1"
new_ip="$2"

git clone ${REPO} /root/ipvps/

CLIENT_EXISTS=$(grep -w $old_ip /root/ipvps/ip | wc -l)
if [[ ${CLIENT_EXISTS} == '0' ]]; then
  echo "IP Lama $old_ip tidak ditemukan!"
  rm -rf /root/ipvps
  exit 1
fi

name=$(grep -w $ip /root/ipvps/ip | awk '{print $2}')

sed -i "s/$old_ip/$new_ip/g" /root/ipvps/ip

cd /root/ipvps
git config --global user.email "${EMAIL}"
git config --global user.name "${USER}"
rm -rf .git &> /dev/null
git init &> /dev/null
git add . &> /dev/null

git commit -m "Ubah IP $old_ip menjadi $new_ip" &> /dev/null
git branch -M main &> /dev/null
git remote add origin https://github.com/Ris-Project/scriptpgetunnel.git
git push -f https://${TOKEN}@github.com/Ris-Project/scriptpgetunnel.git &> /dev/null
rm -rf /root/ipvps

echo -e "◇━━━━━━━━━━━━━━━━━━━◇</b>"
echo -e " ◇⟨IP SUCCESSFULLY CHANGED⟩◇</b>"
echo -e "◇━━━━━━━━━━━━━━━━━━━◇</b>"
echo -e "<b>🏷️ Nama User:</b> <code>$name</code>"
echo -e "<b>🏷️ IP Lama:</b> <code>$old_ip</code>"
echo -e "<b>🏷️ IP Baru:</b> <code>$new_ip</code>"
echo -e "◇━━━━━━━━━━━━━━━━━━━◇</b>"